'use strict';

require('mano/scripts/build-models')(__dirname + '/../public');

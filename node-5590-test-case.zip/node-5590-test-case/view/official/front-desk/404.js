'use strict';

module.exports = require('../../user/404');

'use strict';

var Db        = require('dbjs')
  , tableCols = require('../_users-table-cols')

  , DOMTable = Db.DOMTable, User = Db.User, userProto = User.prototype
  , baseUrl = url;

exports['main-menu-home'] = { class: { active: true } };

exports.main = function () {
	var usersTable, submitted, url = baseUrl.bind(this.root);

	submitted = userProto._isApplicationRegistered.indexFilter(true)
		.filterByProperty('isRevisionApproved', null);
	section({ id: 'revision' }, usersTable = new DOMTable(document, submitted, {
		head: true,
		class: 'clickable table table-bordered table-striped nomargin-table' +
			' users-table',
		sort: function (a, b) {
			return a._submitted._lastModified_ - b._submitted._lastModified_;
		},
		columns: tableCols(function (user) {
			return url('usuario', user._id_, 'debt-proof');
		})
	}));
};

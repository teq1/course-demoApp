'use strict';

var _         = require('i18n2').bind('revision')
  , getSubUrl = require('../_get-sub-url')
  , zoomOnHover = require('dom-ext/lib/HTMLElement/prototype/zoom-on-hover')

  , baseUrl = url
  , compareModified = function (a, b) {
	return a._lastModified_ - b._lastModified_;
};

exports['revision-document'] = function () {
	var sub = this.submission, Document = sub.ns.Document
	  , revForm, revOk, revFail, submit, url = baseUrl.bind(this.root);

	h2(i({ class: 'icon-chip' }, this.index), Document._label);
	ul(sub.files.list(compareModified), function (file) {
		zoomOnHover.call(li({ class: 'big-thumb-doc' },
			img({ src: file.preview ? file.preview.url : file.thumb.url })));
	});
	revForm = form({ action:
		url('revision', getSubUrl(sub.user, sub.ns.Document._id_)),
		method: 'post' },
		div({ class: 'row-fluid document-actions' },
			sub._approved.toDOMInput(document),
			div({ class: 'group-controls date-form' },
				revOk = div(sub.toDOMFieldset(document, { tag: 'revision-ok' })),
				revFail = div(sub.toDOMFieldset(document, { tag: 'revision-fail' }))),
			submit = p(input({ type: 'submit', value: _("Guardar datos") }))));
	legacy('radioMatch', revForm.getId(), sub._approved._id_, {
		0: [revFail.getId(), submit.getId()],
		1: [revOk.getId(), submit.getId()]
	});
};

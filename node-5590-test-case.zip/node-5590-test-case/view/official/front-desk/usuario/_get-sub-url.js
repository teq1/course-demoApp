'use strict';

var camelToHyphen = require('es5-ext/lib/String/prototype/camel-to-hyphen');

module.exports = function (user, name) {
	return user._id_ + '/' + camelToHyphen.call(name);
};

'use strict';

var capitalize       = require('es5-ext/lib/String/prototype/capitalize')
  , Db               = require('dbjs')
  , _                = require('i18n2').bind('revision')
  , compareStr       = require('../../../utils/compare-str')
  , getSubUrl        = require('./_get-sub-url')
  , userData         = require('../../../user-submitted/_user-data')
  , userTable        = require('../../_user-table')

  , baseUrl = url
  , compareModified = function (a, b) {
	return a._lastModified_ - b._lastModified_;
};

exports.main = function () {
	var user = this.target, url = baseUrl.bind(this.root);

	div({ id: 'revision' },
		div({ id: 'revision-header', class: 'container main-container' },
			section({ id: 'expedientes' }, userTable(user)),
			section(div({ id: 'RevisarBtn', class: 'row-fluid' },

				user._submissionsApproved.filterDOM(div({ class: 'span3' },
					postButton({ action: url('revision', user._id_, 'reject'),
						buttonClass: 'btn-large-no',
						value: [img({ src: '/img/new_icons/icon-white-no.png' }), " ",
							_("Rechazar revisión")] })), false),

				user._submissionsApproved.filterDOM(form({ action: url('revision',
					user._id_, 'approve'), method: 'post' }, div({ class: 'span3' },
						button({ class: 'btn-large-ok' },
							img({ src: '/img/new_icons/icon-white-ok.png' }), " ",
							_("Aceptar revisión")))), true)))),

		div({ id: 'revision-documents', class: 'container main-container' },
			section({ id: 'list-docs' },
				h3(_("Documentos requeridos")),
				ol(user.requiredSubmissions.list(compareStr), function (name, index) {
					li(a({ href: url('usuario', getSubUrl(user, name)) },
						i({ class: 'icon-chip' }, index + 1),
						Db[capitalize.call(name)]._label));
				})),
			section({ id: 'diapo-docs' },
				h3(_("Documentos recibidos")),
				ul(user.requiredSubmissions.list(compareStr), function (name, subIdx) {
					var init, subName = name + 'Submission'
					  , el = li({ class: 'thumb-doc' });
					init = function (sub) {
						el.appendChild(
							list(sub.files.list(compareModified), function (file, index) {
								if (index || !sub.user) return;
								a({ href: url('usuario', getSubUrl(user, name)) },
									i({ class: 'icon-chip' }, subIdx + 1),
									img({ src: file.thumb.url }),
									sub._isApproved.filterDOM(i({ class: 'icon-check-ok' }),
										true),
									sub._isApproved.filterDOM(i({ class: 'icon-check-no' }),
										false));
							})
						);
					};
					if (user[subName]) init(user[subName]);
					else user.get(subName).once('change', init);
					return el;
				}))),
		div({ id: 'revision-content', class: 'sub-container' },
			div({ id: 'revision-document', class: 'main-container' }),
			div({ class: 'revision-vsep' }), userData(user)));
};

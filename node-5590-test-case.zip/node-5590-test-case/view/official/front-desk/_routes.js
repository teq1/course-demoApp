// Routes for public website

'use strict';

var hyphenToCamel = require('es5-ext/lib/String/prototype/hyphen-to-camel')
  , memoize       = require('memoizee/lib/regular')
  , Db            = require('dbjs')
  , compareStr    = require('../../utils/compare-str')

  , isId = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/)
  , bind;

bind = function (view) {
	return function (data, env) {
		view.scope = env;
		return view.load();
	};
};

module.exports = function (view) {
	var main = view.documentElement.diff('./_main'), home, getView, getUserView;

	getUserView = memoize(function (user) {
		return home.diff('./usuario');
	});

	getView = memoize(function (sub) {
		return bind(getUserView(sub.user).diff('./usuario/__any__'));
	});

	return {
		'/':    bind(home = main.diff('./index')),
		perfil: bind(main.diff('./perfil')),
		'usuario&': {
			match: function (path, env) {
				var user, sub, fullName;
				path = path.split('/');
				if (path.length !== 2) return false;
				user = path[0];
				if (!isId(user)) return false;
				user = Db.User[user];
				if (!user || !user.isApplicationRegistered) return false;
				if (user.isRevisionApproved != null) return false;
				sub = path[1];
				if (!sub) return false;
				sub = hyphenToCamel.call(sub);
				if (!user.requiredSubmissions.has(sub)) return false;
				fullName = sub + 'Submission';
				if (!user[fullName]) return false;
				env.index = user.requiredSubmissions.list(compareStr).indexOf(sub) + 1;
				env.submission = user[fullName];
				env.target = user;
				return true;
			},
			load: function (data, env) { getView(env.submission)(data, env); }
		},

		// 404 page
		404: bind(main.diff('./404'))
	};
};

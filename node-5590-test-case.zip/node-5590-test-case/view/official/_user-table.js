'use strict';

var _ = require('i18n2').bind('user');

module.exports = function (user) {
	return table({ class: 'table table-bordered table-striped nomargin-table' +
		' users-table' }, thead(tr(th(_("Solicitante")),
			th(_("Número de solicitud")), th(_("Fecha de solicitud")),
			th(_("Registros solicitados")))),
		tbody(tr(td(user._fullName), td(user._applicationNumber),
			td(user._submitted.lastModifiedDOM(document)),
			td(user._isPreInspectionApplicable.filterDOM(
				span({ class: 'label label-pre' }, "PRE"),
				true
			), ' ', user._isLocInspectionApplicable.filterDOM(
				span({ class: 'label label-loc' }, "LOC"),
				true
			)))));
};

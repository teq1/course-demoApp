// Routes for public website

'use strict';

var hyphenToCamel = require('es5-ext/lib/String/prototype/hyphen-to-camel')
  , memoize       = require('memoizee/lib/regular')
  , Db            = require('dbjs')
  , compareStr    = require('../../utils/compare-str')

  , isId = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/)
  , bind;

bind = function (view) {
	return function (data, env) {
		view.scope = env;
		return view.load();
	};
};

module.exports = function (view) {
	var main = view.documentElement.diff('./_main'), home, getUserView
	  , getFormView, getDataView, getSubView;

	getUserView = memoize(function (user) {
		return home.diff('./usuario');
	});

	getFormView = memoize(function (user) {
		return bind(getUserView(user).diff('./usuario/__any__/forms'));
	});

	getDataView = memoize(function (user) {
		return getUserView(user).diff('./usuario/__any__/data');
	});

	getSubView = memoize(function (sub) {
		return bind(getDataView(sub.user).diff('./usuario/__any__'));
	});

	return {
		'/':    bind(home = main.diff('./index')),
		perfil: bind(main.diff('./perfil')),
		'usuario&': {
			match: function (path, env) {
				var user, sub, fullName;
				path = path.split('/');
				if (path.length > 2) return false;
				user = path[0];
				if (!isId(user)) return false;
				user = Db.User[user];
				if (!user || !user.isInspectionSatisfactory) return false;
				if (user.isMinutesStickerGenerated != null) return false;
				env.target = user;
				if (path[1] == null) return true;
				sub = path[1];
				if (!sub) return false;
				sub = hyphenToCamel.call(sub);
				if (!user.requiredSubmissions.has(sub)) return false;
				fullName = sub + 'Submission';
				if (!user[fullName]) return false;
				env.index = user.requiredSubmissions.list(compareStr).indexOf(sub) + 1;
				env.submission = user[fullName];
				return true;
			},
			load: function (data, env) {
				var view = env.submission ? getSubView(env.submission) :
						getFormView(env.target);
				view(data, env);
			}
		},

		// 404 page
		404: bind(main.diff('./404'))
	};
};

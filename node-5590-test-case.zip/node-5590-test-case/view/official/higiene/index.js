'use strict';

var Db        = require('dbjs')
  , tableCols = require('../_users-table-cols')

  , baseUrl = url
  , DOMTable = Db.DOMTable, User = Db.User, userProto = User.prototype;

exports['main-menu-home'] = { class: { active: true } };

exports.main = function () {
	var usersTable, submitted, url = baseUrl.bind(this.root);

	submitted = userProto._isInspectionSatisfactory.indexFilter(true)
		.filterByProperty('isMinutesStickerGenerated', null);
	section(usersTable = new DOMTable(document, submitted, {
		head: true,
		class: 'clickable table table-bordered table-striped nomargin-table' +
			' users-table',
		sort: function (a, b) {
			return a._inspectionSatisfactory._lastModified_ -
				b._inspectionSatisfactory._lastModified_;
		},
		columns: tableCols(function (user) { return url('usuario', user._id_); })
	}));
};

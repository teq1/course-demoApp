'use strict';

var _  = require('i18n2').bind('higiene');

exports.body = function () {
	var user = this.user;

	nav({ class: 'navbar' },
		div({ class: 'navbar-inner' },
			div({ class: 'container' },
				div({ class: 'brand' },
					div(a({ href: '/', class: 'brand' },
						img({ src: '/images/milomas-logo.png', alt: 'Lomas de Zamora' }))),
					div({ class: 'btn-toolbar' })),
				div({ class: 'nav-collapse' }),
				div({ class: 'logout-button' },
					a({ href: '/logout/', rel: 'server' },
						img({ src: '/images/logout.png', width: '40', height: '40' }))),
				div({ class: 'logout-button' },
					a({ href: '/perfil/' },
						img({ src: '/images/gear.png', width: '40', height: '40' }))),
				div({ class: 'btn-group' },
					button({ class: 'btn btn-large' },
						div({ class: 'userphoto' },
							img({ src: '/images/user.png', width: '40', height: '40',
								class: 'img-circle' })),
						div({ class: 'userinfo' },
							span({ class: 'user-name' }, user._fullName),
							br(),
							span({ class: 'institution-name' })))),
				div({ class: 'solititle' }, _("Dirección de seguridad e higiene")))));

	div({ id: 'header' },
		div({ id: 'main-menu' },
			div(ul(
				li({ id: 'main-menu-home' }, a({ href: '/' }, "Libros de actas")),
				li({ id: 'main-menu-profile' }, a({ href: '/perfil/' }, "Perfil"))
			)),
			div({ class: 'pull-right' },
				ul({ class: 'nav actions' }))));

	div({ id: 'main' });
};

'use strict';

var camelToHyphen = require('es5-ext/lib/String/prototype/camel-to-hyphen')
  , capitalize    = require('es5-ext/lib/String/prototype/capitalize')
  , Db            = require('dbjs')
  , _             = require('i18n2').bind('summary')
  , compareStr    = require('../utils/compare-str')
  , userData      = require('../user-submitted/_user-data')

  , compareModified = function (a, b) {
	return a._lastModified_ - b._lastModified_;
}, getSubUrl = function (user, name) {
	return user._id_ + '/' + camelToHyphen.call(name);
};

module.exports = function (user, url) {
	return div({ id: 'revision' },
		div({ id: 'revision-documents', class: 'container main-container' },
			section({ id: 'list-docs' },
				h3(_("Documentos requeridos")),
				ol(user.requiredSubmissions.list(compareStr), function (name, index) {
					li(a({ href: url('usuario', getSubUrl(user, name)) },
						i({ class: 'icon-chip' }, index + 1),
						Db[capitalize.call(name)]._label));
				})),
			section({ id: 'diapo-docs' },
				h3(_("Documentos recibidos")),
				ul(user.requiredSubmissions.list(compareStr), function (name, subIdx) {
					var init, subName = name + 'Submission'
					  , el = li({ class: 'thumb-doc' });
					init = function (sub) {
						el.appendChild(
							list(sub.files.list(compareModified), function (file, index) {
								if (index || !sub.user) return;
								a({ href: url('usuario', getSubUrl(user, name)) },
									i({ class: 'icon-chip' }, subIdx + 1),
									img({ src: file.thumb.url }),
									sub._isApproved.filterDOM(i({ class: 'icon-check-ok' }),
										true),
									sub._isApproved.filterDOM(i({ class: 'icon-check-no' }),
										false));
							})
						);
					};
					if (user[subName]) init(user[subName]);
					else user.get(subName).once('change', init);
					return el;
				}))),
		div({ id: 'revision-content', class: 'sub-container' },
			div({ id: 'revision-document', class: 'main-container' }),
			div({ class: 'revision-vsep' }),
			userData(user)));
};

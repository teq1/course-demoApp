'use strict';

var _  = require('i18n2').bind('users');

module.exports = function (url) {
	return [{
		head: _("Solicitante"),
		render: function (user) {
			a({ href: url(user) }, user._fullName);
		}
	}, {
		head: _("Número de solicitud"),
		render: function (user) {
			a({ href: url(user) }, user._applicationNumber);
		}
	}, {
		head: _("Fecha de solicitud"),
		render: function (user) {
			a({ href: url(user) }, user._submitted.lastModifiedDOM(document));
		},
	}, {
		head: _("Registros solicitados"),
		render: function (user) {
			a({ href: url(user) }, user._isPreInspectionApplicable.filterDOM(
				span({ class: 'label label-pre' }, "PRE"),
				true
			), ' ', user._isLocInspectionApplicable.filterDOM(
				span({ class: 'label label-loc' }, "LOC"),
				true
			));
		}
	}];
};

'use strict';

var d                = require('es5-ext/lib/Object/descriptor')
  , memoize          = require('memoizee')
  , Fragment         = require('dbjs/lib/utils/fragment/multi')
  , objFragment      = require('dbjs/lib/utils/fragment/object')
  , Role             = require('mano-auth/model/role')
  , approveRelation  = require('mano-auth/server/approve-relation')
  , baFragment       = require('../server/business-activity-access')
  , criteriaFragment = require('../server/criteria-access')
  , shFragment       = require('../server/sh-access')

  , role;

module.exports = Role;

role = Role.options.add('schema-admin');
role.setProperties({
	label: "Schema Admin",
	order: 70
});

Object.defineProperty(role, 'access', d(memoize(function (user) {
	var fragment = new Fragment();
	fragment.add(objFragment(user,
		function (rel) { return approveRelation(rel, user); }));
	fragment.add(baFragment);
	fragment.add(criteriaFragment);
	fragment.add(shFragment);
	return fragment;
})));

'use strict';

module.exports = require('../../user/model/user/base');
require('./role');

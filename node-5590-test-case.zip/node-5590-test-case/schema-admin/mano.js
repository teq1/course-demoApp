'use strict';

exports.route = function (req) { return req.$user.roles.has('schema-admin'); };
exports.order = 70;
exports.viewPath = '../view/schema-admin';

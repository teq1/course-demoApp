'use strict';

var memoize          = require('memoizee/lib/primitive')
  , Fragment         = require('dbjs/lib/utils/fragment/multi')
  , objFragment      = require('dbjs/lib/utils/fragment/object')
  , objects          = require('dbjs/lib/objects')
  , ControlCriteria = require('../../user/model/control-criteria')

  , approve, fragment, getFragment, onAdd;

approve = function (rel) {
	return (rel._root_.constructor === ControlCriteria);
};

module.exports = fragment = new Fragment();

getFragment = memoize(function (id) {
	return objFragment(objects[id], approve);
});

ControlCriteria.forEach(onAdd = function (obj) {
	fragment.add(getFragment(obj._id_));
});

ControlCriteria.on('add', onAdd);
ControlCriteria.on('delete', function (obj) {
	fragment.delete(getFragment(obj._id_));
});

'use strict';

var objFragment      = require('dbjs/lib/utils/fragment/object')
  , filter           = require('dbjs/lib/utils/fragment/filter')
  , BusinessActivity = require('../../user/model/business-activity')
  , Zone             = require('../../user/model/zone')

  , activities = BusinessActivity._options, zones = Zone._options
  , approve = function () { return true; }
  , names = { category: true, label: true, group: true, order: true,
		zoneLabelClass: true };

module.exports = filter(objFragment(BusinessActivity, approve), function (obj) {
	var parent = obj.obj;
	if (!parent) return false;
	if (parent._type_ !== 'relation-set-item') return false;
	if (names.hasOwnProperty(obj.name)) return false;
	if (parent.obj.name === 'zones') {
		if (!zones.has(parent._subject_)) return false;
		if (!activities.has(parent.obj.obj._subject_)) return false;
	} else if (parent.obj.name === 'options') {
		if (!activities.has(parent._subject_)) return false;
	} else {
		return false;
	}
	return true;
});

'use strict';

var Fragment    = require('dbjs/lib/utils/fragment/multi')
  , objFragment = require('dbjs/lib/utils/fragment/object')
  , filter      = require('dbjs/lib/utils/fragment/filter')
  , Category    = require('../../user/model/sh-category')
  , Control     = require('../../user/model/control-criteria')

  , fragment, getFragment, onAdd, filterCb, approve;

module.exports = fragment = new Fragment();

approve = function (obj) {
	if (obj.obj._type_ !== 'object') return true;
	if (obj.obj.constructor === Control) return false;
	if (obj.name === 'label') return false;
	if (obj.name === 'order') return false;
	if (obj.name === 'tags') return false;
	return true;
};

filterCb = function (obj) { return (obj._type_ !== 'object'); };

getFragment = function (obj) {
	return filter(objFragment(obj, approve), function (obj) {
		return filterCb(obj);
	});
};

Category.forEach(onAdd = function (obj) { fragment.add(getFragment(obj)); });

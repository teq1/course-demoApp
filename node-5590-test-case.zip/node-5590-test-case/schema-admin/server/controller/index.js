'use strict';

module.exports = {
	profile:             require('../../../user/server/controller/profile'),
	'change-password-x': require('mano-auth/server/controller/change-password-x'),
	'rules&':            require('./rules'),
	'tes&':              require('./tes'),
	'zone&':             require('./zone'),
	'criteria&':         require('./criteria'),
	'criteria/add':      require('./criteria/add'),
	'sh&':               require('./sh')
};

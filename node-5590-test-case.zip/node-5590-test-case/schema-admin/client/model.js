'use strict';

var User     = require('../model/user')
  , Password = require('dbjs-ext/string/string-line/password')

  , user = User.prototype;

user._password.ns = Password;

require('../../user/model/business-activity');
require('../../user/model/control-criteria');
require('../../user/model/sh-category');
module.exports = require('dbjs');

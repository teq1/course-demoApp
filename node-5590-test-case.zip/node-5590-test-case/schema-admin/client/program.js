'use strict';

require('mano/lib/client')({
	schema: function () {
		var Db = require('./model.generated'), itemProto;

		Db.User.prototype._password.ns = Db.Password;

		Db.Boolean._trueLabel.$$setValue("Si");
		Db.Boolean._falseLabel.$$setValue("No");
		require('dbjs-dom/text');
		require('dbjs-dom/text/string/string-line/enum');
		require('dbjs-dom/text/utils/table');
		require('dbjs-dom/ext/domjs/table-cell-render');
		require('dbjs-dom/input');
		require('dbjs-dom/input/date-time/date');
		require('dbjs-dom/input/string/string-line');
		require('dbjs-dom/input/string/string-line/email');
		require('dbjs-dom/input/string/string-line/url');
		require('dbjs-dom/input/string/string-line/enum').chooseLabel =
			'Seleccione:';
		require('dbjs-dom/input/string/string-line/password');
		require('dbjs-dom/input/utils/fieldset');

		require('dbjs-dom-bootstrap/number/square-meters');
		require('dbjs-dom-bootstrap/number/horse-power');
		itemProto = Db.BusinessActivity._options._itemPrototype_;
		itemProto._zones._itemPrototype_._inspectionMandatory.DOMInput =
			itemProto._zones._itemPrototype_._locInspectionMandatory.DOMInput =
			itemProto._higieneRegistration.DOMInput =
			Db.SHCategory.prototype._inspectionMandatory.DOMInput =
			require('dbjs-dom-bootstrap/boolean-button-group');
		Db.RuleQuestion.DOMRadio = require('./rule-question-btn-group');
	},
	viewRequire: require('../../view/schema-admin/_require'),
	routes: function (router, view) {
		var Table = require('dbjs-dom/text/utils/table');
		Table.prototype.domjs = view.engine;

		router.get = require('../../view/schema-admin/_routes')(view);
		router.post = require('mano/lib/client/build-controller')(
			require('../controller'),
			require('./controller')
		);
	}
});

'use strict';

var dbjsCreate = require('mano/lib/utils/dbjs-form-create')
  , location   = require('mano/lib/client/location');

module.exports = function (data, env) {
	dbjsCreate(data);
	location.goto(location.root + 'condiciones/');
};

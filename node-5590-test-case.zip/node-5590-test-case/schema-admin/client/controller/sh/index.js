'use strict';

var dbjsSet  = require('mano/lib/utils/dbjs-form-save')
  , location = require('mano/lib/client/location');

module.exports = function (data, env) {
	dbjsSet(data);
	if (env.method === 'conditions') {
		location.goto(location.root + 'control-de-seguridad-e-higiene/');
	}
};

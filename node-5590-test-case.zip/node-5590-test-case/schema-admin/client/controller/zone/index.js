'use strict';

var dbjsSet = require('mano/lib/utils/dbjs-form-save');

module.exports = function (data, env) {
	dbjsSet(data);
	env.target._zoneStatus._update_();
	env.target._zoneLabelClass._update_();
};

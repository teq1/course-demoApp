'use strict';

module.exports = {
	profile:        require('../../../user/client/controller/profile'),
	'rules&':       require('./rules'),
	'tes&':         require('./tes'),
	'zone&':        require('./zone'),
	'criteria&':    require('./criteria'),
	'criteria/add': require('./criteria/add'),
	'sh&':          require('./sh'),
};

'use strict';

var live = require('mano-legacy/live');

window.$ = require('mano-legacy');

require('mano-legacy/select-match');
require('mano-legacy/radio-match');

require('domjs-ext/post-button.legacy');

live.add('form', 'class', 'auto-submit',
	require('mano-legacy/form-auto-submit'));

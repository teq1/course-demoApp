'use strict';

var d     = require('es5-ext/lib/Object/descriptor')
  , Radio = require('dbjs-dom-bootstrap/string/string-line/enum-button-group')

  , RuleRadio;

module.exports = RuleRadio = function (document, ns/*, options*/) {
	Radio.apply(this, arguments);
};

RuleRadio.prototype = Object.create(Radio.prototype, {
	constructor: d(RuleRadio),
	classMap: d({ no: 'danger', ask: 'warning' })
});

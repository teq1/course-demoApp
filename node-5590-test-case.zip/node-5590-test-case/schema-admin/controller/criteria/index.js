'use strict';

var dbjsValidate = require('mano/lib/utils/dbjs-form-validate')
  , Criteria     = require('dbjs/lib/objects')._get('ControlCriteria')
  , isId         = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/);

exports.match = function (path, env) {
	var method, criteria;
	path = path.split('/');
	if (path.length > 2) return false;
	criteria = path[0];
	if (!isId(criteria)) return false;
	if (!Criteria.hasOwnProperty(criteria)) return false;
	criteria = Criteria[criteria];
	if (path[1] == null) method = 'edit';
	else if (path[1] === 'delete') method = 'delete';
	else return false;
	env.method = method;
	env.target = criteria;
	return true;
};

exports.load = function (data, env) {
	if (env.method !== 'delete') dbjsValidate(data, { changedOnly: true });
};

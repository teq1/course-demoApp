'use strict';

var dbjsValidate = require('mano/lib/utils/dbjs-form-validate')
  , Db           = require('dbjs')

  , activities = Db.BusinessActivity._options;

exports.match = function (activity, env) {
	if (!activities.has(activity)) return false;
	env.target = activities.getItem(activity);
	return true;
};

exports.load = function (data, env) {
	dbjsValidate(data, { changedOnly: true });
};

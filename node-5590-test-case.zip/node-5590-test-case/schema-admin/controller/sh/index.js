'use strict';

var dbjsValidate = require('mano/lib/utils/dbjs-form-validate')
  , Category     = require('dbjs/lib/objects')._get('SHCategory')
  , isId         = RegExp.prototype.test.bind(/^[a-z][a-zA-Z0-9]+$/);

exports.match = function (path, env) {
	var method, category;
	path = path.split('/');
	if (path.length > 2) return false;
	category = path[0];
	if (!isId(category)) return false;
	if (!Category.hasOwnProperty(category)) return false;
	category = Category[category];
	if (path[1] == null) method = 'conditions';
	else if (path[1] === 'inspection') method = 'inspection';
	else return false;
	env.method = method;
	env.target = category;
	return true;
};

exports.load = function (data, env) { dbjsValidate(data); };

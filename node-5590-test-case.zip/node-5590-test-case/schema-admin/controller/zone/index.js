'use strict';

var dbjsValidate = require('mano/lib/utils/dbjs-form-validate')
  , Db           = require('dbjs')

  , activities = Db.BusinessActivity._options, zones = Db.Zone._options;

exports.match = function (path, env) {
	var activity, zone;
	path = path.split('/');
	if (path.length !== 2) return false;
	activity = path[0];
	if (!activities.has(activity)) return false;
	zone = path[1];
	if (!zones.has(zone)) return false;
	env.target = activities.getItem(activity)._zones.getItem(zone);
	return true;
};

exports.load = function (data, env) {
	dbjsValidate(data, { changedOnly: true });
};

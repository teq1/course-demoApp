'use strict';

exports.route = function (req) {
	var user = req.$user;
	return user.roles.has('user') && !user.isApplicationRegistered;
};
exports.order = 10;
exports.viewPath = '../view/user';

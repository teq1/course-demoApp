'use strict';

var Db  = require('dbjs')

  , max = Math.max, setNumber
  , submitted, missing = [], current = 50000;

setNumber = function (user) {
	var num = '4068-' + String(++current).slice(0, 5) + '-';
	if (user.lastName) num += user.lastName.trim().charAt(0).toUpperCase() || '-';
	else num += '-';
	num += '-';
	num += String((new Date()).getUTCFullYear());
	user.applicationNumber = num;
};

submitted = Db.User.prototype._applicationSubmissionStatus.indexFilter(true);

Db.User.forEach(function (user) {
	if (user.applicationNumberNumber) {
		current = max(current, user.applicationNumberNumber);
	} else if (user.applicationSubmissionStatus) {
		missing.push(user);
	}
});

console.log("Last application number:", current);

missing.sort(function (a, b) {
	return a._submitted._lastModified_ - b._submitted._lastModified_;
}).forEach(setNumber);
missing = null;

submitted.on('add', function (user) {
	if (user.applicationNumber) return;
	setNumber(user);
});

require('../model/user/_activity-rules');

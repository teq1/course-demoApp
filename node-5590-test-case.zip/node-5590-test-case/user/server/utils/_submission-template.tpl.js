'use strict';

var extend = require('es5-ext/lib/Object/extend')
  , Doc    = require('../$FILENAME$')

  , Submission;

Submission = module.exports = Doc.Submission = require('./_submission')
	.create('$NAME$', {}, { Document: Doc });

extend(Submission.prototype._user, {
	unique: true,
	reverse: true
});

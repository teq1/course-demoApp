'use strict';

var camelToHyphen = require('es5-ext/lib/String/prototype/camel-to-hyphen')
  , deferred      = require('deferred')
  , readFile      = require('fs2/lib/read-file')
  , writeFile     = require('fs2/lib/write-file')
  , resolve       = require('path').resolve

  , stringify = JSON.stringify
  , re = /([A-Z0-9]+) ([\0-\uffff]+)\(([\0-\(\*-\uffff]+)\)$/
  , root = resolve(__dirname, '../../model/documents');

deferred(readFile(resolve(__dirname, '_docs-template.tpl.js')),
	readFile(resolve(root, 'documents.txt'))(function (str) {
		return String(str).trim().split('\n')
			.map(function (str) { return str.trim(); }).filter(Boolean)
			.map(function (str) {
				var tokens = str.match(re);
				if (!tokens) throw Error("No match '" + str + "'");
				return {
					code: tokens[1],
					label: tokens[2].trim(),
					name: tokens[3].split(/\s+/).map(function (item) {
						return item[0].toUpperCase() + item.slice(1);
					}).join('')
				};
			});
	})).match(function (tpl, conf) {
	tpl = String(tpl);
	conf.sort(function (a, b) { return a.name.localeCompare(b.name); });
	return deferred(writeFile(resolve(root, 'index.js'),
		'\'use strict\';\n\nmodule.exports = require(\'./_document\');\n\n' +
		conf.map(function (data) {
			return 'require(\'./' + camelToHyphen.call(data.name) + '\');';
		}).join('\n') + '\n'), deferred.map(conf, function (data) {
		return writeFile(resolve(root, camelToHyphen.call(data.name) + '.js'),
			tpl.replace('$COMMENT$', data.code + ' ' + data.label)
			.replace('$NAME$', data.name).replace('$LABEL$', stringify(data.label)));
	}));
}).end();

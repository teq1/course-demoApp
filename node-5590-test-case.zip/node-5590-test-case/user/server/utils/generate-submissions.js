'use strict';

var capitalize    = require('es5-ext/lib/String/prototype/capitalize')
  , hyphenToCamel = require('es5-ext/lib/String/prototype/hyphen-to-camel')
  , deferred      = require('deferred')
  , readFile      = require('fs2/lib/read-file')
  , writeFile     = require('fs2/lib/write-file')
  , readdir       = require('fs2/lib/readdir')
  , resolve       = require('path').resolve

  , docsDir = resolve(__dirname, '../../model/documents')
  , subsDir = resolve(docsDir, 'submissions');

deferred(readFile(resolve(__dirname, '_submission-template.tpl.js')),
	readdir(docsDir, { type: { file: true } }).invoke('filter', function (name) {
		if (name[0] === '_') return false;
		if (name[0] === '.') return false;
		if (name.slice(-3) !== '.js') return false;
		if (name === 'index.js') return false;
		return true;
	})).match(function (tpl, names) {
	tpl = String(tpl);
	return deferred(deferred.map(names, function (name) {
		name = name.slice(0, -3);
		return deferred(writeFile(resolve(subsDir, name + '.js'),
			tpl.replace('$FILENAME$', name)
			.replace('$NAME$', hyphenToCamel.call(capitalize.call(name)) +
				'Submission')));
	}), writeFile(resolve(subsDir, 'index.js'),
		'\'use strict\';\n\nmodule.exports = require(\'./_submission\');\n\n' +
		names.map(function (name) { return 'require(\'./' + name + '\');'; })
		.join('\n') + '\n'));
});

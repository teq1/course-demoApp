'use strict';

var dbjsCreate = require('mano/lib/utils/dbjs-form-create');

module.exports = function (data, env) {
	env.user.partners.add(dbjsCreate(data));
};

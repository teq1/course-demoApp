'use strict';

var dbjsCreate = require('mano/lib/utils/dbjs-form-create');

module.exports = function (data, env) {
	env.user.representatives.add(dbjsCreate(data));
};

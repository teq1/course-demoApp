'use strict';

var deferred = require('deferred')
  , Db       = require('dbjs')
  , fs       = require('fs')
  , resolve  = require('path').resolve
  , gm       = require('gm')

  , isArray = Array.isArray
  , promisify = deferred.promisify, rename = promisify(fs.rename)
  , filesPath = resolve(__dirname, '../../../uploads');

gm.prototype.writeP = promisify(gm.prototype.write);

module.exports = function (data, env) {
	var ns = Db[env.action.query.doc], submission, files
	  , user = env.user, relName;

	console.log("Document upload:", ns._id_, data.file);

	relName = ns._id_[0].toLowerCase() + ns._id_.slice(1);

	if (!data.file) return true;

	files = isArray(data.file) ? data.file : [data.file];
	return deferred.map(files, function (file) {
		var dbFile, path, thumbPath, previewPath, ext;
		dbFile = new Db.SubmissionFile();
		ext = '.' + file.name;
		path = dbFile._id_ + ext;
		if (file.type !== 'image/jpeg') ext += '.jpg';
		thumbPath = dbFile._id_ + '.thumb' + ext;
		previewPath = dbFile._id_ + ext;

		return rename(file.path, resolve(filesPath, path))(function () {
			var filePath = path, thumb, preview;
			if (file.type === 'application/pdf') filePath += '[0]';
			thumb = gm(resolve(filesPath, filePath)).resize(500, 500)
				.writeP(resolve(filesPath, thumbPath));
			if (path !== previewPath) {
				preview = gm(resolve(filesPath, filePath)).resize(1500, 1500)
					.writeP(resolve(filesPath, previewPath));
			}
			return deferred(thumb, preview);
		})({ path: path, thumbPath: thumbPath, file: file, dbFile: dbFile,
			previewPath: previewPath });
	})(function (data) {
		var files;
		files = data.map(function (data) {
			var thumb, preview;
			data.dbFile.dir = resolve(filesPath, data.path);
			data.dbFile.url = '/' + encodeURIComponent(data.path);
			data.dbFile.name = data.file.name;
			data.dbFile.size = data.file.size;

			thumb = new Db.Image();
			thumb.dir = resolve(filesPath, data.thumbPath);
			thumb.url = '/' + encodeURIComponent(data.thumbPath);
			thumb.name = data.file.name;
			data.dbFile.thumb = thumb;

			preview = new Db.Image();
			preview.dir = resolve(filesPath, data.previewPath);
			preview.url = '/' + encodeURIComponent(data.previewPath);
			preview.name = data.file.name;
			data.dbFile.preview = preview;

			return data.dbFile;
		});

		submission = user[relName];
		if (!submission) {
			submission = ns({ user: user });
			submission.files = files;
		} else {
			files.forEach(function (file) { submission.files.add(file); });
			if (submission.approved != null) submission._approved.$setValue(null);
		}
		return true;
	});
};

'use strict';

var cpController = require('mano-auth/server/controller/change-own-password-x');

module.exports = {
	'/':                     require('./guide'),
	activities:              require('./activities'),
	address:                 require('./address'),
	'application-submit':    require('./application-submit'),
	business:                require('./business'),
	'business-address':      require('./business-address'),
	'change-own-password-x': cpController,
	company:                 require('./company'),
	'document-file-delete&': require('./document-file-delete'),
	'document-upload':       require('./document-upload'),
	inventory:               require('./inventory'),
	'partner&':              require('./partner'),
	'partner/add':           require('./partner/add'),
	personal:                require('./personal'),
	'pickup-institution':    require('./pickup-institution'),
	profile:                 require('./profile'),
	'representative&':       require('./representative'),
	'representative/add':    require('./representative/add'),
	other:                    require('./other')
};

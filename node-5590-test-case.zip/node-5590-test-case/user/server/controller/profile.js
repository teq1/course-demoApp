'use strict';

var dbjsSet    = require('mano/lib/utils/dbjs-form-save')
  , controller = require('mano-auth/server/controller/change-own-password');

module.exports = function (data, env) {
	dbjsSet(data);
	if (data.password) return controller(data, env);
};

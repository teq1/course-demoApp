'use strict';

module.exports = {"administracion-publica":"Administración Pública","comercio-mayorista":"Comercio Mayorista","comercio-minorista":"Comercio Minorista","cultura-culto-y-esparcimiento":"Cultura-culto y esparcimiento","educacion":"Educación","infraestructura-de-servicios":"Infraestructura de servicios","residencial":"Residencial","sanidad":"Sanidad","transportes":"Transportes","servicios":"Servicios"};

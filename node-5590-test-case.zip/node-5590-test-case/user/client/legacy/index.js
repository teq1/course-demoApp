'use strict';

var live = require('mano-legacy/live');

window.$ = require('mano-legacy');

require('mano-legacy/dbjs-form-fill');
require('mano-legacy/for-in');
require('mano-legacy/input-mask');
require('mano-legacy/on-env-update');
require('mano-legacy/select-match');
require('mano-legacy/setify');
require('mano-legacy/tabs');

require('mano-legacy/element#/class');
require('mano-legacy/element#/event');
require('mano-legacy/element#/get-by-class');
require('mano-legacy/element#/toggle');

require('domjs-ext/post-button.legacy');

require('./dept-control');

live.add('input', 'data-mask', $.inputMask);
live.add('ul', 'class', 'nav-tabs', $.tabs);

require('./zone-map');

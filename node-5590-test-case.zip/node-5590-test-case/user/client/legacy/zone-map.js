'use strict';

var $       = require('mano-legacy')
  , console = require('mano-legacy/console')
  , live    = require('mano-legacy/live')
  , kmls    = require('./zone-kml');

require('mano-legacy/element#/event');
require('mano-legacy/custom-events/enterkeypress');

google.maps.visualRefresh = true;

google.maps.Polygon.prototype.my_getBounds = function () {
	var bounds = new google.maps.LatLngBounds();
	this.getPath().forEach(function (element, index) {
		bounds.extend(element);
	});
	return bounds;
};

live.add('div', 'id', 'zone-map', function (dom) {
	var map, geocoder, infowindow, myLatLng, marker
	  , addListenersOnPolygon, select, resetMap, resetAll, codeAddress
	  , zoneCoords, zoneSelect, current, zones = []
	  , myOptions, k, addressInput, validZones = {}, zoneMap = {}
	  , addressP, addressBtn, zoneSelectDiv, tmpEl;

	marker = new google.maps.Marker();

	addListenersOnPolygon = function (polygon) {
		google.maps.event.addListener(polygon, 'click', function (event) {
			select(polygon.id);
		});
	};

	select = function (id) {
		zoneSelect.value = id;
		if (current === id) return;
		resetMap();
		marker.setMap();
		current = id;
		console.log("Zone select: " + id);
		if (!zones[id]) return;
		zones[id].setOptions({ strokeOpacity: 1, fillOpacity: 0.6,
			fillColor: '#FFF665', strokeColor: '#FFF665' });
		map.panTo(zones[id].my_getBounds().getCenter());
	};

	resetMap = function () {
		var k;
		for (k in kmls) {
			if (!kmls.hasOwnProperty(k)) return;
			zones[k].setOptions({ strokeOpacity: 0.25, fillOpacity: 0.5,
				fillColor: kmls[k].color, strokeColor: kmls[k].color });
		}
	};

	resetAll = function () {
		resetMap();
		map.panTo(myLatLng);
		map.setZoom(13);
		marker.setMap();
	};

	codeAddress = function (address) {
		if (!address) return;
		geocoder.geocode({ 'address': address + ', Lomas de Zamora, Argentina',
			region: 'ar' }, function (results, status) {
			var goodResult, r, k, inside, gLocation;
			if (status === google.maps.GeocoderStatus.OK) {
				goodResult = false;
				for (r = 0; r < results.length; ++r) {
					gLocation = results[r].geometry.location;
					if (results[r].geometry.location_type === 'APPROXIMATE') continue;
					for (k in kmls) {
						if (!kmls.hasOwnProperty(k)) continue;
						inside = google.maps.geometry.poly
							.containsLocation(gLocation, zones[k]);
						if (inside === true) {
							select(k);
							map.panTo(gLocation);
							marker.setOptions({
								map: map,
								position: gLocation,
								title: results[r].formatted_address
							});
							goodResult = true;
							break;
						}
					}
					if (goodResult === true) break;
				}
				if (goodResult === false) alert("No result in the areas: " + status);
			} else {
				alert("Geocode was not successful for the following reason: " + status);
			}
		});
	};

	zoneCoords = function (z) {
		var coords = [], c;
		for (c = 0; c < kmls[z].data.length; ++c) {
			coords.push(new google.maps.LatLng(kmls[z].data[c].lat,
				kmls[z].data[c].long));
		}
		return coords;
	};

	geocoder = new google.maps.Geocoder();
	myLatLng = new google.maps.LatLng(-34.761076, -58.431129);
	myOptions = {
		zoom: 13,
		maxZoom: 17,
		minZoom: 12,
		disableDefaultUI: true,
		center: myLatLng,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};

	map = new google.maps.Map(dom, myOptions);
	infowindow = new google.maps.InfoWindow();

	zoneSelectDiv = $('zone-control');
	zoneSelect = zoneSelectDiv.getElementsByTagName('select')[0];
	for (k = 0; (tmpEl = zoneSelect.options[k]); ++k) {
		if (tmpEl.value) validZones[tmpEl.value] = true;
	}
	for (k in kmls) {
		if (!kmls.hasOwnProperty(k)) continue;
		if (!validZones.hasOwnProperty(k)) {
			console.log("Invalid: " + k);
			delete kmls[k];
			continue;
		}
		zoneMap[k] = true;
		zones[k] = new google.maps.Polygon({
			paths: zoneCoords(k),
			strokeColor: kmls[k].color,
			strokeOpacity: 0.25,
			fillColor: kmls[k].color,
			fillOpacity: 0.5,
			id: k
		});
		zones[k].setMap(map);
		addListenersOnPolygon(zones[k]);
	}

	for (k in validZones) {
		if (!validZones.hasOwnProperty(k)) continue;
		if (!zoneMap.hasOwnProperty(k)) {
			console.error("Zone not presented on map: " + k);
		}
	}
	addressP = $(zoneSelect.parentNode.insertBefore(document.createElement('p'),
		zoneSelect));
	addressInput = document.createElement('input');
	addressInput.setAttribute('type', 'text');
	addressP.appendChild(addressInput);
	addressP.appendChild(document.createTextNode(" "));
	addressBtn = document.createElement('input');
	addressBtn.setAttribute('type', 'button');
	addressBtn.setAttribute('value', "encontrar la dirección");
	addressP.appendChild(addressBtn);

	$(addressBtn).addEvent('click', function (e) {
		codeAddress(addressInput.value);
	});
	$(addressInput).addEvent('enterkeypress', function (e) {
		$.stopPropagation(e);
		$.preventDefault(e);
		codeAddress(addressInput.value);
	});
	zoneSelect.style.display = 'none';

	select(zoneSelect.value);
	if (!zoneSelect._dbjsInput) return;

	// Modern browser, watch for DB update
	zoneSelect._dbjsInput.on('change', function () {
		if (current !== zoneSelect.value) select(zoneSelect.value);
	});
});

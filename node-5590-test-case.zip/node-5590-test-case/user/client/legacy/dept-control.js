'use strict';

var $              = require('mano-legacy')
  , provinceMap    = require('./province-map')
  , provinceLabels = require('./province-labels');

require('mano-legacy/for-each');
require('mano-legacy/for-in');
require('mano-legacy/make-element');
require('mano-legacy/select-match');

require('mano-legacy/element#/parent-by-name');

$.deptControl = function (deptSelect) {
	var deptRow, provinceSelect, options = {}, provinceRow, dept, province
	  , map = {}, provinceOptions = {}, selectedProvinceOption, updateSelect
	  , selectedDeptOption, deptMap = {};

	deptSelect = $(deptSelect);
	deptRow = deptSelect.parentByName('tr');
	dept = deptSelect.value;

	// Gather options
	$.forEach(deptSelect.getElementsByTagName('option'), function (option) {
		options[option.value] = option;
	});
	$.forIn(provinceMap, function (ids, provinceId) {
		var list = map[provinceId] = [];
		$.forEach(ids, function (id, i) {
			list[i] = options[id];
			deptMap[id] = provinceId;
			if (id === dept) {
				selectedDeptOption = options[id];
				province = provinceId;
			}
		});
	});

	// Generate Province row
	provinceRow = $.makeElement('tr', { 'class': 'dbjs' }, $.makeElement('th',
		$.makeElement('label', { for: 'input-province' }, "Provincia:")),
		$.makeElement('td',
			provinceSelect = $.makeElement('select', { id: 'input-province' })));
	provinceSelect.appendChild(deptSelect.firstChild.cloneNode(true));
	$.forIn(provinceLabels, function (label, value) {
		var option = provinceSelect.appendChild(new Option(label, value));
		provinceOptions[value] = option;
		if (value === province) {
			selectedProvinceOption = option;
			option.setAttribute('selected', 'selected');
		}
	});

	deptRow.parentNode.insertBefore(provinceRow, deptRow);

	// Invoke match
	updateSelect = $.selectMatch(provinceSelect, map);

	if (!document.on) return;
	document.on('db:' + deptSelect.name, function (dept) {
		var province = deptMap[dept];
		if (selectedProvinceOption) {
			selectedProvinceOption.removeAttribute('selected');
		}
		selectedProvinceOption = provinceOptions[province];
		if (selectedProvinceOption) {
			selectedProvinceOption.setAttribute('selected', 'selected');
		}
		provinceSelect.value = province;
		updateSelect(province);

		if (selectedDeptOption) selectedDeptOption.removeAttribute('selected');
		selectedDeptOption = options[dept];
		if (selectedDeptOption) {
			selectedDeptOption.setAttribute('selected', 'selected');
		}
		deptSelect.value = dept;
	});
};

'use strict';

var reload = function () { window.location.href = '/'; };

require('mano/lib/client')({
	schema: function () {
		var Db = require('./model.generated')
		  , user = Db.User.prototype;

		user._password.ns = Db.Password;
		Db.Boolean._trueLabel.$$setValue("Si");
		Db.Boolean._falseLabel.$$setValue("No");
		require('../model/user/_activity-rules');

		require('dbjs-dom/text');
		require('dbjs-dom/text/string/string-line/enum');
		require('dbjs-dom/input');
		require('dbjs-dom/input/date-time/date');
		require('dbjs-dom/input/string/string-line');
		require('dbjs-dom/input/string/string-line/email');
		require('dbjs-dom/input/string/string-line/enum').chooseLabel =
			'Seleccione:';
		require('dbjs-dom/input/string/string-line/password');
		require('dbjs-dom/input/utils/fieldset');
		require('dbjs-dom-bootstrap/number/currency');
		require('dbjs-dom-bootstrap/number/square-meters');
		user._businessPerpStreets.DOMInput =
			require('dbjs-dom/input/composites/line');
		user._businessNomenclature.DOMInput =
			require('dbjs-dom/input/composites/line');
		require('./business-activity-input');
	},
	viewRequire: require('../../view/user/_require'),
	routes: function (router, view) {
		var server = require('mano/lib/client/server-sync');
		router.get = require('../../view/user/_routes')(view, router.user);
		router.post = require('mano/lib/client/build-controller')(
			require('../controller'),
			require('./controller')
		);

		router.user.get('isApplicationRegistered').on('change',
			function (value) {
				if (!value) return;
				server.once('sync', reload);
			});
	}
});

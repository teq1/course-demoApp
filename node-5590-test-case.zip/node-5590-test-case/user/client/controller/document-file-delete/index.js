'use strict';

module.exports = function (data, env) {
	var submission = env.target.submission;
	if (submission.approved != null) submission._approved.$setValue(null);
	env.target.delete();
};

'use strict';

var save = require('mano/lib/utils/dbjs-form-save');

module.exports = function (data, env) {
	save(data);
	env.user.inventoryValue = env.user.inventoryTotal;
};

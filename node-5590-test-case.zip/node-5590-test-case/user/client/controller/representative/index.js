'use strict';

var dbjsSet  = require('mano/lib/utils/dbjs-form-save')
  , location = require('mano/lib/client/location');

module.exports = function (data, env) {
	if (env.method === 'delete') {
		env.target.delete();
		return;
	}
	dbjsSet(data);
	location.goto(location.root + 'ingrese-sus-datos/');
};

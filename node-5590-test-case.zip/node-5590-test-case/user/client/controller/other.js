'use strict';

var dbjsSave = require('mano/lib/utils/dbjs-form-save');

module.exports = function (data) { dbjsSave(data); };

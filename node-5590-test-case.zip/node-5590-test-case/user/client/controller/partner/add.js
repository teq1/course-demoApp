'use strict';

var dbjsCreate = require('mano/lib/utils/dbjs-form-create')
  , location   = require('mano/lib/client/location');

module.exports = function (data, env) {
	env.user.partners.add(dbjsCreate(data));
	location.goto(location.root + 'ingrese-sus-datos/');
};

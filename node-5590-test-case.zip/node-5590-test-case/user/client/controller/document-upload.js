'use strict';

var noop   = require('es5-ext/lib/Function/noop')
  , upload = require('mano/lib/client/utils/upload');

module.exports = function (data, env) {
	if (!data.file.length) return;
	return upload(data.file, env.form, env.form._progressContainer)(noop);
};

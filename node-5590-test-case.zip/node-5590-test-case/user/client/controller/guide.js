'use strict';

var dbjsSave = require('mano/lib/utils/dbjs-form-save')
  , location = require('mano/lib/client/location');

module.exports = function (data) {
	dbjsSave(data);
	location.goto(location.root + 'otras-caracteristicas/');
};

// Tweak businessActivity input to show only activities allowed for business
// location zone

'use strict';

var d  = require('es5-ext/lib/Object/descriptor')
  , Db = require('dbjs')

  , zones = Db.Zone._options, rel = Db.User.prototype._businessActivities
  , org = rel.toDOMInput;

Object.defineProperty(rel, 'toDOMInput', d(function (document/*, options*/) {
	var options = Object(arguments[1]), input, user = this.obj, onChange;
	Object(options.item).only =
		user.locationZone && zones.getItem(user.locationZone).activities;

	input = org.call(this, document, options);
	onChange = function (input, nu) {
		var old = input.onlyFilter;
		if (old) {
			old.off('add', input.reload);
			old.off('delete', input.reload);
			input.onlyFilter = null;
		}
		if (!nu) return;
		input.onlyFilter = nu;
		nu.on('add', input.reload);
		nu.on('add', input.reload);
		input.reload();
	};
	user._locationZone.on('change', function (zone) {
		var nu = zones.getItem(zone).activities;
		input.items.forEach(function (input) { onChange(input, nu); });
	});
	return input;
}));

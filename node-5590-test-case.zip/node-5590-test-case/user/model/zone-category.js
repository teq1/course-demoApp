'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('ZoneCategory', {
	'side': {
		label: "Banda",
		order: 1
	},
	'commercial': {
		label: "Comercial",
		order: 2
	},
	'industrial': {
		label: "Industrial",
		order: 3
	},
	'recreation': {
		label: "Recreación",
		order: 4
	},
	'residential': {
		label: "Residencial",
		order: 5
	}
});

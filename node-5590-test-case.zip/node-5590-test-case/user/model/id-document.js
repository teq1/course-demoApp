'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('IdDocument', {
	id: {
		label: "Documento Nacional de Identidad",
		order: 1
	},
	'enrollment-book': {
		label: "Libreta de enrolamiento",
		order: 2
	},
	'civic-book': {
		label: "Libreta cívica",
		order: 3
	}
});

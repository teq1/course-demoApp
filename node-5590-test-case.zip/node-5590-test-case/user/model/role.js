'use strict';

var d            = require('es5-ext/lib/Object/descriptor')
  , memoize      = require('memoizee')
  , Fragment     = require('dbjs/lib/utils/fragment/multi')
  , objFragment  = require('dbjs/lib/utils/fragment/object')
  , Role         = require('mano-auth/model/role')
  , apprRelation = require('mano-auth/server/approve-relation')
  , baFragment   = require('../../schema-admin/server/business-activity-access')

  , role;

module.exports = Role;

role = Role.options.add('user');

role.setProperties({
	label: "Commerciante",
	order: 1
});

Object.defineProperty(role, 'access', d(memoize(function (user) {
	var fragment = new Fragment();
	fragment.add(objFragment(user,
		function (rel) { return apprRelation(rel, user); }));
	fragment.add(baFragment);
	return fragment;
})));

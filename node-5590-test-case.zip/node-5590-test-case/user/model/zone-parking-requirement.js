'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('ZoneParkingRequirement', {
	'no': {
		label: "no se requiere",
		order: 1
	},
	'yes': {
		label: "obligatorio",
		order: 2
	},
	'surface-depend': {
		label: "obligatorio a partir de cierta superficie cubierta",
		order: 3
	},
	'street-aside': {
		label: "obligatorio solamente con acceso por calle lateral",
		order: 4
	}
});

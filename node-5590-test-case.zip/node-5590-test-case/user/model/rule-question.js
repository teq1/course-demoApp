'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('RuleQuestion', {
	'yes': {
		label: "Si",
		order: 1
	},
	'no': {
		label: "No",
		order: 2
	},
	'ask': {
		label: "Preguntar",
		order: 3
	}
});

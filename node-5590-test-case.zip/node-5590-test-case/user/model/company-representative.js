'use strict';

var Db         = require('dbjs')
  , Percentage = require('dbjs-ext/number/percentage')
  , StringLine = require('dbjs-ext/string/string-line');

module.exports = Db.create('CompanyRepresentative', {
	firstName: StringLine.rel({ required: true, label: "Nombre", order: 1,
		tags: ['details'] }),
	lastName: StringLine.rel({ required: true, label: "Apellido", order: 2,
		tags: ['details'] }),
	position: StringLine.rel({ required: true, label: "Cargo en la sociedad",
		order: 3, inputHint: "de cada persona autorizada a firmar",
		tags: ['details'] }),

	fullName: StringLine.rel({ value: function () {
		return this.firstName + " " + this.lastName;
	}, triggers: ['firstName', 'lastName'] }),
	status: Percentage.rel({ value: function () {
		var total = 0, valid = 0;
		++total;
		if (this.firstName != null) ++valid;
		++total;
		if (this.lastName != null) ++valid;
		++total;
		if (this.position != null) ++valid;

		return valid / total;
	}, triggers: ['firstName', 'lastName', 'position'] })
});

'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('ArgentinaProvinces', {
	'AR-C': {
		label: "Ciudad Autónoma de Buenos Aires",
		order: 1
	},
	'AR-B': {
		label: "Buenos Aires",
		order: 2
	},
	'AR-K': {
		label: "Catamarca",
		order: 3
	},
	'AR-H': {
		label: "Chaco",
		order: 4
	},
	'AR-U': {
		label: "Chubut",
		order: 5
	},
	'AR-X': {
		label: "Córdoba",
		order: 6
	},
	'AR-W': {
		label: "Corrientes",
		order: 7
	},
	'AR-E': {
		label: "Entre Ríos",
		order: 8
	},
	'AR-P': {
		label: "Formosa",
		order: 9
	},
	'AR-Y': {
		label: "Jujuy",
		order: 10
	},
	'AR-L': {
		label: "La Pampa",
		order: 11
	},
	'AR-F': {
		label: "La Rioja",
		order: 12
	},
	'AR-M': {
		label: "Mendoza",
		order: 13
	},
	'AR-N': {
		label: "Misiones",
		order: 14
	},
	'AR-Q': {
		label: "Neuquén",
		order: 15
	},
	'AR-R': {
		label: "Río Negro",
		order: 16
	},
	'AR-A': {
		label: "Salta",
		order: 17
	},
	'AR-J': {
		label: "San Juan",
		order: 18
	},
	'AR-D': {
		label: "San Luis",
		order: 19
	},
	'AR-Z': {
		label: "Santa Cruz",
		order: 20
	},
	'AR-S': {
		label: "Santa Fe",
		order: 21
	},
	'AR-G': {
		label: "Santiago del Estero",
		order: 22
	},
	'AR-V': {
		label: "Tierra del Fuego",
		order: 23
	},
	'AR-T': {
		label: "Tucumán",
		order: 24
	}
});

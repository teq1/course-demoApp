'use strict';

var Db                = require('dbjs')
  , User              = require('./base')
  , PickupInstitution = require('../pickup-institution');

User.prototype.setProperties({
	pickupInstitution: PickupInstitution.rel({ required: true,
		label: "Lugar de retiro" }),
	submitted: Db.Boolean
});

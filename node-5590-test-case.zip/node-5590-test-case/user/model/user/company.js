'use strict';

var Db          = require('dbjs')
  , UInteger    = require('dbjs-ext/number/integer/u-integer')
  , StringLine  = require('dbjs-ext/string/string-line')
  , CompanyType = require('../company-type')
  , User        = require('./base')

  , user = User.prototype;

user.setProperties({
	companyType: CompanyType.rel({ required: true, tags: ['company'],
		label: "Tipo de sociedad", order: -3 }),
	companyName: StringLine.rel({ required: true, tags: ['company'],
		label: "Razón social", order: -2 }),
	cuit: StringLine.rel({ required: true, tags: ['company'], label: "CUIT",
		order: -1 }),
	companyLegalAddress: Db.String.rel({ tags: ['company'],
		label: "Domicilio legal", order: 0 }),
	employeesCount: UInteger.rel({ tags: ['company'],
		label: "Cantidad de empleados", order: 2 })
});

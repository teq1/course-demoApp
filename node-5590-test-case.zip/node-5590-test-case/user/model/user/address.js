'use strict';

var address = require('../address')
  , User    = require('./base');

User.prototype.setProperties(address({ tag: 'address' }));

module.exports = User;

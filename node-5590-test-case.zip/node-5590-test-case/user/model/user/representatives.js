'use strict';

var User                  = require('./base')
  , CompanyRepresentative = require('../company-representative');

User.prototype.setProperties({
	representatives: CompanyRepresentative.rel({ multiple: true,
		label: "Autorización de firmas" })
});

'use strict';

var Db         = require('dbjs')
  , Percentage = require('dbjs-ext/number/percentage')
  , UInteger   = require('dbjs-ext/number/integer/u-integer')
  , StringLine = require('dbjs-ext/string/string-line')
  , User       = require('./base');

require('./partners');

User.prototype.setProperties({
	requiredDocumentsPrognosis: StringLine.rel({ value: function () {
		// IMPORTANT: This function must work in legacy engines
		var docs;

		docs = ['sanitaryCertification', 'taxRegistrationCard',
			'waterReceipt', 'provinceRegistration', 'identityDocument'];

		if (!this.isTrainServiceBuilding) docs.push('debtProof');

		if ((this.surfaceTrade < 100) || this.isTrainServiceBuilding) {
			docs.push('shopPlan');
		}

		if ((this.surfaceTrade >= 100) && !this.isTrainServiceBuilding) {
			docs.push('proShopPlan');
		}

		if (this.isInShoppingMall) docs.push('mallRegistration');

		if (this.isTrainServiceBuilding) {
			if (this.isLocalOwner) docs.push('storeDeed');
			else docs.push('storeLease');
		} else {
			if (this.isLocalOwner) docs.push('storeDeedCert');
			else docs.push('storeLeaseCert');
		}

		if ((this.legalForm === 'company') ||
				(this.legalForm === 'companyDeFacto')) {
			docs.push('inventoryCertified');
			docs.push('credentialEnrollment');
			docs.push('payroll');
			docs.push('socialStatusTestimony');
		} else if (this.inventoryValue < 8000) {
			docs.push('inventory');
		} else {
			docs.push('inventoryCertified');
		}

		if (this.isCondominium) docs.push('ownershipRegulation');
		return docs;
	}, multiple: true, triggers: ['inventoryValue', 'isCondominium',
		 'isLocalOwner', 'isInShoppingMall', 'isTrainServiceBuilding',
		 'legalForm', 'surfaceTrade'] }),

	guideStatus: Db.Boolean.rel({ value: function () {
		if (!this.legalForm || !this.businessActivities.count ||
				!this.surfaceTrade || !this.inventoryValue) {
			return false;
		}
		if (this.isLocalOwner == null) return false;
		return true;
	}, triggers: ['legalForm', 'businessActivities', 'surfaceTrade',
		 'inventoryValue', 'isLocalOwner'] }),

	personalStatus: Percentage.rel({ value: function () {
		var total = 0, valid = 0;
		++total;
		if (this.firstName != null) ++valid;
		++total;
		if (this.lastName != null) ++valid;
		++total;
		if (this.idDocument != null) ++valid;
		++total;
		if (this.idNumber != null) ++valid;

		return valid / total;
	}, triggers: ['firstName', 'lastName', 'idDocument',
		 'idNumber', 'passportNumber'] }),

	addressStatus: Percentage.rel({ value: function () {
		var total = 0, valid = 0;
		++total;
		if (this.street != null) ++valid;
		++total;
		if (this.houseNumber != null) ++valid;
		++total;
		if (this.department != null) ++valid;
		++total;
		if (this.city != null) ++valid;

		return valid / total;
	}, triggers: ['street', 'houseNumber', 'department',
		 'city'] }),

	partnersStatus: Percentage.rel({ value: function () {
		var total = 0, valid = 0, partners = this.partners;
		if (!partners) return 1;
		partners.forEach(function (partner) {
			if (!partner.$statusObserve) {
				partner._personalStatus.on('change',
					this._partnersStatus._update_);
				partner._addressStatus.on('change',
					this._partnersStatus._update_);
				partner.$statusObserve = true;
			}
			++total;
			if ((partner.personalStatus === 1) && (partner.addressStatus === 1)) {
				++valid;
			}
		}, this);
		return total ? (valid / total) : 1;
	}, triggers: ['partners'] }),

	representativesStatus: Percentage.rel({ value: function () {
		var total = 0, valid = 0, representatives = this.representatives;
		if (!representatives) return 1;
		representatives.forEach(function (representative) {
			if (!representative.$statusObserve) {
				representative._status.on('change',
					this._representativesStatus._update_);
				representative.$statusObserve = true;
			}
			++total;
			if (representative.status === 1) ++valid;
		}, this);
		return total ? (valid / total) : 1;
	}, triggers: ['representatives'] }),

	businessAddressStatus: Percentage.rel({ value: function () {
		var total = 0, valid = 0;

		++total;
		if (this.businessCity != null) ++valid;
		++total;
		if (this.businessStreet != null) ++valid;
		++total;
		if (this.businessHouseNumber != null) ++valid;
		++total;
		if (this.businessRegister != null) ++valid;

		return valid / total;
	}, triggers: ['businessCity', 'businessStreet', 'businessHouseNumber',
		 'businessRegister'] }),

	companyStatus: Percentage.rel({ value: function () {
		var total = 0, valid = 0;

		++total;
		if (this.companyType != null) ++valid;
		++total;
		if (this.companyName != null) ++valid;
		++total;
		if (this.cuit != null) ++valid;

		return valid / total;
	}, triggers: ['companyType', 'companyName', 'cuit'] }),

	dataStatus: Percentage.rel({ value: function () {
		var total, valid;
		if (!this.guideStatus) return 0;

		total = valid = 0;
		++total;
		valid += this.personalStatus;
		if (this.legalForm === 'company') {
			++total;
			valid += this.representativesStatus;
			++total;
			valid += this.companyStatus;
		} else if (this.legalForm === 'companyDeFacto') {
			++total;
			valid += this.representativesStatus;
			++total;
			valid += this.companyStatus;
			++total;
			valid += this.partnersStatus;
		} else {
			++total;
			valid += this.addressStatus;
			++total;
			valid += this.partnersStatus;
		}
		++total;
		valid += this.businessAddressStatus;

		return valid / total;
	}, triggers: ['guideStatus', 'legalForm', 'personalStatus', 'addressStatus',
		 'partnersStatus', 'companyStatus', 'representativesStatus',
		 'businessAddressStatus'] }),

	requiredDocuments: Db.StringLine.rel({ multiple: true, value: function () {
		var i, result = this.requiredDocumentsPrognosis;
		if (!result) return [];
		result = result.values;
		i = result.indexOf('payroll');
		if (i !== -1) {
			result.splice(i, 1);
			if (this.companyRepresentation === 'baCounter') {
				result.push('payrollByCouncil');
			} else if (this.companyRepresentation === 'manager') {
				result.push('payrollByManagers');
			}
		}
		return result;
	}, triggers: ['requiredDocumentsPrognosis', 'companyRepresentation'] }),

	requiredSubmissions: Db.StringLine.rel({ multiple: true, value: function () {
		var result = [], docs = this.requiredDocuments;
		if (!docs) return result;
		docs.forEach(function (name) {
			var doc;
			if (name.slice(-('Choice'.length)) === 'Choice') {
				doc = this[name];
				if (doc) result.push(doc);
				return;
			}
			result.push(name);
		}, this);
		return result;
	}, triggers: ['requiredDocuments', 'storeDocumentChoice',
		 'storeDocumentCertChoice'] }),

	documentsStatus: Percentage.rel({ value: function () {
		var total, valid, subs;
		if (!this.guideStatus) return 0;

		total = valid = 0;
		subs = this.requiredSubmissions;
		if (!subs || !subs.count) return 0;
		subs.forEach(function (name) {
			var rel, sub, files;
			name += 'Submission';
			++total;
			sub = this[name];
			rel = this.get(name);
			if (!sub) {
				if (!rel.hasOwnProperty('$statusObserve')) {
					rel.on('change', this._documentsStatus._update_);
					rel.$statusObserve = true;
				}
				return;
			}
			if (rel.$statusObserve) {
				rel.off('change', this._documentsStatus._update_);
				delete rel.$statusObserve;
			}
			files = sub._files;
			if (!sub.$statusObserve) {
				files.on('add', this._documentsStatus._update_);
				files.on('delete', this._documentsStatus._update_);
				files.on('change', this._documentsStatus._update_);
				sub.$statusObserve = true;
			}
			if (files._isSet_ && files.count) ++valid;
		}, this);
		return valid / total;
	}, triggers: ['guideStatus', 'requiredSubmissions'] }),

	submissionStatus: Percentage.rel({ value: function () {
		var total, valid;
		if (!this.guideStatus) return 0;

		total = valid = 0;
		++total;
		if (this.pickupInstitution != null) ++valid;

		return valid / total;
	}, triggers: ['guideStatus', 'pickupInstitution'] }),

	applicationStatus: Db.Boolean.rel({ value: function () {
		return (this.dataStatus === 1) && (this.documentsStatus === 1) &&
			(this.submissionStatus === 1);
	}, triggers: ['dataStatus', 'documentsStatus', 'submissionStatus'] }),

	certifiedTruth: Db.Boolean.rel({ required: true }),

	applicationSubmissionStatus: Db.Boolean.rel({ value: function () {
		return this.applicationStatus && this.certifiedTruth && this.submitted;
	}, triggers: ['applicationStatus', 'certifiedTruth', 'submitted'] }),

	applicationNumber: StringLine.rel({
		pattern: /^4068-(\d{5})-[\u0009 -\u2027\u2030-\uffff]-\d{4}$/
	}),
	applicationNumberNumber: UInteger.rel({ value: function () {
		var aNum = this.applicationNumber, match;
		if (aNum == null) return null;
		match = aNum.match(this.ns.prototype._applicationNumber.pattern);
		return match ? match[1] : null;
	} }),

	isApplicationRegistered: Db.Boolean.rel({ value: function () {
		return Boolean(this.applicationSubmissionStatus && this.applicationNumber);
	}, triggers: ['applicationSubmissionStatus', 'applicationNumber'] })
});

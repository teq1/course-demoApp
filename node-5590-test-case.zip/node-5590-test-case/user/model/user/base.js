'use strict';

var StringLine = require('dbjs-ext/string/string-line')
  , User       = require('../../../public/model/user')

  , user = User.prototype;

user.set('fullName', StringLine.rel({
	value: function () { return this.firstName + ' ' + this.lastName; },
	triggers: ['firstName', 'lastName']
}));

user._firstName.tags.add('profile');
user._lastName.tags.add('profile');

module.exports = User;

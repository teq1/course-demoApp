'use strict';

var Db          = require('dbjs')
  , StringLine  = require('dbjs-ext/string/string-line')
  , LomasCities = require('../lomas-cities')
  , User        = require('./base')

  , user = User.prototype;

user.setProperties({
	businessCity: LomasCities.rel({ required: true, tags: 'business-address',
		label: "Localidad", order: 401 }),
	businessStreet: StringLine.rel({ required: true, tags: 'business-address',
		label: "Calle", order: 402 }),
	businessHouseNumber: StringLine.rel({ required: true,
		tags: 'business-address', label: "Número de casa", order: 403 }),
	businessPerpStreets: StringLine.rel({ tags: 'business-address',
		value: function () {
			return this.businessPerpStreet1 + ' y ' + this.businessPerpStreet2;
		}, label: "Entre calles", order: 404,
		triggers: ['businessPerpStreet1', 'businessPerpStreet2'] }),
	businessPerpStreet1: StringLine.rel({ label: "Calle perpendicular 1",
		order: 404.2 }),
	businessPerpStreet2: StringLine.rel({ label: "Calle perpendicular 2",
		order: 404.4 }),

	businessLocal: StringLine.rel({ tags: 'business-address', label: "Local",
		order: 405 }),
	businessFloor: StringLine.rel({ tags: 'business-address', label: "Piso",
		order: 406 }),
	businessRegister: StringLine.rel({ tags: 'business-address', required: true,
		label: "Padrón / cuenta", order: 407, pattern: /^\d{8}$/,
		inputMask: '88888888', inputHint: "sin barra" }),

	businessPhone: StringLine.rel({ tags: 'business-address',
		label: "Número de teléfono", order: 408 }),

	businessNomenclature: StringLine.rel({ label: "Nomenclatura catastral",
		tags: 'business-address', value: function () {
		return (this.businessCirc || '   ') + (this.businessSection || '  ') +
			(this.businessDivision || '   ') + (this.businessDivisionLetter || ' ') +
			(this.businessBlock || '    ') + (this.businessBlockLetter || '   ') +
			(this.businessPlot || '        ') + (this.businessPlotLetter || '   ') +
			(this.businessPolygon || '     ') + (this.businessUF || '    ') +
			(this.businessUC || '   ');
	}, triggers: ['businessCirc', 'businessSection', 'businessDivision',
			 'businessDivisionLetter', 'businessBlock', 'businessBlockLetter',
			 'businessPlot', 'businessPlotLetter', 'businessPolygon', 'businessUF',
			 'businessUC'], order: 409 }),
	businessCirc: StringLine.rel({ label: "Circ.", order: 408,
		pattern: /^\w{3}$/, inputMask: 'XXX' }),
	businessSection: StringLine.rel({ label: "Secc.", order: 409,
		pattern: /^\w{2}$/, inputMask: 'XX' }),
	businessDivision: StringLine.rel({ label: "Fracc.", order: 410,
		pattern: /^\w{3}$/, inputMask: 'XXX' }),
	businessDivisionLetter: StringLine.rel({ label: "Letra fracc.", order: 411,
		pattern: /^\w{1}$/, inputMask: 'X' }),
	businessBlock: StringLine.rel({ label: "Manz.", order: 412,
		pattern: /^\w{4}$/, inputMask: 'XXXX' }),
	businessBlockLetter: StringLine.rel({ label: "Letra manz.", order: 413,
		pattern: /^\w{3}$/, inputMask: 'XXX' }),
	businessPlot: StringLine.rel({ label: "Parc.", order: 414,
		pattern: /^\w{8}$/, inputMask: 'XXXXXXXX' }),
	businessPlotLetter: StringLine.rel({ label: "Letra parcela", order: 415,
		pattern: /^\w{3}$/, inputMask: 'XXX' }),
	businessPolygon: StringLine.rel({ label: "Pol.", order: 416,
		pattern: /^\w{5}$/, inputMask: 'XXXXX' }),
	businessUF: StringLine.rel({ label: "U.F.", order: 417, pattern: /^\w{4}$/,
		inputMask: 'XXXX' }),
	businessUC: StringLine.rel({ label: "U.C.", order: 418, pattern: /^\w{3}$/,
		inputMask: 'XXX' }),

	businessAddressProperties: Db.Base.rel({ multiple: true, value: function () {
		var data = this.getProperties('business-address').values, index;
		if ((this.legalForm !== 'company') &&
				(this.legalForm !== 'companyDeFacto')) {
			index = data.indexOf(this._businessPhone);
			if (index === -1) throw new Error("Relation not found");
			data.splice(index, 1);
		}
		if (!this.isInShoppingMall) {
			index = data.indexOf(this._businessLocal);
			if (index === -1) throw new Error("Relation not found");
			data.splice(index, 1);
		}
		if (!this.isCondominium) {
			index = data.indexOf(this._businessFloor);
			if (index === -1) throw new Error("Relation not found");
			data.splice(index, 1);
		}
		return data;
	}, triggers: ['legalForm', 'isCondominium', 'isInShoppingMall'] })

});

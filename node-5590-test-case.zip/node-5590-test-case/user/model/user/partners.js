'use strict';

var User = require('./base');

User.prototype.set('partners', User.rel({ multiple: true }));

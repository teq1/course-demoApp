'use strict';

var Db           = require('dbjs')
  , StringLine   = require('dbjs-ext/string/string-line')
  , User         = require('./base')

  , user = User.prototype;

user.setProperties({
	phone: StringLine.rel({ tags: 'business', label: "Número de telefóno",
		order: 510 }),
	employeesCount: Db.Number.rel({ tags: 'business',
		label: "Cantidad de empleados", order: 520 })
});

'use strict';

var Db = require('dbjs')

  , now = Date.now
  , activities = Db.BusinessActivity._options
  , zones = Db.Zone._options
  , user = Db.User.prototype, rel, define, activityCalc, time;

time = now();
// Set activities property on each zone item
rel = zones._itemPrototype_.get('activities');
rel._ns.$$setValue(Db.BusinessActivity);
rel._multiple.$$setValue(true);

// Reset activities list for each zone (so it's empty and doesn't inherit from
// list below the prototype chain)
zones._forEachItem_(function (zoneItem) {
	zoneItem._activities.$$setValue(null);
});

// Iterate over each activity and within iterate over each zone to check
// whether activity applies to that zone.
activities._forEachItem_(function (activityItem) {
	var aZonesSet, activity;
	if (!activityItem.value) return;
	aZonesSet = activityItem._zones;
	activity = activityItem._subject_;
	zones._forEachItem_(function (zoneItem) {
		var zone = zoneItem._subject_, aZoneItem = aZonesSet.getItem(zone)
		  , zActivityItem = zoneItem._activities.getItem(activity), onChange;
		aZoneItem._forbidden.on('change', onChange = function (value) {
			zActivityItem.$$setValue(!value);
		});
		onChange(aZoneItem.forbidden);
	});
});
console.log("Zones calculation:", ((now() - time) / 1000).toFixed(3) + 's');

activityCalc = function (calc) {
	var observers = {};
	return function () {
		var clear = [], observer = observers[this._id_], result;
		if (observer) {
			observer();
			delete observers[this._id_];
		}
		result = calc.call(this, clear);
		if (clear.length) {
			observers[this._id_] = function () {
				while (clear[0]) clear.shift()();
			};
		}
		return result;
	};
};

// time = now();
user.get('validBusinessActivities').$$setValue((function () {
	var observers = {};
	return function () {
		var zActivities, update, observer = observers[this._id_];
		if (observer) {
			observer();
			delete observers[this._id_];
		}
		if (!this.locationZone) return this.businessActivities;
		zActivities = zones.getItem(this.locationZone).get('activities');
		update = this._validBusinessActivities._update_;
		zActivities.on('add', update);
		zActivities.on('delete', update);
		observers[this._id_] = function () {
			zActivities.off('add', update);
			zActivities.off('delete', update);
		};
		return this.businessActivities.values.filter(function (activity) {
			return zActivities.has(activity);
		});
	};
}()));
// console.log("Calc: business activities", now() - time);

define = function (name) {
	var rel;
	rel = user.get(name + 'BySchema');
	rel._ns.$$setValue(Db.Boolean);
	rel._triggers.$$setValue(null);
	rel._triggers.getItem('validBusinessActivities').$$setValue(true);
	rel.$$setValue(activityCalc(function (clear) {
		var result = 0;
		this.validBusinessActivities.forEach(function (activity) {
			var rel = activities.getItem(activity).get(name)
			  , value = rel.value, userRel = user.get(name + 'BySchema');
			rel.on('change', userRel._update_);
			clear.push(rel.off.bind(rel, 'change', userRel._update_));
			if (value === 'ask') value = 1;
			else if (value === 'yes') value = 2;
			if (value > result) (result = value);
		}, this);
		if (!result) return false;
		if (result === 1) return null;
		return true;
	}));

	rel = user.get(name + 'Resolved');
	rel._ns.$$setValue(Db.Boolean);
	rel._triggers.$$setValue(null);
	rel._triggers.getItem(name).$$setValue(true);
	rel._triggers.getItem(name + 'BySchema').$$setValue(true);
	rel.$$setValue(function () {
		var bySchema = this[name + 'BySchema'];
		if (bySchema != null) return bySchema;
		return this[name];
	});
};
// time = now();
user.getPropertyNames('rule').forEach(define);
// console.log("Calc: rules", now() - time);

// time = now();
user.get('maxPossibleSurfaceTrade').$$setValue(activityCalc(function (clear) {
	var value, zone, update;
	value = Infinity;
	zone = this.locationZone;
	if (!zone) return value;
	update = this._maxPossibleSurfaceTrade._update_;
	this.validBusinessActivities.forEach(function (activity) {
		var val, rel;
		rel = activities.getItem(activity)._zones.getItem(zone)._surfaceMax;
		rel.on('change', update);
		clear.push(rel.off.bind(rel, 'change', update));
		val = rel.value;
		if (value > val) value = val;
	});
	return value;
}));
// console.log("Calc: max surface", now() - time);

// time = now();
user.get('minPossibleSurfaceTrade').$$setValue(activityCalc(function (clear) {
	var value, zone, update;
	value = 1;
	zone = this.locationZone;
	if (!zone) return value;
	update = this._minPossibleSurfaceTrade._update_;
	this.validBusinessActivities.forEach(function (activity) {
		var val, rel;
		rel = activities.getItem(activity)._zones.getItem(zone)._surfaceMin;
		rel.on('change', update);
		clear.push(rel.off.bind(rel, 'change', update));
		val = rel.value;
		if (value < val) value = val;
	});
	return value;
}));
// console.log("Calc: min surface", now() - time);

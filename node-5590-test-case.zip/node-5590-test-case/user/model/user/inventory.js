'use strict';

var Db         = require('dbjs')
  , StringLine = require('dbjs-ext/string/string-line')
  , Peso       = require('../ui-argentine-peso')
  , User       = require('./base')

  , user = User.prototype, InventoryValue;

InventoryValue = Db.create('InventoryValue', {
	description: StringLine,
	value: Peso
});

user.setProperties({
	inventoryShelves: InventoryValue.rel({ multiple: true, tags: 'inventory',
		order: 1, label: "Estanterías", inputPlaceholder: "Estantería #1",
		description: "Agregar líneas necesarias y mencionar el costo de origen de" +
		" cada elemento. Dejar vacío si no hay elemento." }),
	inventoryCounters: InventoryValue.rel({ multiple: true, tags: 'inventory',
		order: 2, label: "Mostradores",
		inputPlaceholder: "Mostrador #1",
		description: "Agregar líneas necesarias y mencionar el costo de origen de" +
		" cada elemento. Dejar vacío si no hay elemento.",
		addLabel: "Agregar mostrador" }),
	inventoryChairs: InventoryValue.rel({ multiple: true, tags: 'inventory',
		order: 3, label: "Sillas", inputPlaceholder: "Silla #1",
		description: "Agregar líneas necesarias y mencionar el costo de origen de" +
		" cada elemento. Dejar vacío si no hay elemento.",
		addLabel: "Agregar silla" }),
	inventoryRefridgerators: InventoryValue.rel({ multiple: true,
		tags: 'inventory', order: 4, label: "Heladeras",
		inputPlaceholder: "Heladera #1", description: "Agregar líneas necesarias" +
		" y mencionar el costo de origen de cada elemento. Dejar vacío si no hay" +
		" elemento.", addLabel: "Agregar heladera"  }),
	inventoryScales: InventoryValue.rel({ multiple: true, tags: 'inventory',
		order: 5, label: "Balanzas", inputPlaceholder: "Balanza #1",
		description: "Agregar líneas necesarias y mencionar el costo de origen de" +
		" cada elemento. Dejar vacío si no hay elemento.",
		addLabel: "Agregar balanza" }),
	inventoryMachinery: InventoryValue.rel({ multiple: true, tags: 'inventory',
		order: 6, label: "Máquinas y herramientas", inputPlaceholder: "Máquina o" +
		" herramienta #1", description: "Agregar líneas necesarias y mencionar el" +
		" costo de origen de cada elemento. Dejar vacío si no hay elemento.",
		addLabel: "Agregar máquina o herramienta" }),
	inventoryOther: InventoryValue.rel({ multiple: true, tags: 'inventory',
		order: 6, label: "Otros", inputPlaceholder: "Otro #1",
		description: "Agregar líneas necesarias y mencionar el costo de origen de" +
		" cada elemento. Dejar vacío si no hay elemento.",
		addLabel: "Agregar otro" }),
	inventoryTotal: Peso.rel(function () {
		var total = 0, add;
		this.inventoryShelves.forEach(add = function (item) {
			if (item.value) total += item.value;
		});
		this.inventoryCounters.forEach(add);
		this.inventoryChairs.forEach(add);
		this.inventoryRefridgerators.forEach(add);
		this.inventoryScales.forEach(add);
		this.inventoryMachinery.forEach(add);
		this.inventoryOther.forEach(add);
		return total;
	})
});

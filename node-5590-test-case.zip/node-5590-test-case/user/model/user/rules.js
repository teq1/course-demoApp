'use strict';

var Db   = require('dbjs')
  , User = require('./base');

User.prototype.setProperties({
	// Rules
	isPublic: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Local abierto al público", order: 1 }),
	isPublicMassive: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Local con concurrencia masiva", order: 2 }),
	hasEmployees: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Hay personal trabajando en el local", order: 3 }),
	foodSaleApproved: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Venta de productos alimenticios previamente elaborados (y" +
		" aprobados)", order: 4 }),
	sellsPrimaryFood: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Venta de productos alimenticios primarios", order: 5 }),
	craftsFood: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Elaboración artesanal de comida con venta al mostrador",
		order: 6 }),
	hasFoodConsumption: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Preparación de comida y bebidas para consumo en el lugar",
		order: 7 }),
	sellsFractionedFood: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Fracciona o pesa alimentos", order: 8 }),
	sellsRedMeat: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Vende carne roja", order: 9 }),
	sellsWhiteMeat: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Vende carne blanca", order: 10 }),
	sellsAlcohol: Db.Boolean.rel({ required: true, tags: ['rule'],
		label: "Quiere vender bebidas alcohólicas", trueLabel: "Si",
		falseLabel: "No", order: 11 })
});

module.exports = User;

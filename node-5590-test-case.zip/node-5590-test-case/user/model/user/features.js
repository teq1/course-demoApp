'use strict';

var Db               = require('dbjs')
  , SquareMeters     = require('dbjs-ext/number/square-meters')
  , StringLine       = require('dbjs-ext/string/string-line')
  , ArgentinePeso    = require('../ui-argentine-peso')
  , LegalForm        = require('../legal-form')
  , Zone             = require('../zone')
  , ZonePolygon      = require('../zone-polygon')
  , User             = require('./rules')
// Needs to required after User
  , BusinessActivity = require('../business-activity');

User.prototype.setProperties({
	locationZonePolygon: ZonePolygon.rel({ required: true,
		label: "Dirección de su negocio ?" }),
	locationZone: Zone.rel({ value: function () {
		var polygon = this.locationZonePolygon;
		if (!polygon) return null;
		return this.Db.ZonePolygon.zoneMap[polygon];
	}, triggers: ['locationZonePolygon'] }),
	businessActivities: BusinessActivity.rel({ required: true,
		label: "Rubro de su negocio", multiple: true }),
	validBusinessActivities: BusinessActivity.rel({ required: true,
		label: "Rubro de su negocio", multiple: true, order: 1,
		value: function () { return this.businessActivities; },
		tags: ['business', 'company'],
		triggers: ['locationZone', 'businessActivities'] }),

	// Other characteristics
	surfaceTrade: SquareMeters.rel({ required: true, min: 1,
		label: "Superficie de su negocio" }),
	minPossibleSurfaceTrade: SquareMeters.rel({ required: true, min: 1,
		value: 1, triggers: ['locationZone', 'validBusinessActivities'] }),
	maxPossibleSurfaceTrade: SquareMeters.rel({ required: true, min: 1,
		value: Infinity, triggers: ['locationZone', 'validBusinessActivities'] }),
	validSurfaceTrade: SquareMeters.rel({ min: 1,
		label: "Superficie de su negocio", tags: ['business'],
		order: 580, value: function () {
		var current = this.surfaceTrade;
		if (current == null) return null;
		if (this.minPossibleSurfaceTrade > current) return null;
		if (this.maxPossibleSurfaceTrade < current) return null;
		return current;
	}, triggers: ['surfaceTrade', 'minPossibleSurfaceTrade',
		 'maxPossibleSurfaceTrade'] }),
	inventoryValue: ArgentinePeso.rel({ required: true, min: 1, step: 1,
		label: "Valor del inventario", order: 3 }),
	legalForm: LegalForm.rel({ required: true, label: "Tipo de empresa" }),
	isLocalOwner: Db.Boolean.rel({ required: true, tags: ['feature', 'business'],
		label: "Calidad de propiedad", trueLabel: "Propietario",
		falseLabel: "Inquilino", value: true, order: -1 }),
	isInShoppingMall: Db.Boolean.rel({ required: true,
		label: "una galería comercial", tags: 'feature',
		trueLabel: "Si", falseLabel: "No", order: 5 }),
	isTrainServiceBuilding: Db.Boolean.rel({ required: true,
		label: "un edificio afectado al servicio ferroviario", tags: 'feature',
		trueLabel: "Si", falseLabel: "No", order: 6 }),
	isCondominium: Db.Boolean.rel({ required: true,
		label: "una propiedad horizontal", tags: 'feature',
		trueLabel: "Si", falseLabel: "No", order: 7 }),
	hasStorage: Db.Boolean.rel({ required: true,
		label: "Su local contiene un entrepiso o un depósito.", tags: 'feature',
		trueLabel: "Si", falseLabel: "No", order: 8 }),

	businessGroup: StringLine.rel('C'),

	baseHabilitationCost: ArgentinePeso.rel({ value: function () {
		return this.inventoryValue ? (this.inventoryValue * 0.05) : 0;
	}, triggers: ['inventoryValue'] }),
	habilitationCost: ArgentinePeso.rel({ required: true,
		label: "Liquidación de habilitación (5% of inventario)",
		value: function () {
			var cost, group;
			cost = this.baseHabilitationCost;
			if (cost >= 458) return cost;
			if (!this.businessActivities.count) return cost;
			group = 'C';
			if ((group === 'A') || (group === 'B')) {
				if (cost >= 289) return cost;
				if (this.surfaceTrade >= 40) return 289;
				if (cost >= 167) return cost;
				if (this.surfaceTrade >= 20) return 167;
				return Math.max(cost, 112);
			}
			if ((group === 'C') || (group === 'D')) {
				if (this.surfaceTrade >= 40) return 458;
				if (cost >= 289) return cost;
				if (this.surfaceTrade >= 20) return 289;
				return Math.max(cost, 167);
			}
			return cost;
		}, triggers: ['baseHabilitationCost', 'businessActivities',
			 'surfaceTrade'] }),

	totalCost: ArgentinePeso.rel({ required: true,
		value: function () {
			return 13 + 40 + this.habilitationCost;
		}, triggers: 'habilitationCost' })
});

module.exports = User;

'use strict';

var Db                    = require('dbjs')
  , DateType              = require('dbjs-ext/date-time/date')
  , StringLine            = require('dbjs-ext/string/string-line')
  , Country               = require('../country')
  , IdDocument            = require('../id-document')
  , MaritalStatus         = require('../marital-status')
  , CompanyRepresentation = require('../company-representation')
  , User                  = require('./base')

  , user = User.prototype;

user._firstName.tags.add('personal');
user._lastName.tags.add('personal');

user.setProperties({
	idDocument: IdDocument.rel({ required: true,
		tags: 'personal', label: "Tipo de documento", order: 11 }),
	idNumber: StringLine.rel({ required: true, tags: 'personal',
		label: "Número de documento", pattern: /^\d{7,8}$/, inputMask: '8888888?8',
		order: 12 }),

	maritalStatus: MaritalStatus.rel({ tags: 'personal', label: "Estado civil",
		order: 14 }),
	birthDate: DateType.rel({ tags: 'personal', label: "Fecha de nacimiento",
		order: 15 }),
	nationality: Country.rel({ tags: 'personal', label: "Nacionalidad",
		order: 16 }),
	partnerName: StringLine.rel({ tags: 'personal',
		label: "Nombre y apellido del cónyuge", order: 17 }),

	companyPosition: StringLine.rel({ tags: 'personal',
		label: "Cargo en la sociedad", order: 14 }),
	companyRepresentation: CompanyRepresentation.rel({ tags: 'personal',
		label: "Caracter de representación", order: 15 }),

	personalPropertiesPre: Db.Base.rel({ multiple: true, value: function () {
		var data = this.getProperties('personal').values, index;
		if ((this.legalForm === 'company') ||
				(this.legalForm === 'companyDeFacto')) {
			index = data.indexOf(this._maritalStatus);
			if (index === -1) throw new Error("Relation not found");
			data.splice(index, 1);
			index = data.indexOf(this._birthDate);
			if (index === -1) throw new Error("Relation not found");
			data.splice(index, 1);
			index = data.indexOf(this._nationality);
			if (index === -1) throw new Error("Relation not found");
			data.splice(index, 1);
			index = data.indexOf(this._partnerName);
			if (index === -1) throw new Error("Relation not found");
			data.splice(index, 1);
		} else {
			index = data.indexOf(this._companyPosition);
			if (index === -1) throw new Error("Relation not found");
			data.splice(index, 1);
			index = data.indexOf(this._companyRepresentation);
			if (index === -1) throw new Error("Relation not found");
			data.splice(index, 1);
		}
		return data;
	}, triggers: ['legalForm'] }),

	personalProperties: Db.Base.rel({ multiple: true, value: function () {
		var data = this.personalPropertiesPre, index;
		if (!data) return [];
		data = data.values;
		if (this.legalForm === 'company') return data;
		if (this.legalForm === 'companyDeFacto') return data;
		if (this.maritalStatus !== 'married') {
			index = data.indexOf(this._partnerName);
			if (index === -1) throw new Error("Relation not found");
			data.splice(index, 1);
		}
		return data;
	}, triggers: ['personalPropertiesPre', 'legalForm', 'maritalStatus'] }),

	personalSectionTitle: StringLine.rel({ value: function () {
		if ((this.legalForm === 'company') ||
				(this.legalForm === 'companyDeFacto')) {
			return "Persona que hace el trámite de habilitación";
		}
		return "Datos personales";
	}, triggers: ['legalForm'] })
});

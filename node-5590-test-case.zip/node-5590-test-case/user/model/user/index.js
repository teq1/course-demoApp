'use strict';

var User = require('./base');

module.exports = User;

require('./features');
require('./inventory');

require('./personal');
require('./address');
require('./partners');
require('./business-address');
require('./business');

require('./company');
require('./representatives');

require('./submission');

require('./process');

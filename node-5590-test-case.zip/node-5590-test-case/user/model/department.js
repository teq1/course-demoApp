'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

var Department = module.exports = Enum.create('ArgentinaDepartment', {
	'buenos-aires-autonoma': {
		label: "Ciudad Autónoma de Buenos Aires",
		province: 'AR-C',
		order: 1
	},
	'adolfo-alsina-buenes-aires': {
		label: "Adolfo Alsina",
		province: 'AR-B',
		order: 2
	},
	'adolfo-gonzales-chaves': {
		label: "Adolfo Gonzales Chaves",
		province: 'AR-B',
		order: 3
	},
	'alberti': {
		label: "Alberti",
		province: 'AR-B',
		order: 4
	},
	'almirante-brown-buenos-aires': {
		label: "Almirante Brown",
		province: 'AR-B',
		order: 5
	},
	'arrecifes': {
		label: "Arrecifes",
		province: 'AR-B',
		order: 6
	},
	'avellaneda-buenos-aires': {
		label: "Avellaneda",
		province: 'AR-B',
		order: 7
	},
	'ayacucho': {
		label: "Ayacucho",
		province: 'AR-B',
		order: 8
	},
	'azul': {
		label: "Azul",
		province: 'AR-B',
		order: 9
	},
	'bahia-blanca': {
		label: "Bahía Blanca",
		province: 'AR-B',
		order: 10
	},
	'balcarce': {
		label: "Balcarce",
		province: 'AR-B',
		order: 11
	},
	'baradero': {
		label: "Baradero",
		province: 'AR-B',
		order: 12
	},
	'benito-juarez': {
		label: "Benito Juárez",
		province: 'AR-B',
		order: 13
	},
	'berazategui': {
		label: "Berazategui",
		province: 'AR-B',
		order: 14
	},
	'berisso': {
		label: "Berisso",
		province: 'AR-B',
		order: 15
	},
	'bolivar': {
		label: "Bolívar",
		province: 'AR-B',
		order: 16
	},
	'bragado': {
		label: "Bragado",
		province: 'AR-B',
		order: 17
	},
	'brandsen': {
		label: "Brandsen",
		province: 'AR-B',
		order: 18
	},
	'campana': {
		label: "Campana",
		province: 'AR-B',
		order: 19
	},
	'canuelas': {
		label: "Cañuelas",
		province: 'AR-B',
		order: 20
	},
	'capitan-sarmiento': {
		label: "Capitán Sarmiento",
		province: 'AR-B',
		order: 21
	},
	'carlos-casares': {
		label: "Carlos Casares",
		province: 'AR-B',
		order: 22
	},
	'carlos-tejedor': {
		label: "Carlos Tejedor",
		province: 'AR-B',
		order: 23
	},
	'carmen-de-areco': {
		label: "Carmen de Areco",
		province: 'AR-B',
		order: 24
	},
	'castelli': {
		label: "Castelli",
		province: 'AR-B',
		order: 25
	},
	'chacabuco': {
		label: "Chacabuco",
		province: 'AR-B',
		order: 26
	},
	'chascomus': {
		label: "Chascomús",
		province: 'AR-B',
		order: 27
	},
	'chivilcoy': {
		label: "Chivilcoy",
		province: 'AR-B',
		order: 28
	},
	'colon': {
		label: "Colón",
		province: 'AR-B',
		order: 29
	},
	'coronel-dorrego': {
		label: "Coronel Dorrego",
		province: 'AR-B',
		order: 30
	},
	'coronel-pringles-buenos-aires': {
		label: "Coronel Pringles",
		province: 'AR-B',
		order: 31
	},
	'coronel-rosales': {
		label: "Coronel Rosales",
		province: 'AR-B',
		order: 32
	},
	'coronel-suarez': {
		label: "Coronel Suárez",
		province: 'AR-B',
		order: 33
	},
	'daireaux': {
		label: "Daireaux",
		province: 'AR-B',
		order: 34
	},
	'dolores': {
		label: "Dolores",
		province: 'AR-B',
		order: 35
	},
	'ensenada': {
		label: "Ensenada",
		province: 'AR-B',
		order: 36
	},
	'escobar': {
		label: "Escobar",
		province: 'AR-B',
		order: 37
	},
	'esteban-echeverria': {
		label: "Esteban Echeverría",
		province: 'AR-B',
		order: 38
	},
	'exaltacion-de-la-cruz': {
		label: "Exaltación de la Cruz",
		province: 'AR-B',
		order: 39
	},
	'ezeiza': {
		label: "Ezeiza",
		province: 'AR-B',
		order: 40
	},
	'florencio-varela': {
		label: "Florencio Varela",
		province: 'AR-B',
		order: 41
	},
	'florentino-ameghino-buenos-aires': {
		label: "Florentino Ameghino",
		province: 'AR-B',
		order: 42
	},
	'general-alvarado': {
		label: "General Alvarado",
		province: 'AR-B',
		order: 43
	},
	'general-alvear': {
		label: "General Alvear",
		province: 'AR-B',
		order: 44
	},
	'general-arenales': {
		label: "General Arenales",
		province: 'AR-B',
		order: 45
	},
	'general-belgrano': {
		label: "General Belgrano",
		province: 'AR-B',
		order: 46
	},
	'general-guido': {
		label: "General Guido",
		province: 'AR-B',
		order: 47
	},
	'general-juan-madariaga': {
		label: "General Juan Madariaga",
		province: 'AR-B',
		order: 48
	},
	'general-la-madrid': {
		label: "General La Madrid",
		province: 'AR-B',
		order: 49
	},
	'general-las-heras': {
		label: "General Las Heras",
		province: 'AR-B',
		order: 50
	},
	'general-lavalle': {
		label: "General Lavalle",
		province: 'AR-B',
		order: 51
	},
	'general-paz-buenos-aires': {
		label: "General Paz",
		province: 'AR-B',
		order: 52
	},
	'general-pinto': {
		label: "General Pinto",
		province: 'AR-B',
		order: 53
	},
	'general-pueyrredon': {
		label: "General Pueyrredón",
		province: 'AR-B',
		order: 54
	},
	'general-rodriguez': {
		label: "General Rodríguez",
		province: 'AR-B',
		order: 55
	},
	'general-san-martin-buenos-aires': {
		label: "General San Martín",
		province: 'AR-B',
		order: 56
	},
	'general-viamonte': {
		label: "General Viamonte",
		province: 'AR-B',
		order: 57
	},
	'general-villegas': {
		label: "General Villegas",
		province: 'AR-B',
		order: 58
	},
	'guamini': {
		label: "Guaminí",
		province: 'AR-B',
		order: 59
	},
	'hipolito-yrigoyen': {
		label: "Hipólito Yrigoyen",
		province: 'AR-B',
		order: 60
	},
	'hurlingham': {
		label: "Hurlingham",
		province: 'AR-B',
		order: 61
	},
	'ituzaingo-buenos-aires': {
		label: "Ituzaingó",
		province: 'AR-B',
		order: 62
	},
	'jose-c-paz': {
		label: "José C. Paz",
		province: 'AR-B',
		order: 63
	},
	'junin': {
		label: "Junín",
		province: 'AR-B',
		order: 64
	},
	'la-costa': {
		label: "La Costa",
		province: 'AR-B',
		order: 65
	},
	'la-matanza': {
		label: "La Matanza",
		province: 'AR-B',
		order: 66
	},
	'la-plata': {
		label: "La Plata",
		province: 'AR-B',
		order: 67
	},
	'lanus': {
		label: "Lanús",
		province: 'AR-B',
		order: 68
	},
	'laprida': {
		label: "Laprida",
		province: 'AR-B',
		order: 69
	},
	'las-flores': {
		label: "Las Flores",
		province: 'AR-B',
		order: 70
	},
	'leandro-n-alem-buenos-aires': {
		label: "Leandro N. Alem",
		province: 'AR-B',
		order: 71
	},
	'lezama': {
		label: "Lezama",
		province: 'AR-B',
		order: 72
	},
	'lincoln': {
		label: "Lincoln",
		province: 'AR-B',
		order: 73
	},
	'loberia': {
		label: "Lobería",
		province: 'AR-B',
		order: 74
	},
	'lobos': {
		label: "Lobos",
		province: 'AR-B',
		order: 75
	},
	'lomas-de-zamora': {
		label: "Lomas de Zamora",
		province: 'AR-B',
		order: 76
	},
	'lujan': {
		label: "Luján",
		province: 'AR-B',
		order: 77
	},
	'magdalena': {
		label: "Magdalena",
		province: 'AR-B',
		order: 78
	},
	'maipu': {
		label: "Maipú",
		province: 'AR-B',
		order: 79
	},
	'malvinas-argentinas': {
		label: "Malvinas Argentinas",
		province: 'AR-B',
		order: 80
	},
	'mar-chiquita': {
		label: "Mar Chiquita",
		province: 'AR-B',
		order: 81
	},
	'marcos-paz': {
		label: "Marcos Paz",
		province: 'AR-B',
		order: 82
	},
	'mercedes-buenos-aires': {
		label: "Mercedes",
		province: 'AR-B',
		order: 83
	},
	'merlo': {
		label: "Merlo",
		province: 'AR-B',
		order: 84
	},
	'monte': {
		label: "Monte",
		province: 'AR-B',
		order: 85
	},
	'monte-hermoso': {
		label: "Monte Hermoso",
		province: 'AR-B',
		order: 86
	},
	'moreno-buenos-aires': {
		label: "Moreno",
		province: 'AR-B',
		order: 87
	},
	'moron': {
		label: "Morón",
		province: 'AR-B',
		order: 88
	},
	'navarro': {
		label: "Navarro",
		province: 'AR-B',
		order: 89
	},
	'necochea': {
		label: "Necochea",
		province: 'AR-B',
		order: 90
	},
	'nueve-de-julio': {
		label: "Nueve de Julio",
		province: 'AR-B',
		order: 91
	},
	'olavarria': {
		label: "Olavarría",
		province: 'AR-B',
		order: 92
	},
	'patagones': {
		label: "Patagones",
		province: 'AR-B',
		order: 93
	},
	'pehuajo': {
		label: "Pehuajó",
		province: 'AR-B',
		order: 94
	},
	'pellegrini-buenos-aires': {
		label: "Pellegrini",
		province: 'AR-B',
		order: 95
	},
	'pergamino': {
		label: "Pergamino",
		province: 'AR-B',
		order: 96
	},
	'pila': {
		label: "Pila",
		province: 'AR-B',
		order: 97
	},
	'pilar': {
		label: "Pilar",
		province: 'AR-B',
		order: 98
	},
	'pinamar': {
		label: "Pinamar",
		province: 'AR-B',
		order: 99
	},
	'presidente-peron': {
		label: "Presidente Perón",
		province: 'AR-B',
		order: 100
	},
	'puan': {
		label: "Puan",
		province: 'AR-B',
		order: 101
	},
	'punta-indio': {
		label: "Punta Indio",
		province: 'AR-B',
		order: 102
	},
	'quilmes': {
		label: "Quilmes",
		province: 'AR-B',
		order: 103
	},
	'ramallo': {
		label: "Ramallo",
		province: 'AR-B',
		order: 104
	},
	'rauch': {
		label: "Rauch",
		province: 'AR-B',
		order: 105
	},
	'rivadavia': {
		label: "Rivadavia",
		province: 'AR-B',
		order: 106
	},
	'rojas': {
		label: "Rojas",
		province: 'AR-B',
		order: 107
	},
	'roque-perez': {
		label: "Roque Pérez",
		province: 'AR-B',
		order: 108
	},
	'saavedra': {
		label: "Saavedra",
		province: 'AR-B',
		order: 109
	},
	'saladillo': {
		label: "Saladillo",
		province: 'AR-B',
		order: 110
	},
	'salliquelo': {
		label: "Salliqueló",
		province: 'AR-B',
		order: 111
	},
	'salto': {
		label: "Salto",
		province: 'AR-B',
		order: 112
	},
	'san-andres-de-giles': {
		label: "San Andrés de Giles",
		province: 'AR-B',
		order: 113
	},
	'san-antonio-de-areco': {
		label: "San Antonio de Areco",
		province: 'AR-B',
		order: 114
	},
	'san-cayetano': {
		label: "San Cayetano",
		province: 'AR-B',
		order: 115
	},
	'san-fernando-buenos-aires': {
		label: "San Fernando",
		province: 'AR-B',
		order: 116
	},
	'san-isidro': {
		label: "San Isidro",
		province: 'AR-B',
		order: 117
	},
	'san-miguel': {
		label: "San Miguel",
		province: 'AR-B',
		order: 118
	},
	'san-nicolas': {
		label: "San Nicolás",
		province: 'AR-B',
		order: 119
	},
	'san-pedro': {
		label: "San Pedro",
		province: 'AR-B',
		order: 120
	},
	'san-vicente': {
		label: "San Vicente",
		province: 'AR-B',
		order: 121
	},
	'suipacha': {
		label: "Suipacha",
		province: 'AR-B',
		order: 122
	},
	'tandil': {
		label: "Tandil",
		province: 'AR-B',
		order: 123
	},
	'tapalque': {
		label: "Tapalqué",
		province: 'AR-B',
		order: 124
	},
	'tigre': {
		label: "Tigre",
		province: 'AR-B',
		order: 125
	},
	'tordillo': {
		label: "Tordillo",
		province: 'AR-B',
		order: 126
	},
	'tornquist': {
		label: "Tornquist",
		province: 'AR-B',
		order: 127
	},
	'trenque-lauquen': {
		label: "Trenque Lauquen",
		province: 'AR-B',
		order: 128
	},
	'tres-arroyos': {
		label: "Tres Arroyos",
		province: 'AR-B',
		order: 129
	},
	'tres-de-febrero': {
		label: "Tres de Febrero",
		province: 'AR-B',
		order: 130
	},
	'tres-lomas': {
		label: "Tres Lomas",
		province: 'AR-B',
		order: 131
	},
	'veinticinco-de-mayo': {
		label: "Veinticinco de Mayo",
		province: 'AR-B',
		order: 132
	},
	'vicente-lopez': {
		label: "Vicente López",
		province: 'AR-B',
		order: 133
	},
	'villa-gesell': {
		label: "Villa Gesell",
		province: 'AR-B',
		order: 134
	},
	'villarino': {
		label: "Villarino",
		province: 'AR-B',
		order: 135
	},
	'zarate': {
		label: "Zárate",
		province: 'AR-B',
		order: 136
	},
	'adolfo-alsina-rio': {
		label: "Adolfo Alsina",
		province: 'AR-R',
		order: 137
	},
	'aguirre': {
		label: "Aguirre",
		province: 'AR-G',
		order: 138
	},
	'albardon': {
		label: "Albardón",
		province: 'AR-J',
		order: 139
	},
	'alberdi': {
		label: "Alberdi",
		province: 'AR-G',
		order: 140
	},
	'almirante-brown-chaco': {
		label: "Almirante Brown",
		province: 'AR-H',
		order: 141
	},
	'alumine': {
		label: "Aluminé",
		province: 'AR-Q',
		order: 142
	},
	'ambato': {
		label: "Ambato",
		province: 'AR-K',
		order: 143
	},
	'ancasti': {
		label: "Ancasti",
		province: 'AR-K',
		order: 144
	},
	'andalgala': {
		label: "Andalgalá",
		province: 'AR-K',
		order: 145
	},
	'anelo': {
		label: "Añelo",
		province: 'AR-Q',
		order: 146
	},
	'angaco': {
		label: "Angaco",
		province: 'AR-J',
		order: 147
	},
	'anta': {
		label: "Anta",
		province: 'AR-A',
		order: 148
	},
	'antofagasta-de-la-sierra': {
		label: "Antofagasta de la Sierra",
		province: 'AR-K',
		order: 149
	},
	'apostoles': {
		label: "Apóstoles",
		province: 'AR-N',
		order: 150
	},
	'arauco': {
		label: "Arauco",
		province: 'AR-F',
		order: 151
	},
	'argentine-antarctica': {
		label: "Argentine Antarctica",
		province: 'AR-V',
		order: 152
	},
	'atamisqui': {
		label: "Atamisqui",
		province: 'AR-G',
		order: 153
	},
	'atreuco': {
		label: "Atreuco",
		province: 'AR-L',
		order: 154
	},
	'avellaneda-santiago-del-estero': {
		label: "Avellaneda",
		province: 'AR-G',
		order: 155
	},
	'avellaneda-department-rio-negro': {
		label: "Avellaneda",
		province: 'AR-R',
		order: 156
	},
	'ayacucho-department-san-luis': {
		label: "Ayacucho",
		province: 'AR-D',
		order: 157
	},
	'banda': {
		label: "Banda",
		province: 'AR-G',
		order: 158
	},
	'bariloche': {
		label: "Bariloche",
		province: 'AR-R',
		order: 159
	},
	'belen': {
		label: "Belén",
		province: 'AR-K',
		order: 160
	},
	'belgrano': {
		label: "Belgrano",
		province: 'AR-G',
		order: 161
	},
	'belgrano-department-san-luis': {
		label: "Belgrano",
		province: 'AR-D',
		order: 162
	},
	'belgrano-department-santa-fe': {
		label: "Belgrano",
		province: 'AR-S',
		order: 163
	},
	'bella-vista': {
		label: "Bella Vista",
		province: 'AR-W',
		order: 164
	},
	'bermejo': {
		label: "Bermejo",
		province: 'AR-P',
		order: 165
	},
	'bermejo-department-chaco': {
		label: "Bermejo",
		province: 'AR-H',
		order: 166
	},
	'beron-de-astrada': {
		label: "Berón de Astrada",
		province: 'AR-W',
		order: 167
	},
	'biedma': {
		label: "Biedma",
		province: 'AR-U',
		order: 168
	},
	'burruyacu': {
		label: "Burruyacú",
		province: 'AR-T',
		order: 169
	},
	'cachi': {
		label: "Cachi",
		province: 'AR-A',
		order: 170
	},
	'cafayate': {
		label: "Cafayate",
		province: 'AR-A',
		order: 171
	},
	'cainguas': {
		label: "Cainguás",
		province: 'AR-N',
		order: 172
	},
	'calamuchita': {
		label: "Calamuchita",
		province: 'AR-X',
		order: 173
	},
	'caleu-caleu': {
		label: "Caleu Caleu",
		province: 'AR-L',
		order: 174
	},
	'calingasta': {
		label: "Calingasta",
		province: 'AR-J',
		order: 175
	},
	'candelaria-misiones': {
		label: "Candelaria (Misiones)",
		province: 'AR-N',
		order: 176
	},
	'capayan': {
		label: "Capayán",
		province: 'AR-K',
		order: 177
	},
	'capital-department-catamarca': {
		label: "Capital Department, Catamarca",
		province: 'AR-K',
		order: 178
	},
	'capital-department-cordoba': {
		label: "Capital Department, Córdoba",
		province: 'AR-X',
		order: 179
	},
	'capital-department-corrientes': {
		label: "Capital Department, Corrientes",
		province: 'AR-W',
		order: 180
	},
	'capital-department-la-rioja': {
		label: "Capital Department, La Rioja",
		province: 'AR-F',
		order: 181
	},
	'capital-department-mendoza': {
		label: "Capital Department, Mendoza",
		province: 'AR-M',
		order: 182
	},
	'capital-department-misiones': {
		label: "Capital Department, Misiones",
		province: 'AR-N',
		order: 183
	},
	'capital-department-salta': {
		label: "Capital Department, Salta",
		province: 'AR-A',
		order: 184
	},
	'capital-department-san-juan': {
		label: "Capital Department, San Juan",
		province: 'AR-J',
		order: 185
	},
	'capital-department-santa-rosa': {
		label: "Capital Department, Santa Rosa",
		province: 'AR-L',
		order: 186
	},
	'capital-department-santiago-del-estero': {
		label: "Capital Department, Santiago del Estero",
		province: 'AR-G',
		order: 187
	},
	'capital-department-tucuman': {
		label: "Capital Department, Tucumán",
		province: 'AR-T',
		order: 188
	},
	'caseros': {
		label: "Caseros",
		province: 'AR-S',
		order: 189
	},
	'castellanos': {
		label: "Castellanos",
		province: 'AR-S',
		order: 190
	},
	'castro-barros': {
		label: "Castro Barros",
		province: 'AR-F',
		order: 191
	},
	'catan-lil': {
		label: "Catán Lil",
		province: 'AR-Q',
		order: 192
	},
	'catrilo': {
		label: "Catriló",
		province: 'AR-L',
		order: 193
	},
	'caucete': {
		label: "Caucete",
		province: 'AR-J',
		order: 194
	},
	'cerrillos': {
		label: "Cerrillos",
		province: 'AR-A',
		order: 195
	},
	'chacabuco-department-chaco': {
		label: "Chacabuco",
		province: 'AR-H',
		order: 196
	},
	'chacabuco-department-san-luis': {
		label: "Chacabuco",
		province: 'AR-D',
		order: 197
	},
	'chalileo': {
		label: "Chalileo",
		province: 'AR-L',
		order: 198
	},
	'chamical': {
		label: "Chamical",
		province: 'AR-F',
		order: 199
	},
	'chapaleufu': {
		label: "Chapaleufú",
		province: 'AR-L',
		order: 200
	},
	'chical-co': {
		label: "Chical Có",
		province: 'AR-L',
		order: 201
	},
	'chicligasta': {
		label: "Chicligasta",
		province: 'AR-T',
		order: 202
	},
	'chicoana': {
		label: "Chicoana",
		province: 'AR-A',
		order: 203
	},
	'chilecito': {
		label: "Chilecito",
		province: 'AR-F',
		order: 204
	},
	'chimbas': {
		label: "Chimbas",
		province: 'AR-J',
		order: 205
	},
	'chos-malal': {
		label: "Chos Malal",
		province: 'AR-Q',
		order: 206
	},
	'choya': {
		label: "Choya",
		province: 'AR-G',
		order: 207
	},
	'cochinoca': {
		label: "Cochinoca",
		province: 'AR-Y',
		order: 208
	},
	'collon-cura': {
		label: "Collón Curá",
		province: 'AR-Q',
		order: 209
	},
	'colon-department-argentina': {
		label: "Colón",
		province: 'AR-E',
		order: 210
	},
	'colon-department-cordoba': {
		label: "Colón",
		province: 'AR-X',
		order: 211
	},
	'comandante-fernandez': {
		label: "Comandante Fernández",
		province: 'AR-H',
		order: 212
	},
	'concepcion-de-la-sierra': {
		label: "Concepción de la Sierra",
		province: 'AR-N',
		order: 213
	},
	'concepcion-department-argentina': {
		label: "Concepción Department (Argentina)",
		province: 'AR-W',
		order: 214
	},
	'concordia': {
		label: "Concordia",
		province: 'AR-E',
		order: 215
	},
	'conesa': {
		label: "Conesa",
		province: 'AR-R',
		order: 216
	},
	'confluencia': {
		label: "Confluencia",
		province: 'AR-Q',
		order: 217
	},
	'conhelo': {
		label: "Conhelo",
		province: 'AR-L',
		order: 218
	},
	'constitucion': {
		label: "Constitución",
		province: 'AR-S',
		order: 219
	},
	'copo': {
		label: "Copo",
		province: 'AR-G',
		order: 220
	},
	'coronel-felipe-varela': {
		label: "Coronel Felipe Varela",
		province: 'AR-F',
		order: 221
	},
	'coronel-pringles-san-luis': {
		label: "Coronel Pringles",
		province: 'AR-D',
		order: 222
	},
	'corpen-aike': {
		label: "Corpen Aike",
		province: 'AR-Z',
		order: 223
	},
	'cruz-alta': {
		label: "Cruz Alta",
		province: 'AR-T',
		order: 224
	},
	'cruz-del-eje': {
		label: "Cruz del Eje",
		province: 'AR-X',
		order: 225
	},
	'curaco': {
		label: "Curacó",
		province: 'AR-L',
		order: 226
	},
	'curuzu-cuatia': {
		label: "Curuzú Cuatía",
		province: 'AR-W',
		order: 227
	},
	'cushamen': {
		label: "Cushamen",
		province: 'AR-U',
		order: 228
	},
	'deseado': {
		label: "Deseado",
		province: 'AR-Z',
		order: 229
	},
	'diamante': {
		label: "Diamante",
		province: 'AR-E',
		order: 230
	},
	'doce-de-octubre': {
		label: "Doce de Octubre",
		province: 'AR-H',
		order: 231
	},
	'doctor-manuel-belgrano': {
		label: "Doctor Manuel Belgrano",
		province: 'AR-Y',
		order: 232
	},
	'dos-de-abril': {
		label: "Dos de Abril",
		province: 'AR-H',
		order: 233
	},
	'el-alto': {
		label: "El Alto",
		province: 'AR-K',
		order: 234
	},
	'el-carmen': {
		label: "El Carmen",
		province: 'AR-Y',
		order: 235
	},
	'el-cuy': {
		label: "El Cuy",
		province: 'AR-R',
		order: 236
	},
	'eldorado': {
		label: "Eldorado",
		province: 'AR-N',
		order: 237
	},
	'empedrado': {
		label: "Empedrado",
		province: 'AR-W',
		order: 238
	},
	'escalante': {
		label: "Escalante",
		province: 'AR-U',
		order: 239
	},
	'esquina': {
		label: "Esquina",
		province: 'AR-W',
		order: 240
	},
	'famailla-department-tucuman': {
		label: "Famaillá",
		province: 'AR-T',
		order: 241
	},
	'famatina': {
		label: "Famatina",
		province: 'AR-F',
		order: 242
	},
	'federacion': {
		label: "Federación",
		province: 'AR-E',
		order: 243
	},
	'federal': {
		label: "Federal",
		province: 'AR-E',
		order: 244
	},
	'figueroa': {
		label: "Figueroa",
		province: 'AR-G',
		order: 245
	},
	'florentino-ameghino-chubut': {
		label: "Florentino Ameghino",
		province: 'AR-U',
		order: 246
	},
	'formosa': {
		label: "Formosa",
		province: 'AR-P',
		order: 247
	},
	'fray-justo-santa-maria-del-oro': {
		label: "Fray Justo Santa María del Oro",
		province: 'AR-H',
		order: 248
	},
	'fray-mamerto-esquiu': {
		label: "Fray Mamerto Esquiú",
		province: 'AR-K',
		order: 249
	},
	'futaleufu': {
		label: "Futaleufú",
		province: 'AR-U',
		order: 250
	},
	'gaiman': {
		label: "Gaiman",
		province: 'AR-U',
		order: 251
	},
	'garay-argentina': {
		label: "Garay, Argentina",
		province: 'AR-S',
		order: 252
	},
	'gastre': {
		label: "Gastre",
		province: 'AR-U',
		order: 253
	},
	'general-alvear-department-corrientes': {
		label: "General Alvear",
		province: 'AR-W',
		order: 254
	},
	'general-alvear-department-mendoza': {
		label: "General Alvear",
		province: 'AR-M',
		order: 255
	},
	'general-angel-vicente-penaloza': {
		label: "General Angel Vicente Peñaloza",
		province: 'AR-F',
		order: 256
	},
	'general-belgrano-department-chaco': {
		label: "General Belgrano",
		province: 'AR-H',
		order: 257
	},
	'general-belgrano-department-la-rioja': {
		label: "General Belgrano",
		province: 'AR-F',
		order: 258
	},
	'general-donovan': {
		label: "General Donovan",
		province: 'AR-H',
		order: 259
	},
	'general-guemes-department-chaco': {
		label: "General Güemes",
		province: 'AR-H',
		order: 260
	},
	'general-guemes-department-salta': {
		label: "General Güemes",
		province: 'AR-A',
		order: 261
	},
	'general-juan-facundo-quiroga': {
		label: "General Juan Facundo Quiroga",
		province: 'AR-F',
		order: 262
	},
	'general-lamadrid': {
		label: "General Lamadrid",
		province: 'AR-F',
		order: 263
	},
	'general-lopez': {
		label: "General López",
		province: 'AR-S',
		order: 264
	},
	'general-manuel-belgrano': {
		label: "General Manuel Belgrano",
		province: 'AR-N',
		order: 265
	},
	'general-obligado': {
		label: "General Obligado",
		province: 'AR-S',
		order: 266
	},
	'general-ocampo': {
		label: "General Ocampo",
		province: 'AR-F',
		order: 267
	},
	'general-paz-corrientes': {
		label: "General Paz",
		province: 'AR-W',
		order: 268
	},
	'general-pedernera': {
		label: "General Pedernera",
		province: 'AR-D',
		order: 269
	},
	'general-roca-department-cordoba': {
		label: "General Roca",
		province: 'AR-X',
		order: 270
	},
	'general-roca-department-rio-negro': {
		label: "General Roca",
		province: 'AR-R',
		order: 271
	},
	'general-san-martin-salta': {
		label: "General San Martín",
		province: 'AR-A',
		order: 272
	},
	'general-san-martin-department-cordoba': {
		label: "General San Martín",
		province: 'AR-X',
		order: 273
	},
	'general-san-martin-department-la-rioja': {
		label: "General San Martín",
		province: 'AR-F',
		order: 274
	},
	'general-taboada': {
		label: "General Taboada",
		province: 'AR-G',
		order: 275
	},
	'gobernador-dupuy': {
		label: "Gobernador Dupuy",
		province: 'AR-D',
		order: 276
	},
	'godoy-cruz': {
		label: "Godoy Cruz",
		province: 'AR-M',
		order: 277
	},
	'goya': {
		label: "Goya",
		province: 'AR-W',
		order: 278
	},
	'graneros': {
		label: "Graneros",
		province: 'AR-T',
		order: 279
	},
	'guachipas': {
		label: "Guachipas",
		province: 'AR-A',
		order: 280
	},
	'gualeguay': {
		label: "Gualeguay",
		province: 'AR-E',
		order: 281
	},
	'gualeguaychu': {
		label: "Gualeguaychú",
		province: 'AR-E',
		order: 282
	},
	'guarani': {
		label: "Guaraní",
		province: 'AR-N',
		order: 283
	},
	'guasayan': {
		label: "Guasayán",
		province: 'AR-G',
		order: 284
	},
	'guatrache': {
		label: "Guatraché",
		province: 'AR-L',
		order: 285
	},
	'guaymallen': {
		label: "Guaymallén",
		province: 'AR-M',
		order: 286
	},
	'guer-aike': {
		label: "Güer Aike",
		province: 'AR-Z',
		order: 287
	},
	'huiliches': {
		label: "Huiliches",
		province: 'AR-Q',
		order: 288
	},
	'humahuaca': {
		label: "Humahuaca",
		province: 'AR-Y',
		order: 289
	},
	'huncal': {
		label: "Huncal",
		province: 'AR-L',
		order: 290
	},
	'iglesia': {
		label: "Iglesia",
		province: 'AR-J',
		order: 291
	},
	'iguazu': {
		label: "Iguazú",
		province: 'AR-N',
		order: 292
	},
	'independencia-department-chaco': {
		label: "Independencia",
		province: 'AR-H',
		order: 293
	},
	'independencia-department-la-rioja': {
		label: "Independencia",
		province: 'AR-F',
		order: 294
	},
	'iriondo': {
		label: "Iriondo",
		province: 'AR-S',
		order: 295
	},
	'iruya': {
		label: "Iruya",
		province: 'AR-A',
		order: 296
	},
	'ischilin': {
		label: "Ischilín",
		province: 'AR-X',
		order: 297
	},
	'islas-del-atlantico-sur': {
		label: "Islas del Atlántico Sur",
		province: 'AR-V',
		order: 298
	},
	'itati': {
		label: "Itatí",
		province: 'AR-W',
		order: 299
	},
	'ituzaingo-corrientes': {
		label: "Ituzaingó",
		province: 'AR-W',
		order: 300
	},
	'jachal': {
		label: "Jáchal",
		province: 'AR-J',
		order: 301
	},
	'jimenez': {
		label: "Jiménez",
		province: 'AR-G',
		order: 302
	},
	'juan-bautista-alberdi': {
		label: "Juan Bautista Alberdi",
		province: 'AR-T',
		order: 303
	},
	'juan-felipe-ibarra': {
		label: "Juan Felipe Ibarra",
		province: 'AR-G',
		order: 304
	},
	'juarez-celman': {
		label: "Juárez Celman",
		province: 'AR-X',
		order: 305
	},
	'junin-department-mendoza': {
		label: "Junín",
		province: 'AR-M',
		order: 306
	},
	'junin-department-san-luis': {
		label: "Junín",
		province: 'AR-D',
		order: 307
	},
	'la-caldera': {
		label: "La Caldera",
		province: 'AR-A',
		order: 308
	},
	'la-candelaria': {
		label: "La Candelaria",
		province: 'AR-A',
		order: 309
	},
	'la-capital-department-san-luis': {
		label: "La Capital",
		province: 'AR-D',
		order: 310
	},
	'la-capital-department-santa-fe': {
		label: "La Capital",
		province: 'AR-S',
		order: 311
	},
	'la-cocha': {
		label: "La Cocha",
		province: 'AR-T',
		order: 312
	},
	'la-paz-department-catamarca': {
		label: "La Paz",
		province: 'AR-K',
		order: 313
	},
	'la-paz-department-entre-rios': {
		label: "La Paz",
		province: 'AR-E',
		order: 314
	},
	'la-paz-department-mendoza': {
		label: "La Paz",
		province: 'AR-M',
		order: 315
	},
	'la-poma': {
		label: "La Poma",
		province: 'AR-A',
		order: 316
	},
	'la-vina': {
		label: "La Viña",
		province: 'AR-A',
		order: 317
	},
	'lacar': {
		label: "Lacar",
		province: 'AR-Q',
		order: 318
	},
	'lago-argentino': {
		label: "Lago Argentino",
		province: 'AR-Z',
		order: 319
	},
	'lago-buenos-aires': {
		label: "Lago Buenos Aires",
		province: 'AR-Z',
		order: 320
	},
	'laishi': {
		label: "Laishí",
		province: 'AR-P',
		order: 321
	},
	'languineo': {
		label: "Languiñeo",
		province: 'AR-U',
		order: 322
	},
	'las-colonias': {
		label: "Las Colonias",
		province: 'AR-S',
		order: 323
	},
	'las-heras': {
		label: "Las Heras",
		province: 'AR-M',
		order: 324
	},
	'lavalle-department-corrientes': {
		label: "Lavalle",
		province: 'AR-W',
		order: 325
	},
	'lavalle-department-mendoza': {
		label: "Lavalle",
		province: 'AR-M',
		order: 326
	},
	'leales': {
		label: "Leales",
		province: 'AR-T',
		order: 327
	},
	'leandro-n-alem-misiones': {
		label: "Leandro N. Alem",
		province: 'AR-N',
		order: 328
	},
	'ledesma': {
		label: "Ledesma",
		province: 'AR-Y',
		order: 329
	},
	'libertad-chaco': {
		label: "Libertad, Chaco",
		province: 'AR-H',
		order: 330
	},
	'libertador-general-san-martin-department-misiones': {
		label: "Libertador General San Martín",
		province: 'AR-N',
		order: 331
	},
	'libertador-general-san-martin-department-san-luis': {
		label: "Libertador General San Martín",
		province: 'AR-D',
		order: 332
	},
	'libertador-general-san-martin-jujuy': {
		label: "Libertador General San Martín, Jujuy",
		province: 'AR-H',
		order: 333
	},
	'lihue-calel': {
		label: "Lihué Calel",
		province: 'AR-L',
		order: 334
	},
	'limay-mahuida': {
		label: "Limay Mahuida",
		province: 'AR-L',
		order: 335
	},
	'loncopue': {
		label: "Loncopué",
		province: 'AR-Q',
		order: 336
	},
	'loreto': {
		label: "Loreto",
		province: 'AR-G',
		order: 337
	},
	'los-andes': {
		label: "Los Andes",
		province: 'AR-A',
		order: 338
	},
	'los-lagos': {
		label: "Los Lagos",
		province: 'AR-Q',
		order: 339
	},
	'loventue': {
		label: "Loventué",
		province: 'AR-L',
		order: 340
	},
	'lujan-de-cuyo': {
		label: "Luján de Cuyo",
		province: 'AR-M',
		order: 341
	},
	'lules': {
		label: "Lules",
		province: 'AR-T',
		order: 342
	},
	'magallanes': {
		label: "Magallanes",
		province: 'AR-Z',
		order: 343
	},
	'maipu-department-chaco': {
		label: "Maipú",
		province: 'AR-H',
		order: 344
	},
	'maipu-department-mendoza': {
		label: "Maipú",
		province: 'AR-M',
		order: 345
	},
	'malargue': {
		label: "Malargüe",
		province: 'AR-M',
		order: 346
	},
	'maraco': {
		label: "Maracó",
		province: 'AR-L',
		order: 347
	},
	'marcos-juarez': {
		label: "Marcos Juárez",
		province: 'AR-X',
		order: 348
	},
	'martires': {
		label: "Mártires",
		province: 'AR-U',
		order: 349
	},
	'matacos': {
		label: "Matacos",
		province: 'AR-P',
		order: 350
	},
	'mayor-luis-jorge-fontana': {
		label: "Mayor Luis Jorge Fontana",
		province: 'AR-H',
		order: 351
	},
	'mburucuya': {
		label: "Mburucuyá",
		province: 'AR-W',
		order: 352
	},
	'mercedes-corrientes': {
		label: "Mercedes",
		province: 'AR-W',
		order: 353
	},
	'metan': {
		label: "Metán",
		province: 'AR-A',
		order: 354
	},
	'minas-department-cordoba': {
		label: "Minas",
		province: 'AR-X',
		order: 355
	},
	'minas-department-neuquen': {
		label: "Minas",
		province: 'AR-Q',
		order: 356
	},
	'mitre': {
		label: "Mitre",
		province: 'AR-G',
		order: 357
	},
	'molinos': {
		label: "Molinos",
		province: 'AR-A',
		order: 358
	},
	'monte-caseros': {
		label: "Monte Caseros",
		province: 'AR-W',
		order: 359
	},
	'montecarlo': {
		label: "Montecarlo",
		province: 'AR-N',
		order: 360
	},
	'monteros': {
		label: "Monteros",
		province: 'AR-T',
		order: 361
	},
	'moreno-santiago-del-estero': {
		label: "Moreno",
		province: 'AR-G',
		order: 362
	},
	'nogoya': {
		label: "Nogoyá",
		province: 'AR-E',
		order: 363
	},
	'norquin': {
		label: "Ñorquin",
		province: 'AR-Q',
		order: 364
	},
	'norquinco': {
		label: "Ñorquinco",
		province: 'AR-R',
		order: 365
	},
	'nueve-de-julio-department-chaco': {
		label: "Nueve de Julio",
		province: 'AR-H',
		order: 366
	},
	'nueve-de-julio-department-rio-negro': {
		label: "Nueve de Julio",
		province: 'AR-R',
		order: 367
	},
	'nueve-de-julio-department-san-juan': {
		label: "Nueve de Julio",
		province: 'AR-J',
		order: 368
	},
	'nueve-de-julio-department-santa-fe': {
		label: "Nueve de Julio",
		province: 'AR-S',
		order: 369
	},
	'o-higgins': {
		label: "O'Higgins",
		province: 'AR-H',
		order: 370
	},
	'obera': {
		label: "Oberá",
		province: 'AR-N',
		order: 371
	},
	'ojo-de-agua': {
		label: "Ojo de Agua",
		province: 'AR-G',
		order: 372
	},
	'oran': {
		label: "Orán",
		province: 'AR-A',
		order: 373
	},
	'paclin': {
		label: "Paclín",
		province: 'AR-K',
		order: 374
	},
	'palpala': {
		label: "Palpalá",
		province: 'AR-Y',
		order: 375
	},
	'parana': {
		label: "Paraná",
		province: 'AR-E',
		order: 376
	},
	'paso-de-indios': {
		label: "Paso de Indios",
		province: 'AR-U',
		order: 377
	},
	'paso-de-los-libres': {
		label: "Paso de los Libres",
		province: 'AR-W',
		order: 378
	},
	'patino': {
		label: "Patiño",
		province: 'AR-P',
		order: 379
	},
	'pehuenches': {
		label: "Pehuenches",
		province: 'AR-Q',
		order: 380
	},
	'pellegrini-santiago-del-estero': {
		label: "Pellegrini",
		province: 'AR-G',
		order: 381
	},
	'pichi-mahiuda': {
		label: "Pichi Mahiuda",
		province: 'AR-R',
		order: 382
	},
	'picun-leufu': {
		label: "Picún Leufú",
		province: 'AR-Q',
		order: 383
	},
	'picunches': {
		label: "Picunches",
		province: 'AR-Q',
		order: 384
	},
	'pilagas': {
		label: "Pilagás",
		province: 'AR-P',
		order: 385
	},
	'pilcaniyeu': {
		label: "Pilcaniyeu",
		province: 'AR-R',
		order: 386
	},
	'pilcomayo': {
		label: "Pilcomayo",
		province: 'AR-P',
		order: 387
	},
	'pirane': {
		label: "Pirané",
		province: 'AR-P',
		order: 388
	},
	'pocho': {
		label: "Pocho",
		province: 'AR-X',
		order: 389
	},
	'pocito': {
		label: "Pocito",
		province: 'AR-J',
		order: 390
	},
	'poman': {
		label: "Pomán",
		province: 'AR-K',
		order: 391
	},
	'presidente-de-la-plaza': {
		label: "Presidente de la Plaza",
		province: 'AR-H',
		order: 392
	},
	'presidente-roque-saenz-pena': {
		label: "Presidente Roque Sáenz Peña",
		province: 'AR-X',
		order: 393
	},
	'primero-de-mayo': {
		label: "Primero de Mayo",
		province: 'AR-H',
		order: 394
	},
	'puelen': {
		label: "Puelén",
		province: 'AR-L',
		order: 395
	},
	'punilla': {
		label: "Punilla",
		province: 'AR-X',
		order: 396
	},
	'quebrachos': {
		label: "Quebrachos",
		province: 'AR-G',
		order: 397
	},
	'quemu-quemu': {
		label: "Quemú Quemú",
		province: 'AR-L',
		order: 398
	},
	'quitilipi': {
		label: "Quitilipi",
		province: 'AR-H',
		order: 399
	},
	'ramon-lista': {
		label: "Ramón Lista",
		province: 'AR-P',
		order: 400
	},
	'rancul': {
		label: "Rancul",
		province: 'AR-L',
		order: 401
	},
	'rawson-department-chubut': {
		label: "Rawson",
		province: 'AR-U',
		order: 402
	},
	'rawson-department-san-juan': {
		label: "Rawson",
		province: 'AR-J',
		order: 403
	},
	'realico': {
		label: "Realicó",
		province: 'AR-L',
		order: 404
	},
	'rinconada': {
		label: "Rinconada",
		province: 'AR-Y',
		order: 405
	},
	'rio-chico-department-santa-cruz': {
		label: "Río Chico",
		province: 'AR-Z',
		order: 406
	},
	'rio-chico-department-tucuman': {
		label: "Río Chico",
		province: 'AR-T',
		order: 407
	},
	'rio-cuarto': {
		label: "Río Cuarto",
		province: 'AR-X',
		order: 408
	},
	'rio-grande': {
		label: "Río Grande",
		province: 'AR-V',
		order: 409
	},
	'rio-primero': {
		label: "Río Primero",
		province: 'AR-X',
		order: 410
	},
	'rio-seco': {
		label: "Río Seco",
		province: 'AR-X',
		order: 411
	},
	'rio-segundo': {
		label: "Río Segundo",
		province: 'AR-X',
		order: 412
	},
	'rio-senguer': {
		label: "Río Senguer",
		province: 'AR-U',
		order: 413
	},
	'rivadavia-department-mendoza': {
		label: "Rivadavia",
		province: 'AR-M',
		order: 414
	},
	'rivadavia-department-san-juan': {
		label: "Rivadavia",
		province: 'AR-J',
		order: 415
	},
	'rivadavia-department-santiago': {
		label: "Rivadavia",
		province: 'AR-G',
		order: 416
	},
	'rivadavia-salta': {
		label: "Rivadavia, Salta",
		province: 'AR-A',
		order: 417
	},
	'robles': {
		label: "Robles",
		province: 'AR-G',
		order: 418
	},
	'rosario': {
		label: "Rosario",
		province: 'AR-S',
		order: 419
	},
	'rosario-de-la-frontera': {
		label: "Rosario de la Frontera",
		province: 'AR-A',
		order: 420
	},
	'rosario-de-lerma': {
		label: "Rosario de Lerma",
		province: 'AR-A',
		order: 421
	},
	'rosario-vera-penaloza': {
		label: "Rosario Vera Peñaloza",
		province: 'AR-F',
		order: 422
	},
	'saladas': {
		label: "Saladas",
		province: 'AR-W',
		order: 423
	},
	'salavina': {
		label: "Salavina",
		province: 'AR-G',
		order: 424
	},
	'san-alberto': {
		label: "San Alberto",
		province: 'AR-X',
		order: 425
	},
	'san-antonio-oeste': {
		label: "San Antonio",
		province: 'AR-R',
		order: 426
	},
	'san-antonio-jujuy': {
		label: "San Antonio",
		province: 'AR-Y',
		order: 427
	},
	'san-blas': {
		label: "San Blas",
		province: 'AR-F',
		order: 428
	},
	'san-carlos-department-mendoza': {
		label: "San Carlos",
		province: 'AR-M',
		order: 429
	},
	'san-carlos-department-salta': {
		label: "San Carlos",
		province: 'AR-A',
		order: 430
	},
	'san-cosme': {
		label: "San Cosme",
		province: 'AR-W',
		order: 431
	},
	'san-cristobal-santa-fe': {
		label: "San Cristóbal, Santa Fe",
		province: 'AR-S',
		order: 432
	},
	'san-fernando-chaco': {
		label: "San Fernando",
		province: 'AR-H',
		order: 433
	},
	'san-ignacio-department-misiones': {
		label: "San Ignacio",
		province: 'AR-N',
		order: 434
	},
	'san-javier-department-cordoba': {
		label: "San Javier",
		province: 'AR-X',
		order: 435
	},
	'san-javier-department-misiones': {
		label: "San Javier",
		province: 'AR-N',
		order: 436
	},
	'san-javier-department-santa-fe': {
		label: "San Javier",
		province: 'AR-S',
		order: 437
	},
	'san-jeronimo': {
		label: "San Jerónimo",
		province: 'AR-S',
		order: 438
	},
	'san-jose-de-feliciano': {
		label: "San José de Feliciano",
		province: 'AR-E',
		order: 439
	},
	'san-justo-department-cordoba': {
		label: "San Justo",
		province: 'AR-X',
		order: 440
	},
	'san-justo-department-santa-fe': {
		label: "San Justo",
		province: 'AR-S',
		order: 441
	},
	'san-lorenzo-chaco': {
		label: "San Lorenzo",
		province: 'AR-H',
		order: 442
	},
	'san-lorenzo-stanta-fe': {
		label: "San Lorenzo",
		province: 'AR-S',
		order: 443
	},
	'san-luis-del-palmar': {
		label: "San Luis del Palmar",
		province: 'AR-W',
		order: 444
	},
	'san-martin-department-corrientes': {
		label: "San Martín",
		province: 'AR-W',
		order: 445
	},
	'san-martin-department-mendoza': {
		label: "San Martín",
		province: 'AR-M',
		order: 446
	},
	'san-martin-department-san-juan': {
		label: "San Martín",
		province: 'AR-J',
		order: 447
	},
	'san-martin-department-santa-fe': {
		label: "San Martín",
		province: 'AR-S',
		order: 448
	},
	'san-martin-department-santiago-del-estero': {
		label: "San Martín",
		province: 'AR-G',
		order: 449
	},
	'san-miguel-department-corrientes': {
		label: "San Miguel",
		province: 'AR-W',
		order: 450
	},
	'san-pedro-department-jujuy': {
		label: "San Pedro",
		province: 'AR-Y',
		order: 451
	},
	'san-pedro-department-misiones': {
		label: "San Pedro",
		province: 'AR-N',
		order: 452
	},
	'san-rafael': {
		label: "San Rafael",
		province: 'AR-M',
		order: 453
	},
	'san-roque': {
		label: "San Roque",
		province: 'AR-W',
		order: 454
	},
	'sanagasta': {
		label: "Sanagasta",
		province: 'AR-F',
		order: 455
	},
	'santa-barbara': {
		label: "Santa Bárbara",
		province: 'AR-Y',
		order: 456
	},
	'santa-catalina': {
		label: "Santa Catalina",
		province: 'AR-Y',
		order: 457
	},
	'santa-lucia': {
		label: "Santa Lucía",
		province: 'AR-J',
		order: 458
	},
	'santa-maria-department-catamarca': {
		label: "Santa María",
		province: 'AR-K',
		order: 459
	},
	'santa-maria-department-cordoba': {
		label: "Santa María",
		province: 'AR-X',
		order: 460
	},
	'santa-rosa-department-catamarca': {
		label: "Santa Rosa",
		province: 'AR-K',
		order: 461
	},
	'santa-rosa-department-mendoza': {
		label: "Santa Rosa",
		province: 'AR-M',
		order: 462
	},
	'santa-victoria': {
		label: "Santa Victoria",
		province: 'AR-A',
		order: 463
	},
	'santo-tome': {
		label: "Santo Tomé",
		province: 'AR-W',
		order: 464
	},
	'sargento-cabral': {
		label: "Sargento Cabral",
		province: 'AR-H',
		order: 465
	},
	'sarmiento-department-chubut': {
		label: "Sarmiento",
		province: 'AR-U',
		order: 466
	},
	'sarmiento-department-san-juan': {
		label: "Sarmiento",
		province: 'AR-J',
		order: 467
	},
	'sarmiento-department-santiago-del-estero': {
		label: "Sarmiento",
		province: 'AR-G',
		order: 468
	},
	'sauce': {
		label: "Sauce",
		province: 'AR-W',
		order: 469
	},
	'silipica': {
		label: "Silípica",
		province: 'AR-G',
		order: 470
	},
	'simoca': {
		label: "Simoca",
		province: 'AR-T',
		order: 471
	},
	'sobremonte': {
		label: "Sobremonte",
		province: 'AR-X',
		order: 472
	},
	'susques': {
		label: "Susques",
		province: 'AR-Y',
		order: 473
	},
	'tafi-del-valle': {
		label: "Tafí del Valle",
		province: 'AR-T',
		order: 474
	},
	'tafi-viejo': {
		label: "Tafí Viejo",
		province: 'AR-T',
		order: 475
	},
	'tala': {
		label: "Tala",
		province: 'AR-E',
		order: 476
	},
	'tapenaga': {
		label: "Tapenaga",
		province: 'AR-H',
		order: 477
	},
	'tehuelches': {
		label: "Tehuelches",
		province: 'AR-U',
		order: 478
	},
	'telsen': {
		label: "Telsen",
		province: 'AR-U',
		order: 479
	},
	'tercero-arriba': {
		label: "Tercero Arriba",
		province: 'AR-X',
		order: 480
	},
	'termas-de-rio-hondo': {
		label: "Termas de Río Hondo",
		province: 'AR-G',
		order: 481
	},
	'tilcara': {
		label: "Tilcara",
		province: 'AR-Y',
		order: 482
	},
	'tinogasta': {
		label: "Tinogasta",
		province: 'AR-K',
		order: 483
	},
	'toay': {
		label: "Toay",
		province: 'AR-L',
		order: 484
	},
	'totoral': {
		label: "Totoral",
		province: 'AR-X',
		order: 485
	},
	'trancas': {
		label: "Trancas",
		province: 'AR-T',
		order: 486
	},
	'trenel': {
		label: "Trenel",
		province: 'AR-L',
		order: 487
	},
	'tulumba': {
		label: "Tulumba",
		province: 'AR-X',
		order: 488
	},
	'tumbaya': {
		label: "Tumbaya",
		province: 'AR-Y',
		order: 489
	},
	'tunuyan': {
		label: "Tunuyán",
		province: 'AR-M',
		order: 490
	},
	'tupungato': {
		label: "Tupungato",
		province: 'AR-M',
		order: 491
	},
	'ullum': {
		label: "Ullúm",
		province: 'AR-J',
		order: 492
	},
	'union': {
		label: "Unión",
		province: 'AR-X',
		order: 493
	},
	'uruguay': {
		label: "Uruguay",
		province: 'AR-E',
		order: 494
	},
	'ushuaia': {
		label: "Ushuaia",
		province: 'AR-V',
		order: 495
	},
	'utracan': {
		label: "Utracán",
		province: 'AR-L',
		order: 496
	},
	'valcheta': {
		label: "Valcheta",
		province: 'AR-R',
		order: 497
	},
	'valle-fertil': {
		label: "Valle Fértil",
		province: 'AR-J',
		order: 498
	},
	'valle-grande': {
		label: "Valle Grande",
		province: 'AR-Y',
		order: 499
	},
	'valle-viejo': {
		label: "Valle Viejo",
		province: 'AR-K',
		order: 500
	},
	'veinticinco-de-mayo-department-chaco': {
		label: "Veinticinco de Mayo",
		province: 'AR-H',
		order: 501
	},
	'veinticinco-de-mayo-department-misiones': {
		label: "Veinticinco de Mayo",
		province: 'AR-N',
		order: 502
	},
	'veinticinco-de-mayo-department-rio-negro': {
		label: "Veinticinco de Mayo",
		province: 'AR-R',
		order: 503
	},
	'veinticinco-de-mayo-department-san-juan': {
		label: "Veinticinco de Mayo",
		province: 'AR-J',
		order: 504
	},
	'vera': {
		label: "Vera",
		province: 'AR-S',
		order: 505
	},
	'victoria': {
		label: "Victoria",
		province: 'AR-E',
		order: 506
	},
	'villaguay': {
		label: "Villaguay",
		province: 'AR-E',
		order: 507
	},
	'vinchina': {
		label: "Vinchina",
		province: 'AR-F',
		order: 508
	},
	'yavi': {
		label: "Yavi",
		province: 'AR-Y',
		order: 509
	},
	'yerba-buena': {
		label: "Yerba Buena",
		province: 'AR-T',
		order: 510
	},
	'zapala': {
		label: "Zapala",
		province: 'AR-Q',
		order: 511
	},
	'zonda': {
		label: "Zonda",
		province: 'AR-J',
		order: 512
	}
});

Department.set('provinceMap', function () {
	var map = {};
	this.options.itemsListByOrder().forEach(function (item) {
		var province = item.province;
		if (!map[province]) map[province] = [];
		map[province].push(item._subject_);
	});
	return map;
});

'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('ControlCriteriaType', {
	access: {
		label: "Accesso",
		order: 1
	},
	electricity: {
		label: "Electricidad",
		order: 2
	},
	fire: {
		label: "Incendio",
		order: 3
	},
	local: {
		label: "Local",
		order: 4
	},
	personal: {
		label: "Personal",
		order: 5
	},
	noise: {
		label: "Ruido",
		order: 6
	},
	health: {
		label: "Salud",
		order: 7
	},
	higiene: {
		label: "Salubridad e higiene",
		order: 8
	}
});

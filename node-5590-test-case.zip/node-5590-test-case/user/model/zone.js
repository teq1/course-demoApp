'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

require('./zone-category');

module.exports = Enum.create('Zone', {
	'ia': {
		label: "I.A.",
		category: 'side',
		order: 1
	},
	'ib': {
		label: "I.B.",
		category: 'side',
		order: 2
	},
	'c1': {
		label: "C1",
		category: 'commercial',
		order: 3
	},
	'c21': {
		label: "C2.1",
		category: 'commercial',
		order: 4
	},
	'c22': {
		label: "C2.2",
		category: 'commercial',
		order: 5
	},
	'c23': {
		label: "C2.3",
		category: 'commercial',
		order: 6
	},
	'ie': {
		label: "I.E.",
		category: 'industrial',
		order: 7
	},
	'rn': {
		label: "R.N.",
		category: 'recreation',
		order: 8
	},
	'zue': {
		label: "ZUE",
		category: 'side',
		order: 9
	},
	'evp': {
		label: "EVP",
		category: 'recreation',
		order: 10
	},
	're': {
		label: "R.E.",
		category: 'residential',
		order: 11
	},
	'r10': {
		label: "R1.0",
		category: 'residential',
		order: 12
	},
	'r11': {
		label: "R1.1",
		category: 'residential',
		order: 13
	},
	'r12': {
		label: "R1.2",
		category: 'residential',
		order: 14
	},
	'r21': {
		label: "R2.1",
		category: 'residential',
		order: 15
	},
	'r22': {
		label: "R2.2",
		category: 'residential',
		order: 16
	},
	'r31': {
		label: "R3.1",
		category: 'residential',
		order: 17
	},
	'r32': {
		label: "R3.2",
		category: 'residential',
		order: 18
	},
	'r33': {
		label: "R3.3",
		category: 'residential',
		order: 19
	},
	'r41': {
		label: "R4.1",
		category: 'residential',
		order: 20
	},
	'r42': {
		label: "R4.2",
		category: 'residential',
		order: 21
	}
});

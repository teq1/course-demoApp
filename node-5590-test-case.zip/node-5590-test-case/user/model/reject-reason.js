'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('RejectReason', {
	illegible: {
		label: "Los documentos son ilegibles",
		order: 1
	},
	invalid: {
		label: "Los documentos cargados no coinciden con los documentos requeridos",
		order: 2
	},
	other: {
		label: "Otros…",
		order: 3
	}
});

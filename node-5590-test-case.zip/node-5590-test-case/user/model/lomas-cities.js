'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('LomasCities', {
	'lomas-de-zamora': {
		label: "Lomas de Zamora",
		order: 1
	},
	'banfield': {
		label: "Banfield",
		order: 2
	},
	'temperley': {
		label: "Temperley",
		order: 3
	},
	'llavallol': {
		label: "Llavallol",
		order: 4
	},
	'turdera': {
		label: "Turdera",
		order: 5
	},
	'villa-centenario': {
		label: "Villa Centenario",
		order: 6
	},
	'villa-fiorito': {
		label: "Villa Fiorito",
		order: 7
	},
	'ingeniero-budge': {
		label: "Ingeniero Budge",
		order: 8
	},
	'san-jose': {
		label: "San José",
		order: 9
	},
	'villa-albertina': {
		label: "Villa Albertina",
		order: 10
	},
	'parque-baron': {
		label: "Parque Barón",
		order: 11
	}
});

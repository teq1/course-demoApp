'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('CompanyRepresentation', {
	legal: {
		label: "Representante légal",
		order: 1
	},
	manager: {
		label: "Gestor",
		order: 2
	},
	attorney: {
		label: "Apoderado",
		order: 3
	},
	baCounter: {
		label: "Contador matriculado en Provincia de BA",
		order: 4
	}
});

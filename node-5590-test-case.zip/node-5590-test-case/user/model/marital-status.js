'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('MaritalStatus', {
	single: {
		label: "Soltero",
		order: 1
	},
	married: {
		label: "Casado",
		order: 2
	},
	widowed: {
		label: "Viudo",
		order: 3
	},
	divorced: {
		label: "Divorciado",
		order: 4
	}
});

'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('LegalForm', {
	sole: {
		label: "Persona física",
		order: 1
	},
	company: {
		label: "Sociedad legalmente registrada",
		order: 2
	},
	companyDeFacto: {
		label: "Sociedad de hecho",
		order: 3
	}
});

'use strict';

var Db                     = require('dbjs')
  , UInteger               = require('dbjs-ext/number/integer/u-integer')
  , HorsePower             = require('dbjs-ext/number/horse-power')
  , SquareMeters           = require('dbjs-ext/number/square-meters')
  , Enum                   = require('dbjs-ext/string/string-line/enum')
  , Zone                   = require('./zone')
  , ZoneParkingRequirement = require('./zone-parking-requirement')
  , RuleQuestion           = require('./rule-question')
  , User                   = require('./user/rules')

  , itemProto;

require('./business-type');

var Activity = module.exports = Enum.create('BusinessActivity', {
	'correo-central-yo-telegrafico': {
		category: 'administracion-publica',
		label: "Correo Central y/o Telegráfico",
		group: 'C',
		order: 1
	},
	'cuartel-de-bomberos': {
		category: 'administracion-publica',
		label: "Cuartel de Bomberos",
		group: 'C',
		order: 2
	},
	'estafeta-postal': {
		category: 'administracion-publica',
		label: "Estafeta Postal",
		group: 'C',
		order: 3
	},
	'oficinas-descentralizadas-dgi-reg-civil-telefonos': {
		category: 'administracion-publica',
		label: "Oficinas descentralizadas (DGI-Reg Civil-Teléfonos)",
		group: 'C',
		order: 4
	},
	'oficinas-publicas-con-acceso-de-publico': {
		category: 'administracion-publica',
		label: "Oficinas Públicas con acceso de público",
		group: 'C',
		order: 5
	},
	'penitenciaria-reformatorios': {
		category: 'administracion-publica',
		label: "Penitenciarìa-Reformatorios",
		group: 'C',
		order: 6
	},
	'policia-comisarias': {
		category: 'administracion-publica',
		label: "Policía (Comisarias)",
		group: 'C',
		order: 7
	},
	'policia-dpto-central': {
		category: 'administracion-publica',
		label: "Policía (Dpto central)",
		group: 'C',
		order: 8
	},
	'sucursal-de-correos-yo-telegrafos': {
		category: 'administracion-publica',
		label: "Sucursal de correos y/o telégrafos",
		group: 'C',
		order: 9
	},
	'depositos-de-productos-no-contaminados-ni-inflamab': {
		category: 'comercio-mayorista',
		label: "Depósitos de productos no contaminados ni inflamables ni" +
			" explosivos ni procesamiento de ninguna naturaleza",
		group: 'C',
		order: 10
	},
	'sin-deposito-exposicion-y-venta': {
		category: 'comercio-mayorista',
		label: "Sin depósito (exposición y venta)",
		group: 'C',
		order: 11
	},
	'con-deposito-exceptuando-productos-perecederos': {
		category: 'comercio-mayorista',
		label: "Con depósito (exceptuando productos perecederos)",
		group: 'C',
		order: 12
	},
	'con-deposito-productos-perecederos-camara-fria': {
		category: 'comercio-mayorista',
		label: "Con depósito ( productos perecederos)-Cámara fría",
		group: 'C',
		order: 13
	},
	'con-deposito-materiales-inflamables': {
		category: 'comercio-mayorista',
		label: "Con depósito (materiales inflamables)",
		group: 'C',
		order: 14
	},
	'compra-y-venta-de-muebles-maquinarias-usadas': {
		category: 'comercio-minorista',
		label: "Compra y venta de muebles-maquinarias (usadas)",
		group: 'C',
		order: 15
	},
	'antiguedades': {
		category: 'comercio-minorista',
		label: "Antiguedades",
		group: 'C',
		order: 16
	},
	'articulos-de-deportes-armeria-optica-ortopedia-ins': {
		category: 'comercio-minorista',
		label: "Artículos de deportes-armería-óptica-ortopedia-instr de" +
			" precis.científico-musical",
		group: 'C',
		order: 17
	},
	'bazar-plateria-cristaleria-artef-de-iluminacion-y-': {
		category: 'comercio-minorista',
		label: "Bazar-Platería-Cristalería-Artef de iluminación y del hogar",
		group: 'C',
		order: 18
	},
	'automotores-casas-rodantes-embarcaciones-aviones-e': {
		category: 'comercio-minorista',
		label: "Automotores-casas rodantes-embarcaciones-aviones (exp y venta)",
		group: 'C',
		order: 19
	},
	'cerrajeria': {
		category: 'comercio-minorista',
		label: "Cerrajería",
		group: 'C',
		order: 20
	},
	'farmacia': {
		category: 'comercio-minorista',
		label: "Farmacia",
		group: 'C',
		order: 21
	},
	'ferreteria-herrajes-papeles-pintados-materiales-el': {
		category: 'comercio-minorista',
		label: "Ferretería-Herrajes-papeles pintados-materiales" +
			" eléctricos-pinturería",
		group: 'C',
		order: 22
	},
	'floreria-semilleria-y-articulos-para-jardin': {
		category: 'comercio-minorista',
		label: "Florería-semillería y artículos para jardín",
		group: 'C',
		order: 23
	},
	'joyeria-y-relojeria': {
		category: 'comercio-minorista',
		label: "Joyería y relojería",
		group: 'C',
		order: 24
	},
	'rodados-bicicletas-motocicletas': {
		category: 'comercio-minorista',
		label: "Rodados-bicicletas-motocicletas",
		group: 'C',
		order: 25
	},
	'galerias-comerciales-grandes-tiendas-grandes-tiend': {
		category: 'comercio-minorista',
		label: "Galerías comerciales-grandes tiendas (grandes tiendas llevará" +
			" estacionamiento igual al 20% cuando supere los 200 mts2",
		group: 'C',
		order: 26
	},
	'gas-envasado-distribucion-hasta-100-kg': {
		category: 'comercio-minorista',
		label: "Gas envasado-distribución hasta 100 kg",
		group: 'C',
		order: 27
	},
	'maquinarias-herramientas-y-motores-industriales-y-': {
		category: 'comercio-minorista',
		label: "Maquinarias-herramientas y motores industriales y" +
			" agrícolas-maquinarias de oficinas",
		group: 'C',
		order: 28
	},
	'exposicion-y-venta-de-casas-prefabricadas': {
		category: 'comercio-minorista',
		label: "Exposición y venta de casas prefabricadas",
		group: 'C',
		order: 29
	},
	'materiales-de-construccion-con-deposito-de-materia': {
		category: 'comercio-minorista',
		label: "Materiales de construcción (con depósito de materiales a granel)",
		group: 'C',
		order: 30
	},
	'materiales-de-construccion-excepto-materiales-a-gr': {
		category: 'comercio-minorista',
		label: "Materiales de construcción excepto materiales a granel",
		group: 'C',
		order: 31
	},
	'venta-de-repuestos-de-automotor': {
		category: 'comercio-minorista',
		label: "Venta de repuestos de automotor",
		group: 'C',
		order: 32
	},
	'venta-de-forrajes-y-carbon': {
		category: 'comercio-minorista',
		label: "Venta de forrajes y carbón",
		group: 'C',
		order: 33
	},
	'mercado-y-ferias-internadas': {
		category: 'comercio-minorista',
		label: "Mercado y ferias internadas",
		group: 'C',
		order: 34
	},
	'merceria-botoneria-boneteria-y-fantasias': {
		category: 'comercio-minorista',
		label: "Mercería-botonería-bonetería y fantasías",
		group: 'C',
		order: 35
	},
	'muebles-en-gral-productos-de-madera-y-mimbre-colch': {
		category: 'comercio-minorista',
		label: "Muebles en gral-productos de madera y mimbre-colchones y afin",
		group: 'C',
		order: 36
	},
	'papeleria-libreria-cartoneria-impresos-cotillon-di': {
		category: 'comercio-minorista',
		label: "Papelería-librería-cartonería-impresos-cotillón-discos-juguetes",
		group: 'C',
		order: 37
	},
	'perfumeria-art-de-limpieza-y-tocador': {
		category: 'comercio-minorista',
		label: "Perfumería-art de limpieza y tocador",
		group: 'C',
		order: 38
	},
	'productos-alimenticios-bebidas-y-tabaco-excluidos-': {
		category: 'comercio-minorista',
		label: "Productos alimenticios-bebidas y tabaco (excluídos ferias" +
			" mercados y supermercados)",
		group: 'C',
		order: 39
	},
	'quiosco-diarios-revistas-cigarrillos-loteria-golos': {
		category: 'comercio-minorista',
		label: "Quiosco-diarios-revistas-cigarrillos-lotería-golosinas-etc",
		group: 'C',
		order: 40
	},
	'santeria-art-de-cultos-y-rituales': {
		category: 'comercio-minorista',
		label: "Santería-art de cultos y rituales",
		group: 'C',
		order: 41
	},
	'supermercados-y-autoservicios-pasados-los-200-mts2': {
		category: 'comercio-minorista',
		label: "Supermercados y autoservicios (pasados los 200 mts2 destinado a" +
			" venta",
		group: 'C',
		order: 42
	},
	'supermercado-total': {
		category: 'comercio-minorista',
		label: "Supermercado total",
		group: 'C',
		order: 43
	},
	'sustancias-quimicas-caucho-plasticos-venta-de-pint': {
		category: 'comercio-minorista',
		label: "Sustancias químicas-caucho-plásticos-venta de pinturas",
		group: 'C',
		order: 44
	},
	'textiles-pieles-camara-fria-tiendas-regalos-y-afin': {
		category: 'comercio-minorista',
		label: "Textiles-pieles (cámara fría) tiendas-regalos y afines-cueros",
		group: 'C',
		order: 45
	},
	'veterinaria-venta-de-animales-domesticos': {
		category: 'comercio-minorista',
		label: "Veterinaria-venta de animales domésticos",
		group: 'C',
		order: 46
	},
	'vivero': {
		category: 'comercio-minorista',
		label: "Vivero",
		group: 'C',
		order: 47
	},
	'vidrios-y-espejos': {
		category: 'comercio-minorista',
		label: "Vidrios y espejos",
		group: 'C',
		order: 48
	},
	'verduleria-carniceria': {
		category: 'comercio-minorista',
		label: "Verdulería-carnicería",
		group: 'C',
		order: 49
	},
	'autodromo-estadio-hipodromo-velodromo-circo-parque': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Autódromo-estadio-hipódromo-velódromo-circo-parque de diversiones",
		group: 'C',
		order: 50
	},
	'biblioteca-central-biblioteca-local': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Biblioteca central-biblioteca local",
		group: 'C',
		order: 51
	},
	'casa-de-fiestas-cafe-concert-boite-salon-de-baile': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Casa de fiestas-Café concert-boite-salón de baile",
		group: 'C',
		order: 52
	},
	'centro-de-exposiciones': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Centro de exposiciones",
		group: 'C',
		order: 53
	},
	'cine-cine-teatro-auditorio': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Cine-cine teatro-auditorio",
		group: 'C',
		order: 54
	},
	'autocine': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Autocine",
		group: 'C',
		order: 55
	},
	'calesitas': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Calesitas",
		group: 'C',
		order: 56
	},
	'club-deportivo-con-instalaciones-al-aire-libre-can': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Club deportivo con instalaciones al aire libre-cancha de golf." +
			" Etc (excepto club futbol profesional",
		group: 'C',
		order: 57
	},
	'club-social-y-cultural': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Club social y cultural",
		group: 'C',
		order: 58
	},
	'exposiciones-y-galerias-de-arte': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Exposiciones y galerías de arte",
		group: 'C',
		order: 59
	},
	'gimnasio-natatorios': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Gimnasio-natatorios",
		group: 'C',
		order: 60
	},
	'jardin-botanico-zoologico-acuario': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Jardín botánico-zoológico-acuario",
		group: 'C',
		order: 61
	},
	'museo': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Museo",
		group: 'C',
		order: 62
	},
	'planetario': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Planetario",
		group: 'C',
		order: 63
	},
	'templos': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Templos",
		group: 'C',
		order: 64
	},
	'tiro-club-de-tiro': {
		category: 'cultura-culto-y-esparcimiento',
		label: "Tiro (club de tiro)",
		group: 'C',
		order: 65
	},
	'campos-universitarios': {
		category: 'educacion',
		label: "Campos universitarios",
		group: 'C',
		order: 66
	},
	'escuela-o-colegio-con-inernado': {
		category: 'educacion',
		label: "Escuela o colegio con inernado",
		group: 'C',
		order: 67
	},
	'escuela-preescolar-primario': {
		category: 'educacion',
		label: "Escuela (preescolar-primario)",
		group: 'C',
		order: 68
	},
	'escuela-secundaria': {
		category: 'educacion',
		label: "Escuela secundaria",
		group: 'C',
		order: 69
	},
	'guarderia': {
		category: 'educacion',
		label: "Guardería",
		group: 'C',
		order: 70
	},
	'institutos-tecnicos-academias': {
		category: 'educacion',
		label: "Institutos técnicos-academias",
		group: 'C',
		order: 71
	},
	'institutos-de-investigacion-con-laboratorios': {
		category: 'educacion',
		label: "Institutos de investigación con laboratorios",
		group: 'C',
		order: 72
	},
	'universidades-superior-no-universitaria': {
		category: 'educacion',
		label: "Universidades-superior no universitaria",
		group: 'C',
		order: 73
	},
	'centrales-y-concentraciones-telefonicas-y-electric': {
		category: 'infraestructura-de-servicios',
		label: "Centrales y concentraciones teléfonicas y eléctricas",
		group: 'C',
		order: 74
	},
	'deposito-de-agua': {
		category: 'infraestructura-de-servicios',
		label: "Depósito de agua",
		group: 'C',
		order: 75
	},
	'deposito-de-gas': {
		category: 'infraestructura-de-servicios',
		label: "Depósito de gas",
		group: 'C',
		order: 76
	},
	'asilo-de-ancianos-residencia': {
		category: 'residencial',
		label: "Asilo-de ancianos-residencia",
		group: 'C',
		order: 77
	},
	'casas-de-pension': {
		category: 'residencial',
		label: "Casas de pensión",
		group: 'C',
		order: 78
	},
	'convento': {
		category: 'residencial',
		label: "Convento",
		group: 'C',
		order: 79
	},
	'hogar-infantil': {
		category: 'residencial',
		label: "Hogar infantil",
		group: 'C',
		order: 80
	},
	'casa-de-reposo-y-convalescencia': {
		category: 'sanidad',
		label: "Casa de reposo y convalescencia",
		group: 'C',
		order: 81
	},
	'dispensario': {
		category: 'sanidad',
		label: "Dispensario",
		group: 'C',
		order: 82
	},
	'hospital': {
		category: 'sanidad',
		label: "Hospital",
		group: 'C',
		order: 83
	},
	'primeros-auxilios-consultorios-externos': {
		category: 'sanidad',
		label: "Primeros auxilios-consultorios externos",
		group: 'C',
		order: 84
	},
	'sanatarios-para-enfermos-mentales': {
		category: 'sanidad',
		label: "Sanatarios para enfermos mentales",
		group: 'C',
		order: 85
	},
	'sanatorios-privados': {
		category: 'sanidad',
		label: "Sanatorios privados",
		group: 'C',
		order: 86
	},
	'estacion-terminal-de-colectivos-sin-garage': {
		category: 'transportes',
		label: "Estación terminal de colectivos sin garage",
		group: 'C',
		order: 87
	},
	'expresos-de-carga-liviana-taxiflet-se-exigira-20-m': {
		category: 'transportes',
		label: "Expresos de carga liviana-taxiflet, se exigirá 20 mts2 de" +
			" estacionamiento para vehículos declarados",
		group: 'C',
		order: 88
	},
	'garage-para-camiones-y-materiales-rodantes-se-exig': {
		category: 'transportes',
		label: "Garage para camiones y materiales rodantes, se exigirá 50 mts2" +
			" para camión a estacionar",
		group: 'C',
		order: 89
	},
	'garage-para-omnibus-y-colectivos-se-exigira-30-mts': {
		category: 'transportes',
		label: "Garage para omnibus y colectivos, se exigirá 30 mts2 para" +
			" colectivo a estacionar",
		group: 'C',
		order: 90
	},
	'agencia-comerciales-de-empleo-y-turismo-gestoria-i': {
		category: 'servicios',
		label: "Agencia comerciales de empleo y turismo-gestoría" +
			" inmobiliaria-seguros",
		group: 'C',
		order: 91
	},
	'bar-cafe-confiteia-salon-de-te': {
		category: 'servicios',
		label: "Bar-café-confiteía-salón de té",
		group: 'C',
		order: 92
	},
	'bancos-y-oficinas-de-creditos-financieras-cooperat': {
		category: 'servicios',
		label: "Bancos y oficinas de créditos-financieras-cooperativas",
		group: 'C',
		order: 93
	},
	'copias-reducciones-fotografia-salvo-imprenta': {
		category: 'servicios',
		label: "Copias-reducciones-fotografía (salvo imprenta)",
		group: 'C',
		order: 94
	},
	'seguros-con-revision-de-vehiculos': {
		category: 'servicios',
		label: "Seguros-con revisión de vehículos",
		group: 'C',
		order: 95
	},
	'estacion-de-radio-yo-television-planta-transmisora': {
		category: 'servicios',
		label: "Estación de radio y/o televisión (planta transmisoras)",
		group: 'C',
		order: 96
	},
	'estacion-de-servicios': {
		category: 'servicios',
		label: "Estación de servicios",
		group: 'C',
		order: 97
	},
	'estudios-y-consultorios-profesionales': {
		category: 'servicios',
		label: "Estudios y consultorios profesionales",
		group: 'C',
		order: 98
	},
	'funebre-of-de-recepcion': {
		category: 'servicios',
		label: "Fúnebre (of de recepción)",
		group: 'C',
		order: 99
	},
	'funebre-con-deposito-y-garge': {
		category: 'servicios',
		label: "Fúnebre (con depósito y garge)",
		group: 'C',
		order: 100
	},
	'garage-comercial-hasta-200-coches': {
		category: 'servicios',
		label: "Garage comercial hasta 200 coches",
		group: 'C',
		order: 101
	},
	'hoteles-y-otros-lugares-de-alojamiento-salvo-hotel': {
		category: 'servicios',
		label: "Hoteles y otros lugares de alojamiento (salvo hoteles por hora)",
		group: 'C',
		order: 102
	},
	'hotel-alojamiento-por-hora': {
		category: 'servicios',
		label: "Hotel alojamiento por hora",
		group: 'C',
		order: 103
	},
	'laboratorio-de-analsis-industriales': {
		category: 'servicios',
		label: "Laboratorio de análsis industriales",
		group: 'C',
		order: 104
	},
	'laboratorio-de-analsis-no-industriales-clinicos-y-': {
		category: 'servicios',
		label: "Laboratorio de análsis no industriales (clínicos y otros)",
		group: 'C',
		order: 105
	},
	'lavanderia-tintoreria-receptoria': {
		category: 'servicios',
		label: "Lavandería-tintorería (receptoría)",
		group: 'C',
		order: 106
	},
	'lavanderia-tintoreria-con-taller-de-trabajo': {
		category: 'servicios',
		label: "Lavandería-tintorería (con taller de trabajo)",
		group: 'C',
		order: 107
	},
	'oficinas-en-general': {
		category: 'servicios',
		label: "Oficinas en general",
		group: 'C',
		order: 108
	},
	'peluqueria-e-instituto-de-belleza': {
		category: 'servicios',
		label: "Peluquería e instituto de belleza",
		group: 'C',
		order: 109
	},
	'playa-de-estacionamiento-hasta-200-coches': {
		category: 'servicios',
		label: "Playa de estacionamiento hasta 200 coches",
		group: 'C',
		order: 110
	},
	'prestaciones-con-algun-procesos-artesanal-o-indust': {
		category: 'servicios',
		label: "Prestaciones con algún procesos artesanal o industrial (servicios" +
			" personales y del hogar: rep.de calzado y aparatos eléctricos," +
			" relojes, máquinas de escribir, paraguas, máquinas de coser, radio y" +
			" televisión, bicicletas.",
		group: 'C',
		order: 111
	},
	'procesamiento-de-datos-y-tabulacion': {
		category: 'servicios',
		label: "Procesamiento de datos y tabulación",
		group: 'C',
		order: 112
	},
	'restaurante-pizzeria-casas-de-comidas': {
		category: 'servicios',
		label: "Restaurante-pizzería-casas de comidas",
		group: 'C',
		order: 113
	},
	'taller-mecanico-sup-minima-exigible-80-mt2-mas-20-': {
		category: 'servicios',
		label: "Taller mecánico-sup mínima exigible 80 mt2 más 20 mt2 x persona" +
			" ocupada",
		group: 'C',
		order: 114
	},
	'taller-de-gomeria-balanceo-rep-de-radiadores-canos': {
		category: 'servicios',
		label: "Taller de gomería-balanceo-rep de radiadores-caños de" +
			" escpe-carburos elect sup mínima 50 mt2 más 20 mts2 x persona ocupada." +
			" En bandas se admitirá sólo si se cuenta c/playa de estac. Frontal de" +
			" 10 m de profundidad.",
		group: 'C',
		order: 115
	},
	'taller-de-chapa-y-pintura-sup-exigible-minima-150-': {
		category: 'servicios',
		label: "Taller de chapa y pintura, sup exigible mínima 150 mts2 más 20" +
			" mts2 x persona ocupada",
		group: 'C',
		order: 116
	},
	'taller-de-omnibus-y-colectivos-taller-de-elasticos': {
		category: 'servicios',
		label: "Taller de ómnibus y colectivos-taller de elásticos para vehículos" +
			" de transporte",
		group: 'C',
		order: 117
	},
	'cerrajeria-del-automotor-tapiceria-del-automotor': {
		category: 'servicios',
		label: "Cerrajería del automotor-tapicería del automotor",
		group: 'C',
		order: 118
	},
	'velatorio': {
		category: 'servicios',
		label: "Velatorio",
		group: 'C',
		order: 119
	},
	'tapiceria-de-muebles': {
		category: 'servicios',
		label: "Tapicería de muebles",
		group: 'C',
		order: 120
	},
	'lavadero-automatico-de-autos': {
		category: 'servicios',
		label: "Lavadero automático de autos",
		group: 'C',
		order: 121
	},
	'obrador-de-obras-publicas-yo-privadas': {
		category: 'servicios',
		label: "Obrador de obras públicas y/o privadas",
		group: 'C',
		order: 122
	}
});

Activity.set('typeMap', function () {
	var map = {};
	this.options.itemsListByOrder().forEach(function (item) {
		var category = item.category;
		if (!map[category]) map[category] = [];
		map[category].push(item._subject_);
	});
	return map;
});

Activity.set('groupMap', function () {
	var map = {};
	this.options.itemsListByOrder().forEach(function (item) {
		map[item._subject_] = item.group;
	});
	return map;
});

itemProto = Activity._options._itemPrototype_;

// Rules
User.prototype.getProperties('rule').listByOrder().forEach(function (rel, i) {
	itemProto.set(rel.name, RuleQuestion.rel({ tags: ['rule'], order: i + 1,
		label: rel.label }));
});

itemProto.set('zones', Zone.rel({ multiple: true }));

// Zone properties
itemProto._zones._itemPrototype_.setProperties({
	zoneStatus: Db.String.rel({ value: function () {
		if (this.__forbidden.__value) return 'forbidden';
		if (this.__electricityPotentialMax.__value ||
				this.__peopleCapacityMax.__value ||
				this.__surfaceMax.__value || this.__surfaceMin.__value ||
				(this.__parkingRequirement.__value &&
					this.__parkingRequirement.__value !== 'no') ||
				this.__inspectionMandatory.__value ||
				this.__locInspectionMandatory.__value) {
			return 'restricted';
		}
		return 'open';
	}, triggers: ['forbidden', 'electricityPotentialMax', 'peopleCapacityMax',
		 'surfaceMax', 'surfaceMin', 'parkingRequirement', 'inspectionMandatory',
		 'locInspectionMandatory'] }),
	zoneLabelClass: Db.String.rel({ value: function () {
		var status = this.zoneStatus;
		if (status === 'forbidden') return 'label-red';
		if (status === 'restricted') return 'label-orange';
		return 'label-green';
	}, triggers: ['zoneStatus'] }),
	forbidden: Db.Boolean.rel({ tags: ['zone'], order: 1,
		label: "Actividad prohibida en esta zona" }),
	electricityPotentialMax: HorsePower.rel({ tags: ['zone'], order: 2,
		label: "Potencial electríco máx" }),
	peopleCapacityMax: UInteger.rel({ tags: ['zone'], order: 3,
		label: "Personas máx" }),
	surfaceMax: SquareMeters.rel({ tags: ['zone'], order: 4,
		label: "Superficie máx" }),
	surfaceMin: SquareMeters.rel({ tags: ['zone'], order: 5,
		 label: "Superficie mínima" }),
	parkingRequirement: ZoneParkingRequirement.rel({ tags: ['zone'], order: 6,
		 label: "Estacionamiento" }),
	surfaceMinParking: SquareMeters.rel({ tags: ['zone'], order: 7,
		 label: "Sup. mín. para estacionamiento" }),
	inspectionMandatory: Db.Boolean.rel({ tags: ['zone'], order: 8,
		 label: "Inspección para habilitación" }),
	locInspectionMandatory: Db.Boolean.rel({ tags: ['zone'], order: 9,
		 label: "Comisión especial" })
});

itemProto.setProperties({
	higieneRegistration: Db.Boolean.required,
	higieneRegistrationLabelClass: Db.String.rel({ value: function () {
		var status = this.higieneRegistration;
		if (status == null) return null;
		return status ? 'label-green' : 'label-red';
	}, triggers: ['higieneRegistration'] }),
});

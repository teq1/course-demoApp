'use strict';

var forEach    = require('es5-ext/lib/Object/for-each')
  , mapKeys    = require('es5-ext/lib/Object/map-keys')
  , capitalize = require('es5-ext/lib/String/prototype/capitalize')
  , StringLine = require('dbjs-ext/string/string-line')
  , Province   = require('./province')
  , Department = require('./department');

module.exports = function (/*options*/) {
	var options = Object(arguments[0]), prefix = options.prefix, tag = options.tag
	  , data = {
		street: StringLine.rel({ required: true, label: "Calle", order: 1 }),
		houseNumber: StringLine.rel({ required: true, label: "Número de casa",
			order: 2 }),
		floor: StringLine.rel({ label: "Piso", order: 3 }),
		shop: StringLine.rel({ label: "Departamento", order: 4  }),
		province: Province.rel({ required: true, label: "Provincia",
			value: function () {
				var department = this.department;
				if (!department) return null;
				return this._department.ns.options.getItem(department).province;
			}, triggers: 'department' }),
		department: Department.rel({ required: true, label: "Partido", order: 5 }),
		city: StringLine.rel({ required: true, label: "Localidad", order: 6  })
	};

	if (tag) {
		forEach(data, function (data, name) {
			if (name === 'province') return;
			data.data.tags = tag;
		});
	}
	if (prefix) {
		data = mapKeys(data, function (name) {
			return prefix + capitalize.call(name);
		});
		data[prefix + 'Province'].data.value =
			String(data[prefix + 'Province'].data.value)
			.replace('.department', '.' + prefix + 'Department')
			.replace('._department', '._' + prefix + 'Department');
	}
	return data;
};

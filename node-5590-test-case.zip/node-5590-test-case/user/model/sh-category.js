'use strict';

var Db         = require('dbjs')
  , StringLine = require('dbjs-ext/string/string-line')

  , Criteria = require('./control-criteria')

  , Category;

Category = module.exports = Db.create('SHCategory', {
	label: StringLine.rel({ required: true, label: "Category" }),
	conditions: Criteria.rel({ multiple: true, label: "SH Conditions" }),
	inspectionMandatory: Db.Boolean.rel({ required: true, label: "Inspection" }),
	order: Db.Number.rel({ required: true })
});

Category.newNamed('shCatPublicMassive', { order: 1,
	label: "Local abierto al público con concurencia masiva" });
Category.newNamed('shCatPublic', { order: 2,
	label: "Local abierto al público sin concurencia masiva" });
Category.newNamed('shCatEmploys', { order: 3,
	label: "Empleado(s) trabajando en el local" });
Category.newNamed('shCatFoodSale', { order: 4, label: "Venta de productos" +
	" alimenticios previamente elaborados (y aprobados)" });
Category.newNamed('shCatPrimaryFood', { order: 5,
	label: "Venta de productos alimenticios primarios" });
Category.newNamed('shCatCraftsFood', { order: 6,
	label: "Elaboración artesanal de comida con venta al mostrador" });
Category.newNamed('shCatFoodCounsumption', { order: 7,
	label: "Preparación de comida y bebidas para consumo en el lugar" });
Category.newNamed('shCatFractionedFood', { order: 8,
	label: "Fracciono o peso alimentos" });
Category.newNamed('shCatAlcohol', { order: 9,
	label: "Vendo bebidas alcohólicas" });
Category.newNamed('shCatRedMeat', { order: 10, label: "Vendo carne roja" });
Category.newNamed('shCatWhiteMeat', { order: 11, label: "Vendo carne blanca" });

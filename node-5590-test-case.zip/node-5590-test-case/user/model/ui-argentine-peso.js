'use strict';

module.exports = require('dbjs-ext/number/currency/argentine-peso')
	.create('UIArgentinePeso', { step: 1, min: 0 });

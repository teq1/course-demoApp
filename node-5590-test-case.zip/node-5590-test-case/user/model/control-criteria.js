'use strict';

var Db         = require('dbjs')
  , StringLine = require('dbjs-ext/string/string-line')
  , Url        = require('dbjs-ext/string/string-line/url')

  , Type = require('./control-criteria-type');

module.exports = Db.create('ControlCriteria', {
	type: Type.rel({ required: true, label: "Tipo de control", order: 1,
		tags: ['base'] }),
	overview: Db.String.rel({ required: true, label: "Resumen del control",
		order: 2, tags: ['base'] }),
	law: StringLine.rel({ required: true, label: "Nombre de la ley", order: 3,
		tags: ['base'] }),
	lawUrl: Url.rel({ required: true, label: "Enlace de la ley", order: 4,
		tags: ['base'] }),
	article: StringLine.rel({ required: true, label: "Articulo(s)", order: 5,
		tags: ['base'] }),
	text: Db.String.rel({ required: true, label: "Texto del articulo", order: 6,
		tags: ['base'] })
});

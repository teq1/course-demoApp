'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('PickupInstitution', {
	registrationDepartment: {
		label: "Dirección de habilitación",
		order: 1
	}
});

'use strict';

var Db   = require('dbjs')
  , Enum = require('dbjs-ext/string/string-line/enum')

  , ZonePolygon;

require('./zone');

module.exports = ZonePolygon = Enum.create('ZonePolygon', {
	r100: { zone: 'r10' },
	r110: { zone: 'r11' },
	r120: { zone: 'r12' },
	r210: { zone: 'r21' },
	r211: { zone: 'r21' },
	r220: { zone: 'r22' },
	r221: { zone: 'r22' },
	r310: { zone: 'r31' },
	r311: { zone: 'r31' },
	r312: { zone: 'r31' },
	r313: { zone: 'r31' },
	r320: { zone: 'r32' },
	r321: { zone: 'r32' },
	r322: { zone: 'r32' },
	r323: { zone: 'r32' },
	r324: { zone: 'r32' },
	r325: { zone: 'r32' },
	r326: { zone: 'r32' },
	r330: { zone: 'r33' },
	r331: { zone: 'r33' },
	r410: { zone: 'r41' },
	r411: { zone: 'r41' },
	r412: { zone: 'r41' },
	r413: { zone: 'r41' },
	r420: { zone: 'r42' },
	r421: { zone: 'r42' },
	r422: { zone: 'r42' },
	r423: { zone: 'r42' },
	rn1: { zone: 'rn' },
	rn2: { zone: 'rn' },
	rn3: { zone: 'rn' },
	ie1: { zone: 'ie' },
	ie2: { zone: 'ie' },
	ie3: { zone: 'ie' },
	ia1: { zone: 'ia' },
	ia2: { zone: 'ia' },
	ia3: { zone: 'ia' },
	ib: { zone: 'ib' },
	c1: { zone: 'c1' },
	c210: { zone: 'c21' },
	c211: { zone: 'c21' },
	c220: { zone: 'c22' },
	c221: { zone: 'c22' },
	c223: { zone: 'c22' },
	c224: { zone: 'c22' },
	c225: { zone: 'c22' },
	c226: { zone: 'c22' },
	c227: { zone: 'c22' },
	c228: { zone: 'c22' },
	c230: { zone: 'c23' },
	c231: { zone: 'c23' },
	c232: { zone: 'c23' },
	c233: { zone: 'c23' },
	zue1: { zone: 'zue' },
	zue2: { zone: 'zue' },
	zue3: { zone: 'zue' },
	evp1: { zone: 'evp' },
	evp2: { zone: 'evp' },
	evp3: { zone: 'evp' },
	evp4: { zone: 'evp' },
	re: { zone: 're' }
});

ZonePolygon.set('zoneMap', Db.Base.rel({ value: function () {
	var map = {};
	this.options.itemsListByOrder().forEach(function (item) {
		map[item._subject_] = item.zone;
	});
	return map;
}, external: true }));

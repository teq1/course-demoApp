'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('CompanyType', {
	sa: {
		label: "Sociedad Anónima",
		order: 1
	},
	saMajority: {
		label: "Sociedad Anónima con Participación Estatal Mayoritaria",
		order: 2
	},
	'limited-liability': {
		label: "Sociedad de Responsabilidad Limitada",
		order: 3
	},
	partnership: {
		label: "Sociedad Colectiva",
		order: 4
	},
	limitedPartnership: {
		label: "Sociedad en Comandita Simple",
		order: 5
	},
	capital: {
		label: "Sociedad de Capital e Industria",
		order: 6
	},
	accidental: {
		label: "Sociedad Accidental o en participación",
		order: 7
	},
	sharesLimited: {
		label: "Sociedad en Comandita por Acciones",
		order: 8
	}
});

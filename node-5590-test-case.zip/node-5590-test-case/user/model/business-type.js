'use strict';

var Enum = require('dbjs-ext/string/string-line/enum');

module.exports = Enum.create('BusinessType', {
	'administracion-publica': {
		label: "Administración Pública",
		order: 1
	},
	'comercio-mayorista': {
		label: "Comercio Mayorista",
		order: 2
	},
	'comercio-minorista': {
		label: "Comercio Minorista",
		order: 3
	},
	'cultura-culto-y-esparcimiento': {
		label: "Cultura-culto y esparcimiento",
		order: 4
	},
	'educacion': {
		label: "Educación",
		order: 5
	},
	'infraestructura-de-servicios': {
		label: "Infraestructura de servicios",
		order: 6
	},
	'residencial': {
		label: "Residencial",
		order: 7
	},
	'sanidad': {
		label: "Sanidad",
		order: 8
	},
	'transportes': {
		label: "Transportes",
		order: 9
	},
	'servicios': {
		label: "Servicios",
		order: 10
	}
});

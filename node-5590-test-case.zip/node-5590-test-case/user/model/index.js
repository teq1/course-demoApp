'use strict';

module.exports = require('dbjs');

require('./user');
require('./role');
require('./documents');
require('./documents/submissions');
require('mano-auth/server/client');
require('dbjs-ext/string/string-line/password');

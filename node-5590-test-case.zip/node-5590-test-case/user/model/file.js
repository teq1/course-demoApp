'use strict';

var File      = require('dbjs-ext/object/file')
  , ImageType = require('dbjs-ext/object/file/image-file');

module.exports = File.create('SubmissionFile', {
	preview: ImageType.rel({ required: true }),
	thumb: ImageType.rel({ required: true })
});
ImageType.create('Image');

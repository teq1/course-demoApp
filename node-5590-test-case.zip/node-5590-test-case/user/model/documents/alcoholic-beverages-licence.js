// D015 Licencia provincial para la comercialización de bebidas alcohólicas
// (REBA)

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document')
	.create('AlcoholicBeveragesLicence', {}, {
		label: "Licencia provincial para la comercialización de bebidas" +
			" alcohólicas (REBA)"
	});

extend(Doc.prototype._owner, { reverse: true });

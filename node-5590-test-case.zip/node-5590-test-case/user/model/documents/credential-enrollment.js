// Credencial de la matrícula

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('CredentialEnrollment', {},
	{ label: "Credencial de la matrícula" });

extend(Doc.prototype._owner, { reverse: true });

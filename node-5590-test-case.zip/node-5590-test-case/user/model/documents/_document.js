// Document abstraction

'use strict';

var Db         = require('dbjs')
  , StringLine = require('dbjs-ext/string/string-line')
  , User       = require('../user/base')

  , Document;

Document = module.exports = Db.create('Document', {
	owner: User.rel({ required: true,  reverse: 'documents' })
}, {
	Request: null,
	Submission: null,
	label: StringLine.required,
	abbr: StringLine.required
});

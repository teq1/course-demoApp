// D017 Inventario de bienes de uso estimado sobre costo de origen firmado por
// un Contador y certificación del Colegio de Ciencias Económicas

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('InventoryCertified', {}, {
	label: "Inventario de bienes de uso estimado sobre costo de origen firmado" +
		" por un Contador y certificación del Consejo de Ciencias Económicas"
});

extend(Doc.prototype._owner, { reverse: true });

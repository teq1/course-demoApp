// Planilla autorizada por Colegio de Gestores

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('PayrollByManagers', {}, {
	label: "Planilla autorizada por Colegio de Gestores"
});

extend(Doc.prototype._owner, { reverse: true });

// D006 Recibo de tasa por servicios generales

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('DebtProof', {}, {
	label: "Recibo de tasa por servicios generales"
});

extend(Doc.prototype._owner, { reverse: true });

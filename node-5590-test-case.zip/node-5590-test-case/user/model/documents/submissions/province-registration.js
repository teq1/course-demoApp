'use strict';

var extend   = require('es5-ext/lib/Object/extend')
  , DateType = require('dbjs-ext/date-time/date')
  , Doc      = require('../province-registration')

  , Submission;

Submission = module.exports = Doc.Submission = require('./_submission')
	.create('ProvinceRegistrationSubmission', {
		taxRegistrationDate: DateType.rel({ required: true,
			label: "Fecha de inscripción en el Impuesto", tags: 'revision-ok',
			order: 1 }),
	}, { Document: Doc, validateWithOriginal: true });

extend(Submission.prototype._user, {
	unique: true,
	reverse: true
});

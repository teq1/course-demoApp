'use strict';

var extend     = require('es5-ext/lib/Object/extend')
  , StringLine = require('dbjs-ext/string/string-line')
  , Doc        = require('../water-receipt')

  , Submission;

Submission = module.exports = Doc.Submission = require('./_submission')
	.create('WaterReceiptSubmission', {
		customerNumber: StringLine.rel({ required: true,
			label: "Número de cliente", inputMask: '888888888', tags: 'revision-ok',
			order: 1 }),
	}, { Document: Doc, validateWithOriginal: true });

extend(Submission.prototype._user, {
	unique: true,
	reverse: true
});

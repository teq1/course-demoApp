'use strict';

module.exports = require('./_submission');

require('./alcoholic-beverages-licence.js');
require('./business-certification.js');
require('./credential-enrollment.js');
require('./debt-proof.js');
require('./identity-document.js');
require('./inventory-certified.js');
require('./inventory.js');
require('./mall-registration.js');
require('./minutes-book-sticker.js');
require('./ownership-regulation');
require('./payroll-by-council.js');
require('./payroll-by-managers.js');
require('./pro-shop-plan.js');
require('./product-registration');
require('./province-registration.js');
require('./sanitary-certification.js');
require('./shop-plan.js');
require('./social-status-testimony.js');
require('./store-deed.js');
require('./store-deed-cert.js');
require('./store-lease.js');
require('./store-lease-cert.js');
require('./tax-registration-card.js');
require('./temporary-business-certification.js');
require('./water-receipt.js');

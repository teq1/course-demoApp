'use strict';

var extend   = require('es5-ext/lib/Object/extend')
  , DateType = require('dbjs-ext/date-time/date')
  , Doc      = require('../ownership-regulation')

  , Submission;

Submission = module.exports = Doc.Submission = require('./_submission')
	.create('OwnershipRegulationSubmission', {
		issueDate: DateType.rel({ required: true, label: "Fecha de expedición",
			tags: 'revision-ok', order: 1 }),
	}, { Document: Doc });

extend(Submission.prototype._user, {
	unique: true,
	reverse: true
});

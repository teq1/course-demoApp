'use strict';

var extend     = require('es5-ext/lib/Object/extend')
  , StringLine = require('dbjs-ext/string/string-line')
  , Doc        = require('../identity-document')

  , Submission;

Submission = module.exports = Doc.Submission = require('./_submission')
	.create('IdentityDocumentSubmission', {
		documentNumber: StringLine.rel({ required: true, inputMask: '8888888?8',
			label: "Número de documento", tags: 'revision-ok', order: 1 }),
	}, { Document: Doc, validateWithOriginal: true });

extend(Submission.prototype._user, {
	unique: true,
	reverse: true
});

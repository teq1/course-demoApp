'use strict';

var extend     = require('es5-ext/lib/Object/extend')
  , StringLine = require('dbjs-ext/string/string-line')
  , Doc        = require('../tax-registration-card')

  , Submission;

Submission = module.exports = Doc.Submission = require('./_submission')
	.create('TaxRegistrationCardSubmission', {
		taxIdentificationNumber: StringLine.rel({ required: true,
			label: "Número de CUIT", tags: 'revision-ok', order: 1 }),
	}, { Document: Doc });

extend(Submission.prototype._user, {
	unique: true,
	reverse: true
});

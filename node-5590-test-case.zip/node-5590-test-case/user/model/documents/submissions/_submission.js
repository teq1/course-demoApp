// Submission abstraction

'use strict';

var Db           = require('dbjs')
  , StringLine   = require('dbjs-ext/string/string-line')
  , File         = require('../../file')
  , User         = require('../../user/base')
  , RejectReason = require('../../reject-reason');

module.exports = Db.create('DocumentSubmission', {
	user: User.rel({
		required: true,
		writeOnce: true,
		reverse: 'submissions'
	}),
	files: File.rel({ multiple: true, unique: true, reverse: 'submission' }),
	approved: Db.Boolean.rel({ required: true, trueLabel: "Si",
		falseLabel: "No" }),
	matchesOriginal: Db.Boolean.rel({ required: true }),
	rejectReasonType: RejectReason.rel({ required: true,
		label: "Rechazar documentos" }),
	rejectReasonMemo: Db.String.rel({ required: true, label: "Explicación" }),
	rejectReason: StringLine.rel({ tags: 'revision-fail', order: 1,
		label: "Rechazar documentos", value: function () {
		var type = this.rejectReasonType;
		return (type === 'other') ? (this.rejectReasonMemo || null) : type;
	}, triggers: ['rejectReasonType', 'rejectReasonMemo'],
		selectField: 'rejectReasonType', otherField: 'rejectReasonMemo' }),

	isApproved: Db.Boolean.rel({ value: function () {
		if (this.approved == null) return null;
		if (this.approved) return true;
		if (this.rejectReason == null) return null;
		return false;
	}, triggers: ['approved', 'rejectReason'] })
}, {
	validateWithOriginal: Db.Boolean.rel({ required: true, value: false }),
});

'use strict';

var extend   = require('es5-ext/lib/Object/extend')
  , DateType = require('dbjs-ext/date-time/date')
  , Doc      = require('../sanitary-certification')

  , Submission;

Submission = module.exports = Doc.Submission = require('./_submission')
	.create('SanitaryCertificationSubmission', {
		expirationDate: DateType.rel({ required: true,
			label: "Fecha de vencimiento", tags: 'revision-ok', order: 1 }),
	}, { Document: Doc });

extend(Submission.prototype._user, {
	unique: true,
	reverse: true
});

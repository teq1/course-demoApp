// D008 Croquis o plano de obra

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('ShopPlan', {}, {
	label: "Croquis o plano de obra"
});

extend(Doc.prototype._owner, { reverse: true });

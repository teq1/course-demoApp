// D010 Inscripción ante ARBA

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('ProvinceRegistration', {},
	{
		label: "Inscripción ante ARBA"
	});

extend(Doc.prototype._owner, { reverse: true });

// D013 Contrato de locación con firma certificada por escribano público

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('StoreLease', {}, {
	label: "Contrato de locación"
});

extend(Doc.prototype._owner, { reverse: true });

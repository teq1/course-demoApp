// Planilla autorizada por Consejo de contadores

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('PayrollByCouncil', {}, {
	label: "Planilla autorizada por Consejo de contadores"
});

extend(Doc.prototype._owner, { reverse: true });

// D004 Libreta sanitaria

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('SanitaryCertification',
	{}, {
		label: "Libreta sanitaria"
	});

extend(Doc.prototype._owner, { reverse: true });

// D003 Sello de libro de actas

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('MinutesBookSticker', {}, {
	label: "Sello de libro de actas"
});

extend(Doc.prototype._owner, { reverse: true });

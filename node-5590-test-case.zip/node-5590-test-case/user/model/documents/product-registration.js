// D018 Inscripción de productos

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('ProductRegistration', {},
	{ label: "Inscripción de productos" });

extend(Doc.prototype._owner, { reverse: true });

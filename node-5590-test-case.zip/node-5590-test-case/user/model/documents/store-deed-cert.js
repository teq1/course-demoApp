// D012bis Testimonio de escritura pública del local con firma certificada por
// escribano público

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('StoreDeedCert', {}, {
	label: "Testimonio de escritura pública del local con firma certificada por" +
		" escribano público"
});

extend(Doc.prototype._owner, { reverse: true });

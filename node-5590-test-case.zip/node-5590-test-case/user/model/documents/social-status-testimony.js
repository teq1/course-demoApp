// Testimonio del estatuto social

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('SocialStatusTestimony',
	{}, { label: "Testimonio del estatuto social" });

extend(Doc.prototype._owner, { reverse: true });

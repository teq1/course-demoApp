'use strict';

module.exports = require('./_document');

require('./alcoholic-beverages-licence');
require('./business-certification');
require('./credential-enrollment');
require('./debt-proof');
require('./identity-document');
require('./inventory');
require('./inventory-certified');
require('./mall-registration');
require('./minutes-book-sticker');
require('./ownership-regulation');
require('./payroll-by-council');
require('./payroll-by-managers');
require('./pro-shop-plan');
require('./product-registration');
require('./province-registration');
require('./sanitary-certification');
require('./shop-plan');
require('./social-status-testimony');
require('./store-deed');
require('./store-deed-cert');
require('./store-lease');
require('./store-lease-cert');
require('./tax-registration-card');
require('./temporary-business-certification');
require('./water-receipt');

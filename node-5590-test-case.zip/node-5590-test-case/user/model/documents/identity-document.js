// D011 Documento de identidad (con domicilio actualizado)

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('IdentityDocument', {}, {
	label: "Documento de identidad (con domicilio actualizado)"
});

extend(Doc.prototype._owner, { reverse: true });

// D007 Recibo de EDESUR

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('WaterReceipt', {}, {
	label: "Recibo de EDESUR"
});

extend(Doc.prototype._owner, { reverse: true });

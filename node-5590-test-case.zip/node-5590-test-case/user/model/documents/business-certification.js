// D001 Certificado de habilitación

'use strict';

var extend = require('es5-ext/lib/Object/extend')

  , Doc;

Doc = module.exports = require('./_document').create('BusinessCertification',
	{}, {
		label: "Certificado de habilitación"
	});

extend(Doc.prototype._owner, { reverse: true });

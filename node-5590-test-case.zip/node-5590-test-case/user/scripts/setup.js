'use strict';

var deferred  = require('deferred')
  , resolve   = require('path').resolve
  , writeFile = require('fs2/lib/write-file')
  , Db        = require('dbjs')

  , stringify = JSON.stringify;

module.exports = deferred(
	writeFile(resolve(__dirname, '../client/legacy/province-labels.js'),
		'\'use strict\';\n\nmodule.exports = ' +
		stringify(Db.ArgentinaProvinces.labels) + ';\n'),

	writeFile(resolve(__dirname, '../client/legacy/province-map.js'),
		'\'use strict\';\n\nmodule.exports = ' +
		stringify(Db.ArgentinaDepartment.provinceMap) + ';\n'),

	writeFile(resolve(__dirname, '../client/legacy/business-type-labels.js'),
		'\'use strict\';\n\nmodule.exports = ' +
		stringify(Db.BusinessType.labels) + ';\n'),

	writeFile(resolve(__dirname, '../client/legacy/business-type-map.js'),
		'\'use strict\';\n\nmodule.exports = ' +
		stringify(Db.BusinessActivity.typeMap) + ';\n')
);

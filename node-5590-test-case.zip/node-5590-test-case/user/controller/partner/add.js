'use strict';

var dbjsValidate = require('mano/lib/utils/dbjs-form-validate');

module.exports = function (data, env) {
	dbjsValidate(data, { changedOnly: true });
};

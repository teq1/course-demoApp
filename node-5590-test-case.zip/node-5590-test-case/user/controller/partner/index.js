'use strict';

var dbjsValidate = require('mano/lib/utils/dbjs-form-validate')
  , User         = require('dbjs/lib/objects')._get('User')
  , isId         = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/);

exports.match = function (path, env) {
	var method, user;
	path = path.split('/');
	if (path.length > 2) return false;
	user = path[0];
	if (!isId(user)) return false;
	user = User[user];
	if (!env.user.partners.has(user)) return false;
	if (path[1] == null) method = 'edit';
	else if (path[1] === 'delete') method = 'delete';
	else if (path[1] === 'address') method = 'edit-address';
	else return false;
	env.method = method;
	env.target = user;
	return true;
};

exports.load = function (data, env) {
	if (env.method !== 'delete') dbjsValidate(data, { changedOnly: true });
};

'use strict';

var CustomError = require('es5-ext/lib/Error/custom')
  , Db          = require('dbjs')

  , isArray = Array.isArray
  , mimes = { 'image/jpeg': 'jpg', 'application/pdf': 'pdf',
		'image/png': 'png' };

module.exports = function (data, env) {
	var Submission;
	if (!data.file) data.file = [];
	if (!isArray(data.file)) data.file = [data.file];
	data.file.some(function (file) {
		if (!mimes.hasOwnProperty(file.type)) {
			throw new CustomError("Unsupported file type", 'UNSUPPORTED_TYPE',
				{ statusCode: 400 });
		}
	});

	Submission = Db[env.action.query.doc];
	if ((Submission == null) ||
			!Db.DocumentSubmission.isPrototypeOf(Submission)) {
		throw new CustomError("Unrecognized submission document type",
			'UNRECOGNIZED_SUBMISSION', { statusCode: 400 });
	}
};

'use strict';

var dbjsValidate = require('mano/lib/utils/dbjs-form-validate')
  , validate     = require('mano/lib/utils/controller-validate')
  , controller   = require('mano-auth/controller/change-own-password');

module.exports = function (data) {
	dbjsValidate(data, { partial: true, changedOnly: true });
	if (!data.password && !data['password-new']) {
		delete data.password;
		delete data['password-new'];
	} else {
		validate(controller, data);
		if (data.password === data['password-new']) {
			delete data.password;
			delete data['password-new'];
		}
	}
};

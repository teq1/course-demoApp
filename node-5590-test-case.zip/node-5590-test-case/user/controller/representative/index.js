'use strict';

var dbjsValidate   = require('mano/lib/utils/dbjs-form-validate')
  , Representative = require('dbjs/lib/objects')._get('CompanyRepresentative')
  , isId           = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/);

exports.match = function (path, env) {
	var method, representative;
	path = path.split('/');
	if (path.length > 2) return false;
	representative = path[0];
	if (!isId(representative)) return false;
	representative = Representative[representative];
	if (!env.user.representatives.has(representative)) return false;
	if (path[1] == null) method = 'edit';
	else if (path[1] === 'delete') method = 'delete';
	else return false;
	env.method = method;
	env.target = representative;
	return true;
};

exports.load = function (data, env) {
	if (env.method !== 'delete') dbjsValidate(data, { changedOnly: true });
};

'use strict';

var noop           = require('es5-ext/lib/Function/noop')
  , SubmissionFile = require('dbjs/lib/objects')._get('SubmissionFile')
  , isId           = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/);

exports.match = function (path, env) {
	if (!isId(path)) return false;
	if (!SubmissionFile[path]) return false;
	env.target = SubmissionFile[path];
	return true;
};

exports.load = noop;

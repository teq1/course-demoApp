'use strict';

var StringLine = require('dbjs-ext/string/string-line')
  , User       = require('mano-auth/model/user')

  , user = User.prototype;

user.setProperties({
	firstName: StringLine.rel({ required: true, label: "Nombre",
		order: -2, tags: 'register' }),
	lastName: StringLine.rel({ required: true, label: "Apellido",
		order: -1, tags: 'register' })
});

user._email.label = "Correo electrónico";
user._email.tags.add('register');
user._password.label = "Contraseña";
user._password.tags.add('register');

module.exports = User;

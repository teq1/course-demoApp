'use strict';

var auth = require('mano-auth/controller');

exports.login = auth.login;
exports.register = auth.register;
exports['forgot-password'] = auth['forgot-password'];

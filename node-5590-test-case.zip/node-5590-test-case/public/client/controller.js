'use strict';

var auth = require('mano-auth/client/controller');

exports.login = auth.login;
exports.register = auth.register;

'use strict';

require('mano/lib/client')({
	schema: function () {
		var Db = require('./model.generated');
		Db.User.prototype._password.ns = Db.Password;

		require('dbjs-dom/text');
		require('dbjs-dom/input');
		require('dbjs-dom/input/string/string-line');
		require('dbjs-dom/input/string/string-line/email');
		require('dbjs-dom/input/string/string-line/password');
	},
	viewRequire: require('../../view/public/_require'),
	routes: function (router, view) {
		router.get = require('../../view/public/_routes')(view);
		router.post = require('mano/lib/client/build-controller')(
			require('../controller'),
			require('./controller')
		);
	}
});

'use strict';

var controller = require('mano-auth/server/controller')
  , auth       = require('mano/lib/server/server/auth');

exports.login = controller.login;
exports['login-x'] = controller['login-x'];
exports.register = controller.register;
exports['register-x'] = {
	validate: controller['register-x'].validate,
	controller: function (data, env) {
		return controller['register-x'].controller(data, env)(function (user) {
			user.roles.add('user');
			auth.grant(user, env.req, env.res);
			return { url: '/', reload: true, waitFor: user._id_ };
		});
	}
};

exports['forgot-password'] = controller['forgot-password'];

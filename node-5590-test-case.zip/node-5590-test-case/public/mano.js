'use strict';

exports.route = function (req) { return !req.$user; };
exports.order = 1;
exports.viewPath = '../view/public';

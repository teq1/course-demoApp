'use strict';

require('mano/lib/client')({
	schema: function () {
		var Db = require('./model.generated');
		Db.User.prototype._password.ns = Db.Password;
		require('../../../user/model/user/_activity-rules');

		require('dbjs-dom/text');
		require('dbjs-dom/text/string/string-line/enum');
		require('dbjs-dom/text/utils/table');
		require('dbjs-dom/ext/domjs/table-cell-render');
		require('dbjs-dom/input');
		require('dbjs-dom/input/date-time');
		require('dbjs-dom/input/date-time/date');
		require('dbjs-dom/input/string/string-line');
		require('dbjs-dom/input/string/string-line/email');
		require('dbjs-dom/input/string/string-line/enum').chooseLabel =
			'Seleccione:';
		require('dbjs-dom/input/string/string-line/password');
		require('dbjs-dom/input/utils/fieldset');

		require('dbjs-dom-bootstrap/number/square-meters');
	},
	viewRequire: require('../../../view/official/loc-inspection-report/_require'),
	routes: function (router, view) {
		var Table = require('dbjs-dom/text/utils/table');
		Table.prototype.domjs = view.engine;

		router.get =
			require('../../../view/official/loc-inspection-report/_routes')(view);
		router.post = require('mano/lib/client/build-controller')(
			require('../controller'),
			require('./controller')
		);
	}
});

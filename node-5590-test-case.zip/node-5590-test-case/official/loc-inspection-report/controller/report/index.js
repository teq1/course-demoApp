'use strict';

var dbjsValidate  = require('mano/lib/utils/dbjs-form-validate')
  , getObject     = require('dbjs/lib/objects')._get
  , isId          = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/)

  , User = getObject('User');

exports.match = function (path, env) {
	var user;
	if (!isId(path)) return false;
	user = User[path];
	if (!user || !user.isLocInspectionReady) return false;
	if (user.isLocInspectionSatisfactory != null) return false;
	env.target = user;
	return true;
};

exports.load = function (data, env) {
	dbjsValidate(data, { changedOnly: true });
};

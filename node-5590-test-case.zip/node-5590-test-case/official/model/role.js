'use strict';

var Role = require('../../user/model/role')
  , user = require('../../user/model/user/base').prototype

  , SubRole;

module.exports = Role;

Role.options.add('official').setProperties({
	label: "Oficial",
	order: 20,
	Role: SubRole = Role.create('OfficialRole')
});
SubRole.$set('options', null);

user._roles._itemPrototype_.set('roles',
	SubRole.rel({ multiple: true, label: "Oficio" }));

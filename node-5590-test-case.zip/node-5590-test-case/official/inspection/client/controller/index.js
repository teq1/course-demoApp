'use strict';

module.exports = {
	'inspection-dates&': require('./inspection-dates'),
	profile:             require('../../../../user/client/controller/profile')
};

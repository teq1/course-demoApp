'use strict';

var save     = require('mano/lib/utils/dbjs-form-save')
  , location = require('mano/lib/client/location');

module.exports = function (data, env) {
	save(data);
	location.goto();
};

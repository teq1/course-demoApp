'use strict';

module.exports = require('mano/lib/utils/dbjs-form-save');

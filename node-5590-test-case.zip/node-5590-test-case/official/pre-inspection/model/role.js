'use strict';

var d         = require('es5-ext/lib/Object/descriptor')
  , Db        = require('dbjs')
  , Role      = require('../../model/role').options.getItem('official').Role
  , uAccess   = require('mano-auth/server/user-access')
  , bFragment = require('../../../schema-admin/server/business-activity-access')

  , role;

module.exports = Role;

role = Role.options.add('pre-inspection');
role.setProperties({
	label: "Dirección de inspección previa fecha",
	order: 2.6
});

Object.defineProperty(role, 'access', d(uAccess(function () {
	return Db.User.prototype._isDebtCleared.indexFilter(true)
		.filterByProperty('isPreInspectionApplicable', true)
		.filterByProperty('isPreInspectionScheduled', null);
}, bFragment)));

'use strict';

var dbjsValidate  = require('mano/lib/utils/dbjs-form-validate')
  , getObject     = require('dbjs/lib/objects')._get
  , isId          = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/)

  , User = getObject('User'), DateType = getObject('Date');

exports.match = function (path, env) {
	var user;
	if (!isId(path)) return false;
	user = User[path];
	if (!user || !user.isDebtCleared) return false;
	if (!user.isPreInspectionApplicable) return false;
	if (user.isPreInspectionScheduled) return false;
	env.target = user;
	return true;
};

exports.load = function (data, env) {
	var user = env.target, today = new DateType();
	dbjsValidate(data, { changedOnly: true });
	if (data[user._preInspectionDateFrom._id_] >
			data[user._preInspectionDateTo._id_]) {
		throw new TypeError("Invalid date range");
	}
	if (data[user._preInspectionDateFrom._id_] < today) {
		throw new TypeError("Date cannot be past");
	}
};

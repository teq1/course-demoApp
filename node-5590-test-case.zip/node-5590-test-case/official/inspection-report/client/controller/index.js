'use strict';

module.exports = {
	'report&': require('./report'),
	profile:   require('../../../../user/client/controller/profile')
};

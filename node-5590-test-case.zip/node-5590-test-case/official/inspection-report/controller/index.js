'use strict';

module.exports = {
	'report&': require('./report'),
	profile:   require('../../../user/controller/profile')
};

'use strict';

module.exports = function (data, env) {
	env.target.treasuryPaymentReceiptSent = true;
};

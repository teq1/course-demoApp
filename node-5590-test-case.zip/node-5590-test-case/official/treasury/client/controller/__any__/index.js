'use strict';

var send   = require('./receipt-send')
  , upload = require('./receipt-upload')
  , remove = require('./receipt-delete');

module.exports = function (data, env) {
	if (env.method === 'upload') return upload(data, env);
	if (env.method === 'send') return send(data, env);
	if (env.method === 'delete') return remove(data, env);
	throw new TypeError("Unrecognized method");
};

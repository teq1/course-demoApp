'use strict';

var User   = require('dbjs/lib/objects')._get('User')
  , send   = require('./receipt-send')
  , upload = require('./receipt-upload')
  , remove = require('./receipt-delete')

  , isId = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/)
  , supportedMethods =
	{ 'receipt-upload': true, 'receipt-send': true, 'receipt-delete': true };

exports.match = function (path, env) {
	var user, method;
	path = path.split('/');
	if (path.length !== 2) return false;
	user = path[0];
	if (!isId(user)) return false;
	user = User[user];
	if (!user || !user.isMinutesStickerGenerated) return false;
	if (user.isTreasuryPaymentReceived != null) return false;
	method = path[1];
	if (!supportedMethods.hasOwnProperty(method)) return false;
	env.method = method.slice('receipt-'.length);
	env.target = user;
	return true;
};

exports.load = function (data, env) {
	if (env.method === 'upload') return upload(data, env);
	if (env.method === 'send') return send(data, env);
	if (env.method === 'delete') return remove(data, env);
	throw new TypeError("Unrecognized method");
};

'use strict';

var dbjsValidate  = require('mano/lib/utils/dbjs-form-validate')
  , User          = require('dbjs/lib/objects')._get('User')
  , isId          = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/);

exports.match = function (path, env) {
	var user;
	if (!isId(path)) return false;
	user = User[path];
	if (!user || !user.isRevisionApproved) return false;
	if (user.hasHygieneDebt != null) return false;
	env.target = user;
	return true;
};

exports.load = function (data) { dbjsValidate(data, { changedOnly: true }); };

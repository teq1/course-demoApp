'use strict';

var User = require('../../../user-submitted/model/user');

module.exports = User;

User.prototype._hasDebt.setProperties({
	trueLabel: "Deuda a la fecha:",
	falseLabel: "La propiedad no tiene deuda."
});

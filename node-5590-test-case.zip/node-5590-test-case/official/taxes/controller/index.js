'use strict';

module.exports = {
	'debt&': require('./debt'),
	profile: require('../../../user/controller/profile')
};

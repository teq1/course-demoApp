'use strict';

module.exports = {
	'debt&': require('./debt'),
	profile: require('../../../../user/client/controller/profile')
};

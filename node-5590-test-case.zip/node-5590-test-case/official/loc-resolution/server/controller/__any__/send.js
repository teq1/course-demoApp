'use strict';

var dbjsSave = require('mano/lib/utils/dbjs-form-save');

module.exports = function (data, env) {
	dbjsSave(data);
	if (env.target.locResolutionSatisfactory && !env.target.locResolution) return;
	env.target.locResolutionSent = true;
};

'use strict';

var deferred = require('deferred')
  , Db       = require('dbjs')
  , fs       = require('fs')
  , resolve  = require('path').resolve
  , gm       = require('gm')

  , promisify = deferred.promisify, rename = promisify(fs.rename)
  , filesPath = resolve(__dirname, '../../../../../uploads');

gm.prototype.writeP = promisify(gm.prototype.write);

module.exports = function (data, env) {
	var user = env.target, file = data.file, dbFile, ext
	  , path, thumbPath, previewPath;

	dbFile = new Db.SubmissionFile();
	ext = '.' + file.name;
	path = dbFile._id_ + ext;
	if (file.type !== 'image/jpeg') ext += '.jpg';
	thumbPath = dbFile._id_ + '.thumb' + ext;
	previewPath = dbFile._id_ + ext;

	return rename(file.path, resolve(filesPath, path))(function () {
		var filePath = path, thumb, preview;
		if (file.type === 'application/pdf') filePath += '[0]';
		thumb = gm(resolve(filesPath, filePath)).resize(500, 500)
			.writeP(resolve(filesPath, thumbPath));
		if (path !== previewPath) {
			preview = gm(resolve(filesPath, filePath)).resize(1500, 1500)
				.writeP(resolve(filesPath, previewPath));
		}
		return deferred(thumb, preview);
	})(function () {
		var thumb, preview;
		dbFile.dir = resolve(filesPath, path);
		dbFile.url = '/' + encodeURIComponent(path);
		dbFile.name = file.name;
		dbFile.size = file.size;

		thumb = new Db.Image();
		thumb.dir = resolve(filesPath, thumbPath);
		thumb.url = '/' + encodeURIComponent(thumbPath);
		thumb.name = file.name;
		dbFile.thumb = thumb;

		preview = new Db.Image();
		preview.dir = resolve(filesPath, previewPath);
		preview.url = '/' + encodeURIComponent(previewPath);
		preview.name = file.name;
		dbFile.preview = preview;

		user.locResolution = dbFile;
		return true;
	});
};

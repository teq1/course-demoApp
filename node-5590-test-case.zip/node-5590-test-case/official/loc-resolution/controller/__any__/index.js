'use strict';

var User   = require('dbjs/lib/objects')._get('User')
  , send   = require('./send')
  , upload = require('./upload')
  , remove = require('./delete')

  , isId = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/)
  , supportedMethods = { 'upload': true, 'send': true, 'delete': true };

exports.match = function (path, env) {
	var user, method;
	path = path.split('/');
	if (path.length !== 2) return false;
	user = path[0];
	if (!isId(user)) return false;
	user = User[user];
	if (!user || !user.isLocInspectionSatisfactory) return false;
	if (user.isLocResolutionSatisfactory != null) return false;
	method = path[1];
	if (!supportedMethods.hasOwnProperty(method)) return false;
	env.method = method;
	env.target = user;
	return true;
};

exports.load = function (data, env) {
	if (env.method === 'upload') return upload(data, env);
	if (env.method === 'send') return send(data, env);
	if (env.method === 'delete') return remove(data, env);
	throw new TypeError("Unrecognized method");
};

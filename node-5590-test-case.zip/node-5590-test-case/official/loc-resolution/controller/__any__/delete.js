'use strict';

var CustomError = require('es5-ext/lib/Error/custom');

module.exports = function (data, env) {
	if (!env.target.locResolution) {
		throw new CustomError('Missing resolution document', 'FILE_NOT_FOUND',
			{ statusCode: 400 });
	}
};

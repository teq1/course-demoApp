'use strict';

window.$ = require('mano-legacy');

require('mano-legacy/radio-match');
require('domjs-ext/post-button.legacy');

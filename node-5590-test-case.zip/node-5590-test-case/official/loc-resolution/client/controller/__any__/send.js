'use strict';

var location = require('mano/lib/client/location')
  , dbjsSave = require('mano/lib/utils/dbjs-form-save');

module.exports = function (data, env) {
	dbjsSave(data);
	if (env.target.locResolutionSatisfactory && !env.target.locResolution) return;
	env.target.locResolutionSent = true;
	location.goto();
};

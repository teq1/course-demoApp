'use strict';

var CustomError = require('es5-ext/lib/Error/custom');

module.exports = function (data, env) {
	if (!env.target.habilitation) {
		throw new CustomError('Missing habilitation', 'HABILITATION_NOT_FOUND',
			{ statusCode: 400 });
	}
};

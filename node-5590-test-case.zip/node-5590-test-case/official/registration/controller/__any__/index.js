'use strict';

var startsWith = require('es5-ext/lib/String/prototype/starts-with')
  , User       = require('dbjs/lib/objects')._get('User')
  , send       = require('./habilitation-send')
  , upload     = require('./habilitation-upload')
  , remove     = require('./habilitation-delete')
  , validate   = require('./validate-docs')

  , isId = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/)
  , supportedMethods =
	{ 'habilitation-upload': true, 'habilitation-send': true,
		'habilitation-delete': true, 'validate-docs': true };

exports.match = function (path, env) {
	var user, method;
	path = path.split('/');
	if (path.length !== 2) return false;
	user = path[0];
	if (!isId(user)) return false;
	user = User[user];
	if (!user || !user.isTreasuryPaymentReceived) return false;
	if (user.isHabilitationReceived != null) return false;
	method = path[1];
	if (!supportedMethods.hasOwnProperty(method)) return false;
	env.method = startsWith.call(method, 'habilitation') ?
			method.slice('habilitation-'.length) : method;
	env.target = user;
	return true;
};

exports.load = function (data, env) {
	if (env.method === 'upload') return upload(data, env);
	if (env.method === 'send') return send(data, env);
	if (env.method === 'delete') return remove(data, env);
	if (env.method === 'validate-docs') return validate(data, env);
	throw new TypeError("Unrecognized method");
};

'use strict';

module.exports = function (data, env) {
	env.target.habilitationSent = true;
};

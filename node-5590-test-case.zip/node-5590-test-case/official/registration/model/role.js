'use strict';

var d         = require('es5-ext/lib/Object/descriptor')
  , Db        = require('dbjs')
  , Role      = require('../../model/role').options.getItem('official').Role
  , uAccess   = require('mano-auth/server/user-access')
  , bFragment = require('../../../schema-admin/server/business-activity-access')

  , role;

module.exports = Role;

role = Role.options.add('registration');
role.setProperties({
	label: "Dirección de habilitación",
	order: 6
});

Object.defineProperty(role, 'access', d(uAccess(function () {
	return Db.User.prototype._isTreasuryPaymentReceived.indexFilter(true)
		.filterByProperty('isHabilitationReceived', null);
}, bFragment)));

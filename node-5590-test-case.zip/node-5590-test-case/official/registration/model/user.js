'use strict';

var StringLine = require('dbjs-ext/string/string-line')
  , User       = require('../../../user-submitted/model/user');

module.exports = User;

require('../../../user/model/documents/submissions');

User.prototype.set('submissionsToValidate',
	StringLine.rel({ multiple: true, value: function () {
		var subs = this.requiredSubmissions;
		if (!subs) return [];
		return subs.values.filter(function (name) {
			var Sub = this[name[0].toUpperCase() + name.slice(1) + 'Submission'];
			return Sub.validateWithOriginal;
		}, this.Db);
	}, triggers: 'requiredSubmissions' }));

'use strict';

var location = require('mano/lib/client/location');

module.exports = function (data, env) {
	env.target.habilitationSent = true;
	location.goto();
};

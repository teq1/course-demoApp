'use strict';

var send     = require('./habilitation-send')
  , upload   = require('./habilitation-upload')
  , remove   = require('./habilitation-delete')
  , validate = require('./validate-docs');

module.exports = function (data, env) {
	if (env.method === 'upload') return upload(data, env);
	if (env.method === 'send') return send(data, env);
	if (env.method === 'delete') return remove(data, env);
	if (env.method === 'validate-docs') return validate(data, env);
	throw new TypeError("Unrecognized method");
};

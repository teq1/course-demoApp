'use strict';

module.exports = {
	profile:     require('../../../user/controller/profile'),
	'revision&': require('./revision')
};

'use strict';

var hyphenToCamel = require('es5-ext/lib/String/prototype/hyphen-to-camel')
  , dbjsValidate  = require('mano/lib/utils/dbjs-form-validate')
  , User          = require('dbjs/lib/objects')._get('User')
  , isId          = RegExp.prototype.test.bind(/^\d[a-z0-9]+$/);

exports.match = function (path, env) {
	var user, sub;
	path = path.split('/');
	if (path.length !== 2) return false;
	user = path[0];
	if (!isId(user)) return false;
	user = User[user];
	if (!user || !user.isApplicationRegistered) return false;
	if (user.isRevisionApproved != null) return false;
	sub = path[1];
	if (!sub) return false;
	if (sub === 'approve') {
		if (!user.submissionsApproved) return false;
		env.method = 'approve';
	} else if (sub === 'reject') {
		if (user.submissionsApproved !== false) return false;
		env.method = 'reject';
	} else {
		sub = hyphenToCamel.call(sub);
		if (!user.requiredSubmissions.has(sub)) return false;
		sub = sub + 'Submission';
		if (!user[sub]) return false;
		env.submission = user[sub];
	}
	env.target = user;
	return true;
};

exports.load = function (data) { dbjsValidate(data, { changedOnly: true }); };

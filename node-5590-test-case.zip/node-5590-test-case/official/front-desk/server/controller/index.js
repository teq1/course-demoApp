'use strict';

var cpCtrl      = require('mano-auth/server/controller/change-own-password-x')
  , profileCtrl = require('../../../../user/server/controller/profile');

module.exports = {
	'change-own-password-x': cpCtrl,
	profile:                 profileCtrl,
	'revision&':             require('./revision')
};

'use strict';

var save = require('mano/lib/utils/dbjs-form-save');

module.exports = function (data, env) {
	var user = env.target;
	save(data);
	if (env.method === 'approve') user.revisionApproved = true;
	else if (env.method === 'reject') user.revisionApproved = false;
	else if (user.revisionApproved != null) user.revisionApproved = null;
};

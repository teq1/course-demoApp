'use strict';

exports.route = function (req) {
	var roles = req.$user.roles;
	if (!roles.has('official')) return false;
	roles = roles.getItem('official').roles;
	return roles.has('front-desk');
};
exports.order = 21;
exports.viewPath = '../../view/official/front-desk';

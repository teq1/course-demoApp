'use strict';

var User = require('../../../user-submitted/model/user');

module.exports = User;

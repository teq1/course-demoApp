'use strict';

module.exports = {
	profile:     require('../../../../user/client/controller/profile'),
	'revision&': require('./revision')
};

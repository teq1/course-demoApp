'use strict';

var save     = require('mano/lib/utils/dbjs-form-save')
  , location = require('mano/lib/client/location');

module.exports = function (data, env) {
	var user = env.target;
	save(data);
	if (env.method === 'approve') {
		user.revisionApproved = true;
	} else if (env.method === 'reject') {
		user.revisionApproved = false;
	} else {
		if (user.revisionApproved != null) user.revisionApproved = null;
		return;
	}
	location.goto();
};

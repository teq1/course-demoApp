'use strict';

window.$ = require('mano-legacy');

require('mano-legacy/radio-match');

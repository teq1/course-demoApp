'use strict';

var User     = require('../model/user')
  , Password = require('dbjs-ext/string/string-line/password')

  , user = User.prototype;

user._password.ns = Password;
require('../../../user/model/documents');
require('../../../user/model/documents/submissions');

module.exports = require('dbjs');

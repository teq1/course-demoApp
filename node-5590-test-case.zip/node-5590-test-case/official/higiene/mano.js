'use strict';

exports.route = function (req) {
	var roles = req.$user.roles;
	if (!roles.has('official')) return false;
	roles = roles.getItem('official').roles;
	return roles.has('higiene');
};
exports.order = 25;
exports.viewPath = '../../view/official/higiene';

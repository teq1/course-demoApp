'use strict';

module.exports = require('../../../user-submitted/model/user');

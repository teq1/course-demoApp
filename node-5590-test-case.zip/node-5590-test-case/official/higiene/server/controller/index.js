'use strict';

var cpCtrl      = require('mano-auth/server/controller/change-own-password-x')
  , profileCtrl = require('../../../../user/server/controller/profile');

module.exports = {
	'/&':                    require('./__any__'),
	'change-own-password-x': cpCtrl,
	profile:                 profileCtrl,
};

'use strict';

module.exports = function (data, env) {
	env.target.minutesStickerSent = true;
};

'use strict';

window.$ = require('mano-legacy');

require('domjs-ext/post-button.legacy');

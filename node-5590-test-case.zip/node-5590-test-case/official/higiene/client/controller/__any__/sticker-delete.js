'use strict';

module.exports = function (data, env) {
	env.target.minutesSticker.delete();
};

'use strict';

module.exports = {
	'/&':    require('./__any__'),
	profile: require('../../../user/controller/profile')
};

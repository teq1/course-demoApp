'use strict';

var CustomError = require('es5-ext/lib/Error/custom')

  , isArray = Array.isArray
  , mimes = { 'image/jpeg': 'jpg', 'application/pdf': 'pdf',
		'image/png': 'png' };

module.exports = function (data, env) {
	if (!data.file) {
		throw new CustomError("Missing file", 'MISSING_FILE', { statusCode: 400 });
	}
	if (isArray(data.file)) {
		throw new CustomError("Too many files", 'MULTIPLE_UPLOAD',
			{ statusCode: 400 });
	}
	if (!mimes.hasOwnProperty(data.file.type)) {
		throw new CustomError("Unsupported file type", 'UNSUPPORTED_TYPE',
			{ statusCode: 400 });
	}
};

'use strict';

var CustomError = require('es5-ext/lib/Error/custom');

module.exports = function (data, env) {
	if (!env.target.minutesSticker) {
		throw new CustomError('Missing sticker', 'STICKER_NOT_FOUND',
			{ statusCode: 400 });
	}
};

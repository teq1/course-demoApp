'use strict';

module.exports = {
	profile:             require('../../user/controller/profile'),
	revise:              require('./revise'),
	'revise-debt':       require('./revise-debt'),
	'revise-inspection': require('./revise-debt')
};

'use strict';

module.exports = require('es5-ext/lib/Function/noop');

'use strict';

module.exports = {
	profile:             require('../../../user/client/controller/profile'),
	revise:              require('./revise'),
	'revise-debt':       require('./revise-debt'),
	'revise-inspection': require('./revise-inspection')
};

'use strict';

module.exports = function (data, env) {
	var user = env.user;
	if (user.hasDebt === true) user._hasDebt.$setValue(null);
	if (user.hasHygieneDebt === true) user._hasHygieneDebt.$setValue(null);
};

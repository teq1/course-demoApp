'use strict';

module.exports = function (data, env) {
	var user = env.user;
	if (user.isPreInspectionSatisfactory === false) {
		user._preInspectionDateFrom.$setValue(null);
		user._preInspectionDateTo.$setValue(null);
		user._preInspectionSatisfactory.$setValue(null);
		user._preInspectionDate.$setValue(null);
		return;
	}
	if (user.isLocInspectionSatisfactory === false) {
		user._locInspectionDateFrom.$setValue(null);
		user._locInspectionDateTo.$setValue(null);
		user._locInspectionSatisfactory.$setValue(null);
		user._locInspectionDate.$setValue(null);
		return;
	}
	user._inspectionDateFrom.$setValue(null);
	user._inspectionDateTo.$setValue(null);
	user._inspectionSatisfactory.$setValue(null);
	user._inspectionDate.$setValue(null);
};

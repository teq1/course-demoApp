'use strict';

module.exports = function (data, env) {
	env.user.submitted = null;
	env.user.revisionApproved = null;
};

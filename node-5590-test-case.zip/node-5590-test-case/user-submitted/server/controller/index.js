'use strict';

var cpCtrl      = require('mano-auth/server/controller/change-own-password-x')
  , profileCtrl = require('../../../user/server/controller/profile');

module.exports = {
	'change-own-password-x': cpCtrl,
	profile:                 profileCtrl,
	revise:                  require('./revise'),
	'revise-debt':           require('./revise-debt'),
	'revise-inspection':     require('./revise-inspection')
};

'use strict';

exports.route = function (req) {
	var user = req.$user;
	return user.roles.has('user') && user.isApplicationRegistered;
};
exports.role = 'user';
exports.order = 11;
exports.viewPath = '../view/user-submitted';

'use strict';

var Db           = require('dbjs')
  , DateType     = require('dbjs-ext/date-time/date')
  , SquareMeters = require('dbjs-ext/number/square-meters')
  , StringLine   = require('dbjs-ext/string/string-line')
  , File         = require('../../user/model/file')
  , Peso         = require('../../user/model/ui-argentine-peso')
  , User         = require('../../user/model/user/base');

module.exports = User;

require('../../user/model/user/features');

require('../../user/model/user/personal');
require('../../user/model/user/address');
require('../../user/model/user/partners');
require('../../user/model/user/business-address');
require('../../user/model/user/business');

require('../../user/model/user/company');
require('../../user/model/user/representatives');

require('../../user/model/user/submission');

require('../../user/model/user/process');

User.prototype.setProperties({
	revisionApproved: Db.Boolean,

	hasDebt: Db.Boolean.required,
	debt: Peso.required,

	hasHygieneDebt: Db.Boolean.required,
	hygieneDebt: Peso.required,

	preInspectionDateFrom: DateType.required,
	preInspectionDateTo: DateType.required,

	preInspectionDate: Db.DateTime.rel({ required: true,
		label: "Fecha de inspección" }),
	preInspectorName: StringLine.rel({ required: true,
		label: "Nombre del inspector" }),
	preInspectionSatisfactory: Db.Boolean.rel({ required: true,
		trueLabel: "Inspección satisfactoria",
		falseLabel: "Inspección insatisfactoria" }),
	preInspectionRejectReason: Db.String.rel({ required: true,
		label: "Razones de rechazo" }),

	locInspectionDateFrom: DateType.required,
	locInspectionDateTo: DateType.required,

	locInspectionDate: Db.DateTime.rel({ required: true,
		label: "Fecha de inspección" }),
	locInspectorName: StringLine.rel({ required: true,
		label: "Nombre del inspector" }),
	locInspectionSatisfactory: Db.Boolean.rel({ required: true,
		trueLabel: "Inspección satisfactoria",
		falseLabel: "Inspección insatisfactoria" }),
	locInspectionRejectReason: Db.String.rel({ required: true,
		label: "Razones de rechazo" }),

	locResolution: File,
	locResolutionSatisfactory: Db.Boolean.rel({ required: true,
		trueLabel: "Validar localización",
		falseLabel: "Rechazar localización" }),
	locResolutionRejectReason: Db.String.rel({ required: true,
		label: "Razones de rechazo" }),
	locResolutionSent: Db.Boolean,

	inspectionDateFrom: DateType.required,
	inspectionDateTo: DateType.required,

	inspectionDate: Db.DateTime.rel({ required: true,
		label: "Fecha de inspección" }),
	inspectorName: StringLine.rel({ required: true,
		label: "Nombre del inspector" }),
	surfaceTradeConfirmed: SquareMeters.rel({ required: true,
		label: "Superficie constatada" }),
	pickupDate: DateType.rel({ required: true, label: "Fecha de retiro" }),
	inspectionSatisfactory: Db.Boolean.rel({ required: true,
		trueLabel: "Inspección satisfactoria",
		falseLabel: "Inspección insatisfactoria" }),
	inspectionRejectReason: Db.String.rel({ required: true,
		label: "Razones de rechazo" }),

	minutesSticker: File,
	minutesStickerSent: Db.Boolean,

	treasuryPaymentReceipt: File,
	treasuryPaymentReceiptSent: Db.Boolean,

	habilitation: File,
	habilitationSent: Db.Boolean,

	submissionsApproved: Db.Boolean.rel({ value: function () {
		var setup, initialized, subs, value;
		if (!this.submissions) return null;
		if (!this.submissions.hasOwnProperty('$statusApproveObserve')) {
			this.submissions.forEach(setup = function (sub) {
				sub._isApproved.on('change', this._submissionsApproved._update_);
				if (initialized) this._submissionsApproved._update_();
			}, this);
			this.submissions.on('add', setup.bind(this));
			this.submissions.on('delete', function (sub) {
				sub._isApproved.off('change', this._submissionsApproved._update_);
			}.bind(this));
			initialized = true;
			Object.defineProperty(this.submissions, '$statusApproveObserve',
				{ value: true, enumerable: false, writable: true, configurable: true });
		}
		subs = this.requiredSubmissions;
		if (!subs || !subs.count) return null;
		if (subs.count > this.submissions.count) return null;
		value = true;
		return subs.values.some(function (name) {
			var sub = this[name + 'Submission'];
			if (!sub) return true;
			if (sub.isApproved == null) return true;
			if (!sub.isApproved) value = false;
			return false;
		}, this) ? null : value;
	}, triggers: ['requiredSubmissions', 'submissions'] }),

	isRevisionApproved: Db.Boolean.rel({ value: function () {
		var approved, revApproved;
		if (!this.isApplicationRegistered) return null;
		approved = this.submissionsApproved;
		if (approved == null) return null;
		revApproved = this.revisionApproved;
		if (revApproved == null) return null;
		if (!approved) return false;
		return revApproved;
	}, triggers: ['isApplicationRegistered', 'submissionsApproved',
		 'revisionApproved'] }),

	isTaxDebtCleared: Db.Boolean.rel({ value: function () {
		if (!this.isRevisionApproved) return null;
		if (this.hasDebt == null) return null;
		if (!this.hasDebt) return true;
		if (this.debt == null) return null;
		return false;
	}, triggers: ['isRevisionApproved', 'hasDebt', 'debt'] }),

	isHygieneDebtCleared: Db.Boolean.rel({ value: function () {
		if (!this.isRevisionApproved) return null;
		if (this.hasHygieneDebt == null) return null;
		if (!this.hasHygieneDebt) return true;
		if (this.hygieneDebt == null) return null;
		return false;
	}, triggers: ['isRevisionApproved', 'hasHygieneDebt', 'hygieneDebt'] }),

	isDebtCleared: Db.Boolean.rel({ value: function () {
		if (this.isTaxDebtCleared == null) return null;
		if (this.isHygieneDebtCleared == null) return null;
		return this.isTaxDebtCleared && this.isHygieneDebtCleared;
	}, triggers: ['isTaxDebtCleared', 'isHygieneDebtCleared'] }),

	isPreInspectionApplicable: Db.Boolean.rel({ value: function () {
		return ((this.businessGroup === 'B') || (this.businessGroup === 'D'));
	}, triggers: 'businessGroup' }),

	isPreInspectionScheduled: Db.Boolean.rel({ value: function () {
		if (!this.isDebtCleared) return null;
		if (!this.isPreInspectionApplicable) return null;

		if (this.preInspectionDateFrom == null) return null;
		if (this.preInspectionDateTo == null) return null;
		if (this.preInspectionDateFrom > this.preInspectionDateTo) return null;
		return true;
	}, triggers: ['isDebtCleared', 'isPreInspectionApplicable',
		 'preInspectionDateFrom', 'preInspectionDateTo'] }),

	isPreInspectionSatisfactory: Db.Boolean.rel({ value: function () {
		if (!this.isPreInspectionScheduled) return null;

		if (this.preInspectionDate == null) return null;
		if (this.preInspectorName == null) return null;
		if (this.preInspectionSatisfactory == null) return null;
		if (this.preInspectionSatisfactory) return true;
		if (this.preInspectionRejectReason == null) return null;
		return this.preInspectionSatisfactory;
	}, triggers: ['isPreInspectionScheduled', 'preInspectionDate',
		 'preInspectorName', 'preInspectionSatisfactory',
		 'preInspectionRejectReason'] }),

	isLocInspectionApplicable: Db.Boolean.rel({ value: function () {
		return ((this.businessGroup === 'C') || (this.businessGroup === 'D'));
	}, triggers: 'businessGroup' }),

	isLocInspectionReady: Db.Boolean.rel({ value: function () {
		if (!this.isDebtCleared) return false;
		if (!this.isLocInspectionApplicable) return false;
		if (this.isPreInspectionApplicable) {
			if (!this.isPreInspectionSatisfactory) return false;
		}
		return true;
	}, triggers: ['isDebtCleared', 'isLocInspectionApplicable',
		 'isPreInspectionApplicable', 'isPreInspectionSatisfactory'] }),

	isLocInspectionScheduled: Db.Boolean.rel({ value: function () {
		if (!this.isLocInspectionReady) return null;

		if (this.locInspectionDateFrom == null) return null;
		if (this.locInspectionDateTo == null) return null;
		if (this.locInspectionDateFrom > this.locInspectionDateTo) return null;
		return true;
	}, triggers: ['isLocInspectionReady', 'locInspectionDateFrom',
		 'locInspectionDateTo'] }),

	isLocInspectionSatisfactory: Db.Boolean.rel({ value: function () {
		if (!this.isLocInspectionScheduled) return null;

		if (this.locInspectionDate == null) return null;
		if (this.locInspectorName == null) return null;
		if (this.locInspectionSatisfactory == null) return null;
		if (this.locInspectionSatisfactory) return true;
		if (this.locInspectionRejectReason == null) return null;
		return this.locInspectionSatisfactory;
	}, triggers: ['isLocInspectionScheduled', 'locInspectionDate',
		 'locInspectorName', 'locInspectionSatisfactory',
		 'locInspectionRejectReason'] }),

	isLocResolutionSatisfactory: Db.Boolean.rel({ value: function () {
		if (!this.isLocInspectionSatisfactory) return null;
		if (!this.locResolutionSent) return null;
		if (this.locResolutionSatisfactory) {
			if (!this.locResolution) return null;
			return true;
		}
		if (this.locResolutionRejectReason == null) return null;
		return false;
	}, triggers: ['isLocInspectionSatisfactory', 'locResolutionSent',
		 'locResolutionSatisfactory', 'locResolution',
		 'locResolutionRejectReason'] }),

	isInspectionReady: Db.Boolean.rel({ value: function () {
		if (!this.isDebtCleared) return false;
		if (this.isPreInspectionApplicable) {
			if (!this.isPreInspectionSatisfactory) return false;
		}
		if (this.isLocInspectionApplicable) {
			if (!this.isLocResolutionSatisfactory) return false;
		}
		return true;
	}, triggers: ['isDebtCleared',
		 'isPreInspectionApplicable', 'isPreInspectionSatisfactory',
		 'isLocInspectionApplicable', 'isLocResolutionSatisfactory'] }),

	isInspectionScheduled: Db.Boolean.rel({ value: function () {
		if (!this.isInspectionReady) return null;

		if (this.inspectionDateFrom == null) return null;
		if (this.inspectionDateTo == null) return null;
		if (this.inspectionDateFrom > this.inspectionDateTo) return null;
		return true;
	}, triggers: ['isInspectionReady', 'inspectionDateFrom',
		 'inspectionDateTo'] }),

	isInspectionSatisfactory: Db.Boolean.rel({ value: function () {
		if (!this.isInspectionScheduled) return null;

		if (this.inspectionDate == null) return null;
		if (this.inspectorName == null) return null;
		if (this.surfaceTradeConfirmed == null) return null;
		if (this.inspectionSatisfactory == null) return null;
		if (this.inspectionSatisfactory) {
			if (this.pickupDate == null) return null;
		} else {
			if (this.inspectionRejectReason == null) return null;
		}
		return this.inspectionSatisfactory;
	}, triggers: ['isInspectionScheduled', 'inspectionDate', 'inspectorName',
		 'surfaceTradeConfirmed', 'inspectionSatisfactory', 'pickupDate',
		 'inspectionRejectReason'] }),

	hasAnyInspectionFailed: Db.Boolean.rel({ value: function () {
		if (this.isPreInspectionSatisfactory === false) return true;
		if (this.isLocInspectionSatisfactory === false) return true;
		if (this.isInspectionSatisfactory === false) return true;
		return false;
	}, triggers: ['isPreInspectionSatisfactory', 'isLocInspectionSatisfactory',
		 'isInspectionSatisfactory'] }),

	isMinutesStickerGenerated: Db.Boolean.rel({ value: function () {
		if (!this.isInspectionSatisfactory) return null;
		if (!this.minutesSticker || !this.minutesStickerSent) return null;
		return true;
	}, triggers: ['isInspectionSatisfactory', 'minutesSticker',
		 'minutesStickerSent'] }),

	isTreasuryPaymentReceived: Db.Boolean.rel({ value: function () {
		if (!this.isMinutesStickerGenerated) return null;
		if (!this.treasuryPaymentReceipt || !this.treasuryPaymentReceiptSent) {
			return null;
		}
		return true;
	}, triggers: ['isMinutesStickerGenerated', 'treasuryPaymentReceipt',
		 'treasuryPaymentReceiptSent'] }),

	submissionsValidated: Db.Boolean.rel({ value: function () {
		var setup, initialized, subs, value;
		if (!this.submissionsApproved) return null;
		if (!this.submissions) return null;
		if (!this.submissions.hasOwnProperty('$statusValidateObserve')) {
			this.submissions.forEach(setup = function (sub) {
				if (!sub.ns.validateWithOriginal) return;
				sub._matchesOriginal.on('change', this._submissionsValidated._update_);
				if (initialized) this._submissionsValidated._update_();
			}, this);
			this.submissions.on('add', setup.bind(this));
			this.submissions.on('delete', function (sub) {
				if (!sub.ns.validateWithOriginal) return;
				sub._matchesOriginal.off('change', this._submissionsValidated._update_);
			}.bind(this));
			initialized = true;
			Object.defineProperty(this.submissions, '$statusValidateObserve',
				{ value: true, enumerable: false, writable: true, configurable: true });
		}
		subs = this.requiredSubmissions;
		if (!subs || !subs.count) return null;
		if (subs.count > this.submissions.count) return null;
		value = true;
		return subs.values.some(function (name) {
			var sub = this[name + 'Submission'];
			if (!sub) return true;
			if (!sub.ns.validateWithOriginal) return false;
			if (sub.matchesOriginal == null) return true;
			if (!sub.matchesOriginal) value = false;
			return false;
		}, this) ? null : value;
	}, triggers: ['submissionsApproved', 'requiredSubmissions', 'submissions'] }),

	isHabilitationReady: Db.Boolean.rel({ value: function () {
		if (!this.isTreasuryPaymentReceived) return null;
		if (!this.habilitation || !this.submissionsValidated) return false;
		return true;
	}, triggers: ['isTreasuryPaymentReceived', 'habilitation',
		 'submissionsValidated'] }),

	isHabilitationReceived: Db.Boolean.rel({ value: function () {
		if (!this.isHabilitationReady || !this.habilitationSent) return null;
		return true;
	}, triggers: ['isHabilitationReady', 'habilitationSent'] })
});
